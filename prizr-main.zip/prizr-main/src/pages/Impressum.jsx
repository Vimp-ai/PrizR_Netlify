import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Impressum() {
  const navigate = useNavigate();

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button 
          variant="outline" 
          size="icon"
          onClick={() => navigate(createPageUrl("Dashboard"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-slate-50">Impressum</h1>
          <p className="text-slate-400">Angaben gemäß § 5 TMG</p>
        </div>
      </div>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>Anbieter</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-300">
          <p>
            Tim Häntschel<br />
            Goldstrasse 26<br />
            97274 Leinach<br />
            Deutschland/Germany
          </p>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2">Kontakt</h3>
            <p>
              E-Mail: [info@prizr.app]<br />
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2">Umsatzsteuer-ID</h3>
            <p>
              Umsatzsteuer-Identifikationsnummer gemäß §27 a Umsatzsteuergesetz:<br />
              [IHRE UST-ID]
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2">Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV</h3>
            <p>
              [IHR NAME]<br />
              [ADRESSE]
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2">Haftungsausschluss</h3>
            <p className="text-sm">
              Die Inhalte unserer Seiten wurden mit größter Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte können wir jedoch keine Gewähr übernehmen.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2">Online-Streitbeilegung</h3>
            <p className="text-sm">
              Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit:<br />
              <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline">
                https://ec.europa.eu/consumers/odr
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}