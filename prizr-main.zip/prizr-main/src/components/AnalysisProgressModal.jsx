import React, { useEffect, useRef, useState } from "react";
import { Loader2 } from "lucide-react";

export default function AnalysisProgressModal({
  isOpen,
  subscriptionType = "free",
  firstPhotoUrl,
  photoCount = 1,
  hasPro = false
}) {
  const [progress, setProgress] = useState(0);
  const rafRef = useRef(null);

  const FIXED_DURATION_MS = 40000;
  const targetBeforeFinish = 100;

  useEffect(() => {
    if (!isOpen) {
      cancelAnimationFrame(rafRef.current || 0);
      setProgress(0);
      return;
    }

    const start = performance.now();

    function tick(now) {
      const elapsed = now - start;
      const ratio = Math.min(elapsed / FIXED_DURATION_MS, 1);
      const eased = 1 - Math.pow(1 - ratio, 2);
      const next = Math.min(targetBeforeFinish, Math.floor(eased * 100));
      
      setProgress((p) => (next > p ? next : p));
      
      if (isOpen && next < targetBeforeFinish) {
        rafRef.current = requestAnimationFrame(tick);
      }
    }

    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current || 0);
  }, [isOpen]);

  if (!isOpen) return null;

  // Blur-Berechnung basierend auf echtem Progress (nicht Zeit)
  const blurAmount = Math.max(0, 40 - (progress / 100 * 40));
  const brightness = 0.6 + (progress / 100 * 0.4);

  // Kreisförmiger Fortschritt für SVG (circumference basiert)
  const radius = 140;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  // Dynamischer Status-Text basierend auf Progress
  const getStatusText = () => {
    if (progress < 25) return "Bilder werden analysiert";
    if (progress < 50) return "Designer wird identifiziert";
    if (progress < 75) return "Marktwerte werden recherchiert";
    if (progress < 95) return "Bewertung wird finalisiert";
    return "Fast fertig...";
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative flex flex-col items-center justify-center">
        {/* Hintergrund-Glow */}
        <div
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            background: "radial-gradient(circle, rgba(34,211,238,0.4), rgba(14,165,233,0.2) 50%, transparent 80%)",
            filter: "blur(80px)",
            transform: "scale(1.8)"
          }}
        />

        {/* Haupt-Container (Kreis) */}
        <div className="relative w-80 h-80 flex items-center justify-center">
          {/* SVG Kreisförmiger Fortschrittsring */}
          <svg 
            className="absolute inset-0 w-full h-full -rotate-90"
            viewBox="0 0 320 320"
          >
            {/* Hintergrund-Ring */}
            <circle
              cx="160"
              cy="160"
              r={radius}
              stroke="rgba(148, 163, 184, 0.1)"
              strokeWidth="8"
              fill="none"
            />
            {/* Fortschritts-Ring */}
            <circle
              cx="160"
              cy="160"
              r={radius}
              stroke="url(#gradient)"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              style={{
                strokeDasharray: circumference,
                strokeDashoffset: strokeDashoffset,
                transition: 'stroke-dashoffset 0.3s ease-out'
              }}
            />
            {/* Gradient Definition */}
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#06b6d4" />
                <stop offset="100%" stopColor="#14b8a6" />
              </linearGradient>
            </defs>
          </svg>

          {/* Innerer Kreis mit Bild */}
          <div className="relative w-64 h-64 rounded-full overflow-hidden border-4 border-slate-800 shadow-2xl bg-gradient-to-br from-slate-800 to-slate-900">
            {firstPhotoUrl ? (
              <img
                src={firstPhotoUrl}
                alt="Analyzing"
                className="w-full h-full object-cover transition-all duration-500"
                style={{ 
                  filter: `blur(${blurAmount}px) brightness(${brightness})`,
                }}
                onError={(e) => {
                  e.target.style.display = 'none';
                }}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-cyan-900/30 to-teal-900/30">
                <Loader2 className="w-16 h-16 text-cyan-400 animate-spin" />
              </div>
            )}

            {/* Glanz-Effekt über dem Bild */}
            <div 
              className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 via-transparent to-teal-400/20 pointer-events-none"
              style={{
                opacity: progress / 200 // Wird heller mit Progress
              }}
            />
          </div>
        </div>

        {/* Status Text (unterhalb des Kreises) */}
        <div className="mt-8 text-center z-10 max-w-sm">
          <h3 className="text-xl font-bold text-slate-50 mb-2">
            Analyse läuft...
          </h3>
          <p className="text-slate-400 text-sm">
            {getStatusText()}
          </p>
        </div>
      </div>
    </div>
  );
}