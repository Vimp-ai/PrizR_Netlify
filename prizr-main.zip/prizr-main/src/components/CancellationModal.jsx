import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { X, AlertTriangle, Info } from 'lucide-react';

/**
 * Rechtssicheres Kündigungs-Modal gemäß EU-Recht (DSGVO, § 312k BGB)
 * 
 * Anforderungen:
 * - Klare Button-Beschriftung (§ 312k BGB - Button-Lösung)
 * - Transparente Information über Kündigungsfolgen
 * - Dokumentation der Kündigungserklärung
 * - Bestätigung der Kündigung
 */
export default function CancellationModal({ 
  isOpen, 
  onClose, 
  onConfirm, 
  loading = false,
  subscriptionEndDate = null 
}) {
  if (!isOpen) return null;

  const endDate = subscriptionEndDate 
    ? new Date(subscriptionEndDate).toLocaleDateString('de-DE', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      })
    : 'sofort';

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <Card className="bg-slate-900 border-slate-800 max-w-lg w-full shadow-2xl">
        <CardHeader className="border-b border-slate-800">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-orange-900/30 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-orange-400" />
              </div>
              <div>
                <CardTitle className="text-xl text-slate-50">
                  Abonnement kündigen
                </CardTitle>
                <CardDescription className="text-slate-400 mt-1">
                  Bitte bestätigen Sie die Kündigung
                </CardDescription>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onClose}
              disabled={loading}
              className="text-slate-400 hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6 space-y-4">
          {/* Hauptinformation */}
          <div className="space-y-3">
            <p className="text-slate-300 leading-relaxed">
              Sie sind dabei, Ihr <strong className="text-slate-100">Prizr Pro</strong> Abonnement zu kündigen.
            </p>

            {/* Folgen der Kündigung */}
            <Alert className="bg-slate-800/50 border-slate-700">
              <Info className="h-4 w-4 text-cyan-400" />
              <AlertDescription className="text-slate-300">
                <strong className="text-slate-100">Was passiert nach der Kündigung?</strong>
                <ul className="mt-2 space-y-1 text-sm">
                  <li>• Ihr Abonnement bleibt bis zum <strong>{endDate}</strong> aktiv</li>
                  <li>• Bis dahin können Sie alle Pro-Funktionen weiter nutzen</li>
                  <li>• Danach wird Ihr Konto auf den kostenlosen Free-Plan herabgestuft</li>
                  <li>• Es erfolgt keine automatische Verlängerung oder weitere Abrechnung</li>
                  <li>• Ihre bisherigen Bewertungen bleiben erhalten</li>
                </ul>
              </AlertDescription>
            </Alert>

            {/* Rechtliche Hinweise */}
            <div className="text-xs text-slate-500 bg-slate-800/30 p-3 rounded border border-slate-700">
              <p className="mb-2">
                <strong className="text-slate-400">Rechtliche Hinweise:</strong>
              </p>
              <ul className="space-y-1">
                <li>• Die Kündigung wird sofort wirksam und ist unwiderruflich</li>
                <li>• Sie erhalten eine Kündigungsbestätigung per E-Mail</li>
                <li>• Bei Fragen kontaktieren Sie uns unter: kontakt@prizr.app</li>
                <li>• Ihre Daten werden gemäß unserer Datenschutzerklärung behandelt</li>
              </ul>
            </div>
          </div>

          {/* Action Buttons - Rechtssichere Beschriftung gemäß § 312k BGB */}
          <div className="flex flex-col-reverse sm:flex-row gap-3 pt-4">
            <Button 
              variant="outline" 
              onClick={onClose}
              disabled={loading}
              className="flex-1 border-slate-700 hover:bg-slate-800"
            >
              Abbrechen
            </Button>
            <Button 
              onClick={onConfirm}
              disabled={loading}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold"
            >
              {loading ? (
                <>
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                  Wird bearbeitet...
                </>
              ) : (
                'Ja, kostenpflichtig kündigen'
              )}
            </Button>
          </div>

          {/* Zusätzlicher Hinweis */}
          <p className="text-xs text-center text-slate-500 pt-2">
            Sie können jederzeit wieder upgraden, wenn Sie möchten.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}