import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { X, Euro, Calendar, Eye } from 'lucide-react';
import { format } from 'date-fns';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import ReactMarkdown from 'react-markdown';

const cleanAiResponse = (text) => {
  if (typeof text !== 'string') return text;
  return text.replace(/\(Basierend auf [0-9]+ vergleichbaren Angeboten\)/gi, '')
             .replace(/Marktabgleich:/gi, '')
             .replace(/Objektinformationen/gi, '')
             .trim();
};

const getPhotoArray = (photoUrlsField) => {
  if (!photoUrlsField) return [];
  if (Array.isArray(photoUrlsField)) return photoUrlsField;
  if (typeof photoUrlsField === 'string') {
    try {
      const parsed = JSON.parse(photoUrlsField);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) {
      if (photoUrlsField.startsWith('http')) {
        return [photoUrlsField];
      }
    }
  }
  return [];
};

const ValuationDetailModal = ({ valuation, onClose, onImageClick }) => {
  if (!valuation) return null;

  const getConfidenceBadge = (confidence) => {
    const badges = {
      high: {
        component: <Badge className="bg-teal-900 text-teal-200 border-teal-700">🎯 Recht sicher</Badge>,
        tooltip: "Die KI ist sehr sicher bei dieser Bewertung. Basiert auf klaren Erkennungsmerkmalen und verlässlichen Marktdaten."
      },
      medium: {
        component: <Badge className="bg-yellow-900 text-yellow-200 border-yellow-700">⚡ Einigermaßen sicher</Badge>,
        tooltip: "Solide Bewertung basierend auf verfügbaren Informationen. Kleinere Unsicherheiten bei Details oder Marktpreisen."
      },
      low: {
        component: <Badge className="bg-orange-900 text-orange-200 border-orange-700">📊 Grobe Schätzung</Badge>,
        tooltip: "Bewertung mit Unsicherheiten. Wenige Vergleichsdaten oder schwer identifizierbare Merkmale."
      }
    };

    const badge = badges[confidence];
    if (!badge) return null;

    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            {badge.component}
          </TooltipTrigger>
          <TooltipContent>
            <p className="max-w-xs">{badge.tooltip}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  };

  const getConditionText = (condition) => {
    const conditions = {
      1: "Neuwertig",
      2: "Gut", 
      3: "Gebrauchsspuren",
      4: "Starke Abnutzung",
      5: "Grenzwertig nutzbar"
    };
    return conditions[condition] || "Unbekannt";
  };

  // ENTFERNT: proAnalysis-Verarbeitung
  const getSafeParsedObject = (data, fallback = {}) => {
    if (typeof data === 'object' && data !== null) return data;
    if (typeof data === 'string') {
      try {
        const parsed = JSON.parse(data);
        return typeof parsed === 'object' && parsed !== null ? parsed : fallback;
      } catch (e) {
        return fallback;
      }
    }
    return fallback;
  };

  const getSafeParsedArray = (data) => {
    const obj = getSafeParsedObject(data, []);
    return Array.isArray(obj) ? obj : [];
  };

  const originalInfo = getSafeParsedObject(valuation.isReplica && valuation.originalInfo ? valuation.originalInfo : null);
  const displayedAlternativeIdentifications = getSafeParsedArray(valuation.alternativeIdentifications);
  const displayedDesignerCandidates = getSafeParsedArray(valuation.designerCandidates);

  const getShortTitle = () => {
    if (valuation.identifiedStyle) {
      return valuation.identifiedStyle;
    }
    if (valuation.description) {
      const words = valuation.description.split(' ').slice(0, 3).join(' ');
      return words.length > 30 ? words.substring(0, 30) + '...' : words;
    }
    return 'Bewertungsdetails';
  };

  const photoUrls = getPhotoArray(valuation?.photoUrls);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col">
        <div className="flex-1 overflow-y-auto">
          <div className="bg-slate-900 border-b border-slate-800 p-6 flex justify-between items-start">
            <div>
              <h2 className="text-xl font-bold text-slate-50">
                {getShortTitle()}
              </h2>
              {valuation.description && valuation.description !== getShortTitle() && (
                <p className="text-sm text-slate-400 mt-1 max-w-md">
                  {valuation.description}
                </p>
              )}
              <p className="text-xs text-slate-500 mt-2">
                {format(new Date(valuation.created_date), 'dd.MM.yyyy HH:mm')} Uhr
              </p>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          <div className="p-6 space-y-6">
            {valuation.isNotFurniture && (
              <Card className="bg-orange-900/20 border-orange-700">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-orange-200">
                    <span className="text-2xl">🚫</span>
                    <div>
                      <h3 className="font-semibold">Kein Möbelstück erkannt</h3>
                      <p className="text-sm text-orange-300 mt-1">
                        Dieser Gegenstand scheint kein Möbelstück zu sein. Bewertungen für andere Objekte sind noch in Entwicklung.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {displayedDesignerCandidates.length > 0 && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-slate-100">Designer-Kandidaten</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {displayedDesignerCandidates.map((candidate, idx) => (
                    <div key={idx} className="p-3 bg-slate-900/50 rounded-lg border border-slate-700">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-semibold text-slate-100">{candidate.designer}</span>
                        <Badge variant="outline">{candidate.confidence}% sicher</Badge>
                      </div>
                      <p className="text-sm text-slate-400">{candidate.reasoning}</p>
                      {candidate.specificFeatures && (
                        <p className="text-xs text-slate-500 mt-1">
                          <strong>Merkmale:</strong> {candidate.specificFeatures}
                        </p>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {displayedAlternativeIdentifications.length > 0 && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-slate-100">Alternative Identifikationen</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {displayedAlternativeIdentifications.map((alt, idx) => (
                      <li key={idx} className="text-sm text-slate-300">
                        <strong>{alt.style}</strong> ({alt.confidence}% sicher)
                        <p className="text-xs text-slate-500">{alt.reasoning}</p>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            <Card className="bg-gradient-to-br from-slate-800 to-slate-700 border-teal-700">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row items-start justify-between mb-4 gap-6">
                  <div className="flex-1">
                    <div className="mb-4">
                      <h3 className="text-lg font-semibold text-slate-100 mb-2">Angebotspreis (Marktpreis)</h3>
                      <div className="flex items-center gap-2 mb-2">
                        <Euro className="w-8 h-8 text-teal-400" />
                        <span className="text-3xl font-bold text-teal-400">
                          {valuation.estimatedValue?.toLocaleString('de-DE', { 
                            style: 'currency', 
                            currency: 'EUR', 
                            maximumFractionDigits: 0 
                          })}
                        </span>
                      </div>
                      <p className="text-teal-300 text-sm">
                        Durchschnittlicher Marktpreis
                      </p>
                    </div>
                    
                    {valuation.realisticPrice && (
                      <div>
                        <h3 className="text-lg font-semibold text-slate-100 mb-2">Realistischer Verkaufspreis</h3>
                        <div className="flex items-center gap-2 mb-2">
                          <Euro className="w-8 h-8 text-cyan-400" />
                          <span className="text-3xl font-bold text-cyan-400">
                            {valuation.realisticPrice?.toLocaleString('de-DE', { 
                              style: 'currency', 
                              currency: 'EUR', 
                              maximumFractionDigits: 0 
                            })}
                          </span>
                        </div>
                        <p className="text-cyan-300 text-sm">
                          Inkl. Zustand & Handelsspanne
                        </p>
                      </div>
                    )}
                    
                    <p className="text-slate-400 mt-4">
                      Wertspanne: {valuation.valueRange}
                    </p>
                  </div>
                  
                  <div className="flex flex-col gap-2 items-start lg:items-end">
                    {getConfidenceBadge(valuation.confidence)}
                    {valuation.isReplica && (
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Badge className="bg-orange-900 text-orange-200 border-orange-700">
                              ⚠️ Möglicherweise Replika
                            </Badge>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">Die KI hat Anzeichen entdeckt, die auf eine Nachbildung hindeuten könnten.</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )}
                  </div>
                </div>

                {valuation.isReplica && originalInfo && Object.keys(originalInfo).length > 0 && (
                  <div className="mb-4 p-4 bg-orange-900/20 border border-orange-700 rounded-lg">
                    <h3 className="font-semibold text-orange-200 mb-2">🔍 Replika-Analyse</h3>
                    <div className="space-y-2 text-sm">
                      {originalInfo.estimatedOriginalValue && (
                        <p className="text-slate-300">
                          <strong>Original-Wert:</strong> {originalInfo.estimatedOriginalValue.toLocaleString('de-DE', { 
                            style: 'currency', 
                            currency: 'EUR', 
                            maximumFractionDigits: 0 
                          })}
                        </p>
                      )}
                      {originalInfo.recognitionFeatures && (
                        <p className="text-slate-300">
                          <strong>Original erkennen an:</strong> {originalInfo.recognitionFeatures}
                        </p>
                      )}
                      {originalInfo.replicaIndicators && (
                        <p className="text-slate-300">
                          <strong>Replika-Hinweise:</strong> {originalInfo.replicaIndicators}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-slate-100 mb-2">Beschreibung</h3>
                    <p className="text-slate-300">{valuation.description}</p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-slate-100 mb-2">Identifizierter Stil</h3>
                    <p className="text-slate-300">{valuation.identifiedStyle}</p>
                  </div>

                  {(valuation.manufacturer || valuation.likelyManufacturer) && (
                    <div>
                      <h3 className="font-semibold text-slate-100 mb-2">Hersteller</h3>
                      <p className="text-slate-300">{valuation.manufacturer || valuation.likelyManufacturer}</p>
                    </div>
                  )}

                  {(valuation.primaryDesigner || valuation.likelyDesigner) && (
                    <div>
                      <h3 className="font-semibold text-slate-100 mb-2">Designer</h3>
                      <p className="text-slate-300">{valuation.primaryDesigner || valuation.likelyDesigner}</p>
                    </div>
                  )}

                  <div>
                    <h3 className="font-semibold text-slate-100 mb-2">Bewertungsgrundlage</h3>
                    <p className="text-slate-300">{cleanAiResponse(valuation.reasoning)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* ENTFERNT: Detaillierte Analyse Card */}

            {(valuation.forgeryDetection || valuation.additionalInfo) && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader><CardTitle>Zusätzliche Informationen</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  {valuation.forgeryDetection && (
                    <div>
                      <h3 className="font-semibold text-slate-100 mb-2">Fälschungserkennung</h3>
                      <p className="text-slate-300">{valuation.forgeryDetection}</p>
                    </div>
                  )}
                  {valuation.additionalInfo && (
                    <div>
                      {valuation.forgeryDetection && <Separator className="bg-slate-700 my-4"/>}
                      <h3 className="font-semibold text-slate-100 mb-2">Weitere Informationen</h3>
                      <p className="text-slate-300">{valuation.additionalInfo}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle>Objektinformationen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-slate-400">Zustand:</span>
                    <div className="font-medium text-slate-100">
                      {getConditionText(valuation.condition)}
                    </div>
                  </div>
                  {valuation.woodType && (
                    <div>
                      <span className="text-slate-400">Material:</span>
                      <div className="font-medium text-slate-100">{valuation.woodType}</div>
                    </div>
                  )}
                  {valuation.age && (
                    <div>
                      <span className="text-slate-400">Alter:</span>
                      <div className="font-medium text-slate-100">{valuation.age}</div>
                    </div>
                  )}
                  {valuation.origin && (
                    <div>
                      <span className="text-slate-400">Weitere Infos:</span>
                      <div className="font-medium text-slate-100">{valuation.origin}</div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle>Analysierte Fotos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  {photoUrls.map((url, index) => 
                    url && (
                      <div key={index} className="space-y-2 cursor-pointer" onClick={() => onImageClick(url)}>
                        <img 
                          src={url} 
                          alt={`Foto ${index + 1}`} 
                          className="w-full h-24 object-cover rounded-lg border border-slate-600 hover:border-cyan-500 transition-colors"
                        />
                        <p className="text-xs text-slate-400 text-center">{`Foto ${index + 1}`}</p>
                      </div>
                    )
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ValuationDetailModal;