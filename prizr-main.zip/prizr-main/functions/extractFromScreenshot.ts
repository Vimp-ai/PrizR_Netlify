import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Nicht autorisiert' }, { status: 401 });
    }

    const { screenshot } = await req.json();
    
    if (!screenshot) {
      return Response.json({ error: 'Kein Screenshot bereitgestellt' }, { status: 400 });
    }

    console.log("📸 Screenshot-Extraktion gestartet");

    // Nutze InvokeLLM mit file_urls für Bild-Analyse
    const analysisResult = await base44.integrations.Core.InvokeLLM({
      prompt: `Analysiere diesen Screenshot eines Möbelangebots (z.B. eBay, Kleinanzeigen) und extrahiere:
1. Material/Holzart (z.B. "Teak", "Eiche")
2. Geschätztes Alter/Epoche (z.B. "1960er", "Mid-Century")
3. Herkunft/Hersteller
4. Zustand (1-5, wobei 1=neuwertig, 5=stark gebraucht)
5. Kurze Beschreibung (2-3 Sätze)

Antworte NUR mit JSON:`,
      file_urls: [screenshot],
      response_json_schema: {
        type: "object",
        properties: {
          woodType: { type: "string" },
          age: { type: "string" },
          origin: { type: "string" },
          condition: { type: "number" },
          description: { type: "string" }
        }
      }
    });

    const result = {
      ...analysisResult,
      imageUrls: [],
      note: "Bitte laden Sie die Produktfotos separat hoch."
    };

    console.log("✅ Screenshot-Extraktion erfolgreich");
    return Response.json(result);

  } catch (error) {
    console.error("❌ Fehler:", error.message);
    return Response.json({
      error: 'Screenshot-Extraktion fehlgeschlagen',
      details: error.message
    }, { status: 500 });
  }
});