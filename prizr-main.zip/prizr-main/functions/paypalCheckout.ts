import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const paypalClientId = Deno.env.get("PAYPAL_CLIENT_ID");
        const paypalClientSecret = Deno.env.get("PAYPAL_CLIENT_SECRET");
        const paypalSandbox = Deno.env.get("PAYPAL_SANDBOX") === "true";
        const paypalProPlanId = Deno.env.get("PAYPAL_PRO_PLAN_ID");
        
        if (!paypalClientId || !paypalClientSecret || !paypalProPlanId) {
            return Response.json({ error: 'PayPal nicht vollständig konfiguriert' }, { status: 500 });
        }

        const { planType } = await req.json();

        if (planType !== 'pro') {
            return Response.json({ error: 'Ungültiger Plan' }, { status: 400 });
        }

        const baseUrl = paypalSandbox ? 
            "https://api-m.sandbox.paypal.com" : 
            "https://api-m.paypal.com";

        // PayPal Access Token abrufen
        const tokenResponse = await fetch(`${baseUrl}/v1/oauth2/token`, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Accept-Language': 'de_DE',
                'Authorization': `Basic ${btoa(`${paypalClientId}:${paypalClientSecret}`)}`
            },
            body: 'grant_type=client_credentials'
        });

        if (!tokenResponse.ok) {
            throw new Error('Fehler beim Abrufen des PayPal Access Tokens');
        }

        const tokenData = await tokenResponse.json();
        const accessToken = tokenData.access_token;

        // PayPal Subscription erstellen
        const subscriptionResponse = await fetch(`${baseUrl}/v1/billing/subscriptions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                plan_id: paypalProPlanId,
                start_time: new Date(Date.now() + 60000).toISOString(),
                quantity: '1',
                subscriber: {
                    name: {
                        given_name: user.full_name?.split(' ')[0] || 'User',
                        surname: user.full_name?.split(' ').slice(1).join(' ') || 'Name'
                    },
                    email_address: user.email
                },
                application_context: {
                    brand_name: 'Prizr',
                    locale: 'de-DE',
                    shipping_preference: 'NO_SHIPPING',
                    user_action: 'SUBSCRIBE_NOW',
                    payment_method: {
                        payer_selected: 'PAYPAL',
                        payee_preferred: 'IMMEDIATE_PAYMENT_REQUIRED'
                    },
                    return_url: `${req.headers.get('origin')}/Dashboard?payment=success`,
                    cancel_url: `${req.headers.get('origin')}/Abonnement?payment=cancelled`
                },
                custom_id: user.id
            })
        });

        if (!subscriptionResponse.ok) {
            const errorData = await subscriptionResponse.text();
            throw new Error(`PayPal Subscription Error: ${errorData}`);
        }

        const subscriptionData = await subscriptionResponse.json();
        
        const approveLink = subscriptionData.links?.find(link => link.rel === 'approve');
        
        if (!approveLink) {
            throw new Error('Keine Approval URL von PayPal erhalten');
        }

        return Response.json({ 
            checkoutUrl: approveLink.href,
            subscriptionId: subscriptionData.id
        });

    } catch (error) {
        console.error('PayPal Checkout Error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});