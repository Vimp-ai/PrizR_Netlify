import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    console.log('🔐 Admin-Passwort-Verifizierung gestartet...');
    
    const base44 = createClientFromRequest(req);
    
    // Authentifiziere User
    const user = await base44.auth.me();
    
    if (!user) {
      console.error('❌ Kein User authentifiziert');
      return Response.json({ 
        success: false, 
        error: 'Nicht authentifiziert' 
      }, { status: 401 });
    }
    
    console.log(`👤 User: ${user.email}, Role: ${user.role}`);
    
    // Prüfe ob User Admin ist
    if (user.role !== 'admin') {
      console.error('❌ User ist kein Admin');
      return Response.json({ 
        success: false, 
        error: 'Keine Admin-Berechtigung' 
      }, { status: 403 });
    }
    
    // Parse Request Body
    const { email, password } = await req.json();
    
    if (!email || !password) {
      console.error('❌ E-Mail oder Passwort fehlt');
      return Response.json({ 
        success: false, 
        error: 'E-Mail und Passwort erforderlich' 
      }, { status: 400 });
    }
    
    // Prüfe ob E-Mail mit eingeloggtem User übereinstimmt
    if (user.email.toLowerCase() !== email.toLowerCase()) {
      console.error('❌ E-Mail stimmt nicht überein');
      return Response.json({ 
        success: false, 
        error: 'E-Mail-Adresse stimmt nicht überein' 
      }, { status: 403 });
    }
    
    // Hole Admin-Passwort aus Environment Variables
    const adminPassword = Deno.env.get('ADMIN_PASSWORD');
    
    if (!adminPassword) {
      console.error('❌ ADMIN_PASSWORD Environment Variable nicht gesetzt');
      return Response.json({ 
        success: false, 
        error: 'Server-Konfigurationsfehler' 
      }, { status: 500 });
    }
    
    // Vergleiche Passwörter
    if (password !== adminPassword) {
      console.error('❌ Falsches Passwort');
      return Response.json({ 
        success: false, 
        error: 'Falsches Passwort' 
      }, { status: 403 });
    }
    
    console.log('✅ Admin-Passwort korrekt');
    
    return Response.json({ 
      success: true,
      message: 'Admin-Authentifizierung erfolgreich'
    });
    
  } catch (error) {
    console.error('❌ Fehler bei Admin-Verifizierung:', error);
    return Response.json({ 
      success: false, 
      error: 'Interner Server-Fehler' 
    }, { status: 500 });
  }
});