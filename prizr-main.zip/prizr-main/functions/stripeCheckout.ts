import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@16.12.0';

Deno.serve(async (req) => {
  console.log('\n' + '='.repeat(80));
  console.log('🔄 STRIPE CHECKOUT REQUEST GESTARTET');
  console.log('='.repeat(80));
  
  try {
    const base44 = createClientFromRequest(req);
    
    console.log('1️⃣ Authentifiziere User...');
    const user = await base44.auth.me();
    
    if (!user) {
      console.error('❌ Unauthorized: Kein User gefunden');
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    console.log(`✅ User authentifiziert: ${user.email}`);

    console.log('2️⃣ Lade Environment Variables...');
    const stripeSecretKey = Deno.env.get("STRIPE_SECRET_KEY");
    const priceIdPro = Deno.env.get("STRIPE_PRICE_ID_PRO");
    const priceIdBasis = Deno.env.get("STRIPE_PRICE_ID_BASIS");
    const priceIdMini = Deno.env.get("STRIPE_PRICE_ID_MINI");

    console.log(`   - STRIPE_SECRET_KEY: ${stripeSecretKey ? '✅ Gesetzt' : '❌ FEHLT'}`);
    console.log(`   - STRIPE_PRICE_ID_PRO: ${priceIdPro ? '✅ ' + priceIdPro : '❌ FEHLT'}`);
    console.log(`   - STRIPE_PRICE_ID_BASIS: ${priceIdBasis ? '✅ ' + priceIdBasis : '❌ FEHLT'}`);
    console.log(`   - STRIPE_PRICE_ID_MINI: ${priceIdMini ? '✅ ' + priceIdMini : '❌ FEHLT'}`);

    if (!stripeSecretKey) {
      console.error('❌ Stripe Secret Key fehlt');
      return Response.json({ error: 'Stripe Secret Key fehlt' }, { status: 500 });
    }

    console.log('3️⃣ Parse Request Body...');
    const { planType } = await req.json();
    console.log(`   - Plan Type: ${planType}`);
    
    // Bestimme Preis-ID und Modus basierend auf Plan-Typ
    let priceId;
    let mode;
    
    console.log('4️⃣ Bestimme Price ID und Mode...');
    if (planType === 'pro') {
      if (!priceIdPro) {
        console.error('❌ PRO Price ID fehlt');
        return Response.json({ 
          error: 'Stripe PRO Price ID fehlt',
          details: 'Bitte konfigurieren Sie STRIPE_PRICE_ID_PRO in den Environment Variables.'
        }, { status: 500 });
      }
      priceId = priceIdPro;
      mode = 'subscription';
      console.log(`   ✅ Pro-Plan: ${priceId} (mode: ${mode})`);
      
    } else if (planType === 'pack_5') {
      if (!priceIdMini) {
        console.error('❌ MINI Price ID fehlt');
        return Response.json({ 
          error: 'Stripe MINI Price ID fehlt',
          details: 'Bitte konfigurieren Sie STRIPE_PRICE_ID_MINI in den Environment Variables.'
        }, { status: 500 });
      }
      priceId = priceIdMini;
      mode = 'payment';
      console.log(`   ✅ 5-er Paket: ${priceId} (mode: ${mode})`);
      
    } else if (planType === 'pack_20') {
      if (!priceIdBasis) {
        console.error('❌ BASIS Price ID fehlt');
        return Response.json({ 
          error: 'Stripe BASIS Price ID fehlt',
          details: 'Bitte konfigurieren Sie STRIPE_PRICE_ID_BASIS in den Environment Variables.'
        }, { status: 500 });
      }
      priceId = priceIdBasis;
      mode = 'payment';
      console.log(`   ✅ 20-er Paket: ${priceId} (mode: ${mode})`);
      
    } else {
      console.error(`❌ Ungültiger Plan-Typ: ${planType}`);
      return Response.json({ 
        error: 'Ungültiger Plan-Typ',
        details: `Der Plan-Typ "${planType}" ist nicht bekannt.`
      }, { status: 400 });
    }

    console.log('5️⃣ Initialisiere Stripe...');
    const stripe = new Stripe(stripeSecretKey);
    console.log('   ✅ Stripe initialisiert (verwendet Account-Standard API-Version)');

    let customerId = user.stripeCustomerId;
    
    console.log('6️⃣ Prüfe/Erstelle Stripe Customer...');
    if (!customerId) {
      console.log('   ℹ️ Kein Customer vorhanden, erstelle neuen...');
      try {
        const customer = await stripe.customers.create({
          email: user.email,
          name: user.full_name,
          metadata: { userId: user.id }
        });
        customerId = customer.id;
        console.log(`   ✅ Neuer Customer erstellt: ${customerId}`);
        
        // Speichere Stripe Customer ID beim User
        await base44.asServiceRole.entities.User.update(user.id, { 
          stripeCustomerId: customerId 
        });
        console.log('   ✅ Customer ID in Datenbank gespeichert');
        
      } catch (customerError) {
        console.error('❌ Fehler beim Erstellen des Customers:', customerError);
        return Response.json({ 
          error: 'Fehler beim Erstellen des Stripe-Kunden',
          details: customerError.message
        }, { status: 500 });
      }
    } else {
      console.log(`   ✅ Bestehender Customer: ${customerId}`);
    }

    console.log('7️⃣ Erstelle Checkout Session...');
    console.log(`   - Mode: ${mode}`);
    console.log(`   - Price ID: ${priceId}`);
    console.log(`   - Customer ID: ${customerId}`);
    
    try {
      const session = await stripe.checkout.sessions.create({
        mode: mode,
        payment_method_types: ['card', 'paypal'],
        customer: customerId,
        line_items: [{ price: priceId, quantity: 1 }],
        success_url: `${req.headers.get('origin')}/Dashboard?payment=success`,
        cancel_url: `${req.headers.get('origin')}/Abonnement?payment=cancelled`,
        metadata: {
          userId: user.id,
          planType: planType
        }
      });
      
      console.log(`✅ Checkout Session erstellt: ${session.id}`);
      console.log(`   - URL: ${session.url}`);
      console.log('='.repeat(80));
      console.log('✅ ERFOLG');
      console.log('='.repeat(80) + '\n');

      return Response.json({ checkoutUrl: session.url });
      
    } catch (stripeError) {
      console.error('❌ Stripe API Fehler beim Erstellen der Session:');
      console.error('   - Type:', stripeError.type);
      console.error('   - Code:', stripeError.code);
      console.error('   - Message:', stripeError.message);
      console.error('   - Param:', stripeError.param);
      
      if (stripeError.raw) {
        console.error('   - Raw:', JSON.stringify(stripeError.raw, null, 2));
      }
      
      return Response.json({ 
        error: 'Fehler bei der Stripe-Session-Erstellung',
        details: stripeError.message
      }, { status: 500 });
    }
    
  } catch (error) {
    console.error('❌ UNERWARTETER FEHLER:');
    console.error('   - Name:', error.name);
    console.error('   - Message:', error.message);
    console.error('   - Stack:', error.stack);
    
    console.log('='.repeat(80));
    console.log('❌ FEHLER');
    console.log('='.repeat(80) + '\n');
    
    return Response.json({ 
      error: 'Ein unerwarteter Fehler ist aufgetreten',
      details: error.message
    }, { status: 500 });
  }
});