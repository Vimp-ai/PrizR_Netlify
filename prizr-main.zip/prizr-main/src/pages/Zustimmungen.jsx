import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, FileText, Mail, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Zustimmungen() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [newsletterOptIn, setNewsletterOptIn] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      // Falls User schon zugestimmt hat, weiterleiten
      if (currentUser.hasAcceptedTerms) {
        navigate(createPageUrl("Dashboard"));
      }
    } catch (error) {
      console.error("Fehler beim Laden der Benutzerdaten:", error);
      setError("Bitte melden Sie sich an.");
      // Zur Anmeldung weiterleiten
      setTimeout(() => {
        base44.auth.redirectToLogin(createPageUrl("Zustimmungen"));
      }, 2000);
    }
    setLoading(false);
  };

  const handleSubmit = async () => {
    if (!acceptedPrivacy || !acceptedTerms) {
      setError("Bitte akzeptieren Sie die Datenschutzerklärung und die AGB.");
      return;
    }

    setSaving(true);
    setError(null);

    try {
      await base44.auth.updateMe({
        hasAcceptedTerms: true,
        newsletterOptIn: newsletterOptIn,
        termsAcceptedDate: new Date().toISOString()
      });

      // Weiterleitung zur Bewertungsseite
      navigate(createPageUrl("Bewertung"));
    } catch (error) {
      console.error("Fehler beim Speichern der Zustimmungen:", error);
      setError("Die Zustimmungen konnten nicht gespeichert werden. Bitte versuchen Sie es erneut.");
    }

    setSaving(false);
  };

  if (loading) {
    return (
      <div className="p-8 max-w-2xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-700 rounded w-1/3"></div>
          <div className="h-64 bg-slate-800 rounded-xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 md:p-8">
      <div className="w-full max-w-2xl space-y-6">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-cyan-900 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-cyan-400" />
          </div>
          <h1 className="text-3xl font-bold text-slate-50 mb-2">Willkommen bei Prizr!</h1>
          <p className="text-slate-400">
            Um fortzufahren, benötigen wir Ihre Zustimmung zu folgenden Punkten:
          </p>
        </div>

        {error && (
          <Alert variant="destructive">
            <Shield className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-cyan-400" />
              Erforderliche Zustimmungen
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Datenschutz */}
            <div className="flex items-start space-x-3 p-4 bg-slate-800 rounded-lg border border-slate-700">
              <Checkbox
                id="privacy"
                checked={acceptedPrivacy}
                onCheckedChange={setAcceptedPrivacy}
                className="mt-1"
              />
              <div className="flex-1">
                <Label 
                  htmlFor="privacy" 
                  className="text-slate-100 font-medium cursor-pointer"
                >
                  Datenschutzerklärung akzeptieren *
                </Label>
                <p className="text-sm text-slate-400 mt-1">
                  Ich habe die{" "}
                  <a
                    href={createPageUrl("Datenschutz")}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cyan-400 hover:underline"
                  >
                    Datenschutzerklärung
                  </a>{" "}
                  gelesen und akzeptiere die Verarbeitung meiner Daten.
                </p>
              </div>
            </div>

            {/* AGB */}
            <div className="flex items-start space-x-3 p-4 bg-slate-800 rounded-lg border border-slate-700">
              <Checkbox
                id="terms"
                checked={acceptedTerms}
                onCheckedChange={setAcceptedTerms}
                className="mt-1"
              />
              <div className="flex-1">
                <Label 
                  htmlFor="terms" 
                  className="text-slate-100 font-medium cursor-pointer"
                >
                  Allgemeine Geschäftsbedingungen akzeptieren *
                </Label>
                <p className="text-sm text-slate-400 mt-1">
                  Ich akzeptiere die{" "}
                  <a
                    href={createPageUrl("AGB")}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cyan-400 hover:underline"
                  >
                    Allgemeinen Geschäftsbedingungen
                  </a>{" "}
                  von Prizr.
                </p>
              </div>
            </div>

            {/* Newsletter (Optional) */}
            <div className="flex items-start space-x-3 p-4 bg-slate-800/50 rounded-lg border border-slate-700">
              <Checkbox
                id="newsletter"
                checked={newsletterOptIn}
                onCheckedChange={setNewsletterOptIn}
                className="mt-1"
              />
              <div className="flex-1">
                <Label 
                  htmlFor="newsletter" 
                  className="text-slate-100 font-medium cursor-pointer flex items-center gap-2"
                >
                  <Mail className="w-4 h-4 text-slate-400" />
                  Newsletter abonnieren (optional)
                </Label>
                <p className="text-sm text-slate-400 mt-1">
                  Ich möchte Updates über neue Features und Angebote per E-Mail erhalten.
                  Sie können sich jederzeit wieder abmelden.
                </p>
              </div>
            </div>

            <div className="pt-4">
              <Button
                onClick={handleSubmit}
                disabled={!acceptedPrivacy || !acceptedTerms || saving}
                className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3"
              >
                {saving ? (
                  <>
                    <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Speichere...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Zustimmen und fortfahren
                  </>
                )}
              </Button>
            </div>

            <p className="text-xs text-slate-500 text-center">
              * Pflichtfelder - Diese Zustimmungen sind erforderlich, um Prizr nutzen zu können.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}