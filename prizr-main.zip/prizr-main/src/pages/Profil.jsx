
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { 
  User as UserIcon, 
  Mail,
  Crown,
  Calendar,
  Settings,
  Save,
  ArrowLeft,
  Shield,
  Gem,
  Zap,
  AlertTriangle
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import CancellationModal from "@/components/CancellationModal";

export default function Profil() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({ full_name: "" });
  const [success, setSuccess] = useState(null);
  const [error, setError] = useState(null);
  const [portalLoading, setPortalLoading] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      setFormData({ full_name: currentUser.full_name || "" });
    } catch (error) {
      setError("Fehler beim Laden der Benutzerdaten.");
    }
    setLoading(false);
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      await base44.auth.updateMe(formData);
      setSuccess("Profil erfolgreich aktualisiert!");
      await loadUser();
    } catch (error) {
      setError("Fehler beim Speichern der Änderungen.");
    }

    setSaving(false);
  };

  const handleManageSubscription = async () => {
    setPortalLoading(true);
    setError(null);
    
    try {
      const { data } = await base44.functions.invoke('createStripePortalSession');
      
      if (data.portalUrl) {
        window.location.href = data.portalUrl;
      } else {
        throw new Error("Keine Portal-URL erhalten.");
      }
    } catch (err) {
      console.error("Fehler beim Öffnen des Portals:", err);
      
      let errorMessage = "Fehler beim Öffnen des Abo-Portals.";
      
      if (err.response?.data?.details) {
        errorMessage = err.response.data.details;
      } else if (err.response?.data?.error) {
        errorMessage = err.response.data.error;
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      setError(errorMessage);
    } finally {
      setPortalLoading(false);
    }
  };

  const handleCancelSubscription = async () => {
    setCancelling(true);
    setError(null);
    
    try {
      const { data } = await base44.functions.invoke('createStripePortalSession');
      
      if (data.portalUrl) {
        window.location.href = data.portalUrl;
      } else {
        throw new Error("Keine Portal-URL erhalten.");
      }
    } catch (err) {
      console.error("Fehler beim Kündigen:", err);
      
      let errorMessage = "Fehler beim Kündigen des Abonnements.";
      
      if (err.response?.data?.details) {
        errorMessage = err.response.data.details;
      } else if (err.response?.data?.error) {
        errorMessage = err.response.data.error;
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      setError(errorMessage);
    } finally {
      setCancelling(false);
      setShowCancelModal(false);
    }
  };

  const getSubscriptionInfo = () => {
    if (!user) return null;
    
    switch (user.subscriptionType) {
      case 'pro':
        return {
          name: "Prizr Pro",
          color: "bg-gradient-to-r from-purple-600 to-pink-600",
          icon: <Crown className="w-5 h-5" />,
          price: "7,99€/Monat"
        };
      case 'enterprise':
        return {
          name: "Prizr Enterprise",
          color: "bg-gradient-to-r from-slate-700 to-slate-900",
          icon: <Shield className="w-5 h-5" />,
          price: "Individuell"
        };
      default:
        return {
          name: "Prizr Free",
          color: "bg-slate-700",
          icon: <Gem className="w-5 h-5" />,
          price: "Kostenlos"
        };
    }
  };

  const getUsageStats = () => {
    if (!user) return null;

    const type = user.subscriptionType || 'free';
    const currentMonth = new Date().toISOString().slice(0, 7);
    const monthlyUsed = user.lastValuationMonth === currentMonth ? (user.monthlyValuationsUsed || 0) : 0;

    switch (type) {
      case 'enterprise':
        if (user.customMonthlyLimit !== null && user.customMonthlyLimit !== undefined) {
          return {
            current: monthlyUsed,
            limit: user.customMonthlyLimit,
            description: "Bewertungen diesen Monat"
          };
        }
        return { 
          current: monthlyUsed, 
          limit: "∞", 
          description: "Unbegrenzte Bewertungen" 
        };
      case 'pro':
        return { 
          current: monthlyUsed, 
          limit: 30,
          description: "Bewertungen diesen Monat" 
        };
      default:
        return { 
          current: user.totalValuationsUsed || 0, 
          limit: 3,
          description: "Bewertungen gesamt" 
        };
    }
  };

  if (loading) {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-700 rounded w-1/3"></div>
          <div className="h-64 bg-slate-800 rounded-xl"></div>
        </div>
      </div>
    );
  }

  const subscriptionInfo = getSubscriptionInfo();
  const usageStats = getUsageStats();

  return (
    <>
      <CancellationModal
        isOpen={showCancelModal}
        onClose={() => setShowCancelModal(false)}
        onConfirm={handleCancelSubscription}
        loading={cancelling}
        subscriptionEndDate={user?.subscriptionEndDate}
      />

      <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-slate-50 flex items-center gap-2">
              <Settings className="w-6 h-6 text-cyan-400" />
              Mein Profil
            </h1>
            <p className="text-slate-400">Verwalten Sie Ihre persönlichen Daten und Ihr Abonnement</p>
          </div>
        </div>

        {success && (
          <Alert className="bg-teal-900/50 border-teal-700 text-teal-200">
            <Save className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserIcon className="w-5 h-5" />
              Persönliche Daten
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="full_name">Vollständiger Name</Label>
              <Input
                id="full_name"
                value={formData.full_name}
                onChange={(e) => setFormData(prev => ({ ...prev, full_name: e.target.value }))}
                placeholder="Ihr Name"
              />
            </div>

            <div className="space-y-2">
              <Label>E-Mail-Adresse</Label>
              <div className="flex items-center gap-2 p-3 bg-slate-800 rounded-md">
                <Mail className="w-4 h-4 text-slate-400" />
                <span className="text-slate-300">{user?.email}</span>
                <Badge variant="outline" className="ml-auto">
                  <Shield className="w-3 h-3 mr-1" />
                  Verifiziert
                </Badge>
              </div>
              <p className="text-xs text-slate-500">
                Ihre E-Mail-Adresse kann nicht geändert werden.
              </p>
            </div>

            <div className="flex justify-end">
              <Button 
                onClick={handleSave} 
                disabled={saving}
                className="bg-cyan-600 hover:bg-cyan-700"
              >
                {saving ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Speichern...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Änderungen speichern
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gem className="w-5 h-5" />
              Abonnement-Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className={`${subscriptionInfo.color} text-white p-6 rounded-xl`}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  {subscriptionInfo.icon}
                  <div>
                    <h3 className="text-xl font-bold">{subscriptionInfo.name}</h3>
                    <p className="text-white/80">{subscriptionInfo.price}</p>
                  </div>
                </div>
                <Badge className="bg-white/20 text-white border-white/30">
                  {user?.subscriptionType === 'free' ? 'Kostenlos' : 'Aktiv'}
                </Badge>
              </div>

              {user?.subscriptionEndDate && user.subscriptionType !== 'free' && (
                <div className="flex items-center gap-2 text-white/80">
                  <Calendar className="w-4 h-4" />
                  <span>Läuft bis: {format(new Date(user.subscriptionEndDate), 'dd.MM.yyyy')}</span>
                </div>
              )}
            </div>

            <Separator className="bg-slate-700" />

            <div>
              <h4 className="font-semibold text-slate-100 mb-3">Nutzungsstatistik</h4>
              <div className="bg-slate-800 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-300">{usageStats.description}</span>
                  <span className="font-bold text-slate-100">
                    {usageStats.current} / {usageStats.limit}
                  </span>
                </div>
                {usageStats.limit !== "∞" && (
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div 
                      className="bg-cyan-500 h-2 rounded-full" 
                      style={{ 
                        width: `${Math.min((usageStats.current / usageStats.limit) * 100, 100)}%` 
                      }}
                    ></div>
                  </div>
                )}
              </div>
            </div>

            {user?.subscriptionType !== 'free' ? (
              <div className="space-y-3">
                <div className="flex gap-3 justify-center">
                  <Button 
                    onClick={handleManageSubscription}
                    disabled={portalLoading || cancelling}
                    variant="outline"
                    className="px-6"
                  >
                    {portalLoading ? 'Lade...' : 'Zahlungsdaten verwalten'}
                  </Button>
                  <Button 
                    onClick={() => setShowCancelModal(true)}
                    disabled={cancelling || portalLoading}
                    variant="outline"
                    className="px-6 text-red-400 border-red-400 hover:bg-red-900/20"
                  >
                    {cancelling ? 'Lade...' : 'Abonnement kündigen'}
                  </Button>
                </div>
                <p className="text-xs text-slate-500 text-center">
                  Sie können Ihr Abonnement jederzeit kündigen oder Zahlungsdaten aktualisieren.
                </p>
              </div>
            ) : (
              <div className="text-center">
                <Button 
                  onClick={() => navigate(createPageUrl("Abonnement"))}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Jetzt upgraden
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle>Konto-Informationen</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-slate-400">Mitglied seit:</span>
                <div className="font-medium text-slate-100">
                  {user?.created_date ? format(new Date(user.created_date), 'dd.MM.yyyy') : 'N/A'}
                </div>
              </div>
              <div>
                <span className="text-slate-400">Benutzer-ID:</span>
                <div className="font-mono text-slate-100 text-xs">
                  {user?.id}
                </div>
              </div>
            </div>

            <Separator className="bg-slate-700" />

            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-slate-100">Konto-Sicherheit</h4>
                <p className="text-sm text-slate-400">Ihr Konto ist über Google Single Sign-On gesichert</p>
              </div>
              <Shield className="w-8 h-8 text-teal-400" />
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
