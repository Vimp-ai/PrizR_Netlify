
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/entities/User";
import { Valuation } from "@/entities/Valuation";
import { UploadFile } from "@/integrations/Core";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import ImageModal from "@/components/ImageModal";
import AnalysisProgressModal from "@/components/AnalysisProgressModal";
import AdditionalDetailsModal from "../components/AdditionalDetailsModal";
import {
  Camera,
  Loader2,
  Euro,
  Eye,
  ArrowLeft,
  Sparkles,
  AlertTriangle,
  UploadCloud,
  X,
  AlertTriangle as AlertTriangleIcon,
  Crown,
  Shield,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ReactMarkdown from 'react-markdown';
import { base44 } from "@/api/base44Client"; // Corrected: Import base44 explicitly

// NEU: Client-seitiges EXIF-Stripping
const stripExifFromFile = async (file) => {
  try {
    // Erstelle ein neues Canvas-Element
    const img = new Image();
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    // Lade das Bild
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
      img.src = URL.createObjectURL(file);
    });

    // Setze Canvas-Größe
    canvas.width = img.width;
    canvas.height = img.height;

    // Zeichne das Bild (entfernt automatisch EXIF)
    ctx.drawImage(img, 0, 0);

    // Konvertiere zurück zu Blob
    const blob = await new Promise((resolve) => {
      canvas.toBlob(resolve, 'image/jpeg', 0.95);
    });

    // Erstelle neue Datei ohne Metadaten
    const cleanedFile = new File([blob], file.name, {
      type: 'image/jpeg',
      lastModified: Date.now(),
    });

    URL.revokeObjectURL(img.src);
    console.log('✅ Client: EXIF-Metadaten entfernt');
    return cleanedFile;

  } catch (error) {
    console.warn('⚠️ Client: EXIF-Stripping fehlgeschlagen:', error.message);
    return file; // Fallback zum Original
  }
};

const cleanAiResponse = (text) => {
  if (typeof text !== 'string') return text;
  return text.replace(/\(Basierend auf [0-9]+ vergleichbaren Angeboten\)/gi, '')
             .replace(/Marktabgleich:/gi, '')
             .replace(/Objektinformationen/gi, '')
             .trim();
};

const fileToBase64 = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.readAsDataURL(file);
  reader.onload = () => resolve(reader.result);
  reader.onerror = error => reject(error);
});

const resizeImage = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 2048;
        const MAX_HEIGHT = 2048;
        let width = img.width;
        let height = img.height;

        if (width > MAX_WIDTH || height > MAX_HEIGHT) {
          const aspectRatio = width / height;
          if (width > height) {
            width = MAX_WIDTH;
            height = width / aspectRatio;
          } else {
            height = MAX_HEIGHT;
            width = height * aspectRatio;
          }
        }
        
        if (width > MAX_WIDTH) {
          height *= MAX_WIDTH / width;
          width = MAX_WIDTH;
        }
        if (height > MAX_HEIGHT) {
          width *= MAX_HEIGHT / height;
          height = MAX_HEIGHT;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (blob) {
              const cleanFileName = file.name
                .replace(/[äàáâãå]/g, 'a')
                .replace(/[öòóôõø]/g, 'o')
                .replace(/[üùúû]/g, 'u')
                .replace(/[ß]/g, 'ss')
                .replace(/[^a-zA-Z0-9.\-_]/g, '')
                .replace(/\s+/g, '_');

              const resizedFile = new File([blob], cleanFileName, {
                type: 'image/jpeg',
                lastModified: Date.now(),
              });
              resolve(resizedFile);
            } else {
              reject(new Error('Canvas to Blob conversion failed'));
            }
          },
          'image/jpeg',
          0.95
        );
      };
      img.onerror = reject;
    };
    reader.onerror = reject;
  });
};

export default function Bewertung() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [evaluating, setEvaluating] = useState(false);
  const [photos, setPhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({ woodType: "", age: "", origin: "", condition: 3 });
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [magnifiedImage, setMagnifiedImage] = useState(null);
  const [showAnalysisModal, setShowAnalysisModal] = useState(false);
  const [showAdditionalDetailsModal, setShowAdditionalDetailsModal] = useState(false);
  const [pendingValuation, setPendingValuation] = useState(null);
  const [submittingAdditionalPhotos, setSubmittingAdditionalPhotos] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      // Corrected: Use base44.auth.me() as per outline
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Failed to load user:", error);
      setError("Bitte melden Sie sich an, um den Service zu nutzen.");
    }
    setLoading(false);
  };

  const monthKey = () => new Date().toISOString().slice(0, 7);

  const canUseService = () => {
    if (!user) return false;
    const type = user.subscriptionType || 'free';

    if (type === 'enterprise') {
      if (user.customMonthlyLimit !== null && user.customMonthlyLimit !== undefined) {
        const currentMonth = new Date().toISOString().slice(0, 7);
        const monthlyUsed = (user.lastValuationMonth === currentMonth) ? (user.monthlyValuationsUsed || 0) : 0;
        return monthlyUsed < user.customMonthlyLimit;
      }
      return true;
    }

    if (type === 'pro') {
      const currentMonth = new Date().toISOString().slice(0, 7);
      const lastValuationMonth = user.lastValuationMonth;
      const monthlyUsed = (lastValuationMonth === currentMonth) ? (user.monthlyValuationsUsed || 0) : 0;
      return monthlyUsed < 30;
    }

    return (user.totalValuationsUsed || 0) < 3;
  };

  const handlePhotoUpload = async (event) => {
    if (photos.length >= 3) {
      setError("Sie können maximal 3 Fotos hochladen.");
      return;
    }
    const files = Array.from(event.target.files).slice(0, 3 - photos.length); 
    if (files.length === 0) return;

    setUploading(true);
    setError(null);

    // BILDVERKLEINERUNG & EXIF-STRIPPING
    const processedFilesPromises = files.map(async (file) => {
      const resized = await resizeImage(file);
      return await stripExifFromFile(resized); // NEU: EXIF entfernen
    });
    
    let processedFiles;
    try {
      processedFiles = await Promise.all(processedFilesPromises);
    } catch (error) {
      console.error("Fehler bei der Bildverarbeitung:", error);
      setError("Fehler bei der Bildverarbeitung: " + error.message);
      setUploading(false);
      return;
    }

    const newPhotosPromises = processedFiles.map(async (file) => {
      try {
        const base64String = await fileToBase64(file);
        return { file, base64: base64String, url: base64String, uploading: true, error: null };
      } catch (err) {
        console.error("Fehler bei der Dateiverarbeitung:", err);
        return null;
      }
    });

    const newPhotosInitial = (await Promise.all(newPhotosPromises)).filter(Boolean);
    
    setPhotos(prev => [...prev, ...newPhotosInitial]);

    const uploadWithRetry = async (photoEntry, maxRetries = 2) => {
      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          console.log(`🔄 Upload-Versuch ${attempt}/${maxRetries} für ${photoEntry.file.name}`);
          
          const uploadPromise = UploadFile({ file: photoEntry.file }); // Keep original UploadFile for now, as outline only specified for handleAdditionalPhotos
          const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Upload Timeout')), 10000)
          );
          
          const { file_url } = await Promise.race([uploadPromise, timeoutPromise]);
          
          console.log(`✅ Upload erfolgreich: ${file_url}`);
          return file_url;
          
        } catch (uploadError) {
          console.warn(`⚠️ Upload-Versuch ${attempt} fehlgeschlagen:`, uploadError.message);
          
          if (attempt === maxRetries) {
            console.log(`📝 Verwende Base64-Fallback für ${photoEntry.file.name}`);
            return null;
          }
          
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      }
      return null;
    };

    const uploadPromises = newPhotosInitial.map(async (photoEntry) => {
      const file_url = await uploadWithRetry(photoEntry);
      
      setPhotos(prevPhotos =>
        prevPhotos.map(p =>
          p.base64 === photoEntry.base64 ? { 
            ...p, 
            url: file_url || p.base64,
            uploading: false, 
            error: null
          } : p
        )
      );
    });

    await Promise.all(uploadPromises);
    
    const finalPhotos = await new Promise(resolve => {
      setTimeout(() => {
        setPhotos(current => {
          resolve(current);
          return current;
        });
      }, 100);
    });
    
    const allUsedBase64 = finalPhotos.every(p => 
      p.url === p.base64 && p.url.startsWith('data:')
    );
    
    if (allUsedBase64 && finalPhotos.length > 0) {
      console.log('ℹ️ Alle Bilder werden als Base64 verwendet (Upload-Server überlastet)');
      setError('ℹ️ Bilder werden direkt analysiert (Upload-server überlastet)');
      setTimeout(() => setError(null), 5000);
    }
    
    setUploading(false);
  };
  
  const removePhoto = (indexToRemove) => {
    setPhotos(currentPhotos => currentPhotos.filter((_, index) => index !== indexToRemove));
  };

  const getConditionText = (value) => {
    const conditions = { 1: "Neuwertig", 2: "Sehr gut", 3: "Gut", 4: "Gebrauchsspuren", 5: "Grenzwertig nutzbar" };
    return conditions[value] || "Unbekannt";
  };

  const handleEvaluation = async () => {
    console.log("--- Bewertungsprozess gestartet ---");
    console.log("1. Überprüfung der Fotos und des Dienststatus...");
    
    if (photos.length === 0) {
      console.error("Fehler: Keine Fotos hochgeladen.");
      setError("Bitte laden Sie mindestens ein Foto hoch.");
      return;
    }
    
    if (photos.some(p => p.uploading)) {
        console.error("Fehler: Bilder werden noch hochgeladen.");
        setError("Bitte warten Sie, bis alle Bilder verarbeitet sind.");
        return;
    }
    
    if (!canUseService()) {
      console.error("Fehler: Keine verfügbaren Bewertungen mehr.");
      setError("Sie haben keine verfügbaren Bewertungen mehr. Bitte upgraden Sie Ihr Abonnement.");
      return;
    }

    setEvaluating(true);
    setError(null);
    setShowAnalysisModal(true);

    try {
      console.log('2. Daten für die Backend-funktion vorbereitet.');
      
      const allBase64Images = photos.map(p => p.base64);
      const currentPhotoUrls = photos.map(p => 
        (p.url && p.url.startsWith('http')) ? p.url : p.base64
      );
      
      const userLanguage = navigator.language || 'de-DE';
      console.log(`🌍 Browser-Sprache: ${userLanguage}`);
      
      const payload = {
        allBase64Images: allBase64Images,
        allPhotoUrls: currentPhotoUrls,
        formData,
        subscriptionType: user?.subscriptionType,
        isFollowUp: false,
        previousAnalysis: null,
        userLanguage: userLanguage
      };
      
      console.log('3. Rufe Backend-funktion geminiValuation auf...');
      // Corrected: Use base44.functions.invoke as per outline
      const { data: response } = await base44.functions.invoke('geminiValuation', payload);
      console.log('4. Antwort von geminiValuation erhalten.');
      
      if (!response || Object.keys(response).length === 0 || !response.estimatedValue || !response.description) {
        console.error("5. Leere oder unvollständige Antwort von Gemini erhalten:", response);
        throw new Error("Es gab ein Problem bei der Bewertung. Bitte versuchen Sie es erneut oder wenden Sie sich an den Support.");
      }
      
      if (response.needsMoreInfo && response.specificDetailsNeeded && response.specificDetailsNeeded.length > 0) {
        console.log('5. Backend fordert zusätzliche Details an (needsMoreInfo ist true).');
        setPendingValuation(response);
        setShowAdditionalDetailsModal(true);
      } else {
        console.log('5. Backend hat finale Bewertung geliefert und gespeichert.');
        setResult(response);
        
        // Backend hat bereits den Zähler inkrementiert, lade User neu
        await loadUser(); // Corrected: Load user data to refresh counts
      }
      console.log('✅ --- Bewertungsprozess erfolgreich abgeschlossen ---');

    } catch (err) {
      console.error("5. Fehler bei der Backend-Kommunikation oder -Verarbeitung im Frontend:", err);
      
      if (err.response && err.response.data) {
        const errorData = err.response.data;
        if (errorData.suggestions) {
          setError(`${errorData.error}\n\nTipp: ${errorData.suggestions}`);
        } else {
          setError(errorData.error || "Die Bewertung ist fehlgeschlagen.");
        }
      } else if (err.message) {
        if (err.message.includes('Rate limit') || err.message.includes('429')) {
          setError("🚨 Die KI-Services sind überlastet.\n\nWir haben eine Basis-Bewertung für Sie erstellt. Für eine detailliertere Analyse versuchen Sie es bitte später erneut.");
        } else if (err.message.includes('Request too large')) {
          setError("Die Bilddateien sind zu groß. Verwenden Sie kleinere Bilder (unter 1MB) oder reduzieren Sie die Anzahl der Fotos.");
        } else {
          setError("Die Bewertung ist fehlgeschlagen. Bitte überprüfen Sie Ihre Internetverbindung und versuchen Sie es erneut.");
        }
      } else {
        setError("Ein unbekannter Fehler ist aufgetreten. Bitte versuchen Sie es später erneut.");
      }
      console.log('❌ --- Bewertungsprozess mit Fehler beendet ---');
    } finally {
      setShowAnalysisModal(false);
      setEvaluating(false);
    }
  };

  const handleAdditionalPhotos = async (additionalPhotoFiles) => {
    console.log("--- Prozess zur Präzisierung der Bewertung gestartet ---");
    setSubmittingAdditionalPhotos(true);
    setShowAdditionalDetailsModal(false);
    setShowAnalysisModal(true);

    try {
      console.log("2. Lade zusätzliche Fotos hoch...");
      
      const resizedAdditionalFilesPromises = additionalPhotoFiles.map(file => resizeImage(file));
      let resizedAdditionalFiles;
      try {
        resizedAdditionalFiles = await Promise.all(resizedAdditionalFilesPromises);
      } catch (error) {
        console.error("Fehler bei der Bildverkleinerung für zusätzliche Fotos:", error);
        setError("Fehler bei der Verarbeitung der zusätzlichen Bilder: " + error.message);
        setSubmittingAdditionalPhotos(false);
        setShowAnalysisModal(false);
        setShowAdditionalDetailsModal(true);
        return;
      }

      // NEU: EXIF auch aus zusätzlichen Bildern entfernen
      const cleanedAdditionalFiles = await Promise.all(
        resizedAdditionalFiles.map(file => stripExifFromFile(file))
      );

      // Corrected: Use base44.integrations.Core.UploadFile as per outline
      const uploadPromises = cleanedAdditionalFiles.map(file => base44.integrations.Core.UploadFile({ file }));
      const uploadedPhotos = await Promise.all(uploadPromises);
      const additionalPhotoUrls = uploadedPhotos.map(res => res.file_url);

      const originalPhotoUrls = photos.map(p => (p.url && p.url.startsWith('http')) ? p.url : p.base64);
      const allPhotoUrls = [...originalPhotoUrls, ...additionalPhotoUrls];

      const existingPhotosBase64 = photos.map(p => p.base64);
      const newAdditionalPhotosBase64Promises = cleanedAdditionalFiles.map(file => fileToBase64(file));
      const newAdditionalPhotosBase64 = await Promise.all(newAdditionalPhotosBase64Promises);
      const allBase64Images = [...existingPhotosBase64, ...newAdditionalPhotosBase64];

      console.log("3. Rufe Backend-Funktion geminiValuation (Follow-up) erneut auf...");
      
      const payload = {
        allBase64Images: allBase64Images,
        allPhotoUrls: allPhotoUrls,
        formData,
        subscriptionType: user?.subscriptionType,
        isFollowUp: true,
        previousAnalysis: pendingValuation,
        userLanguage: navigator.language || 'de-DE'
      };
      
      // Corrected: Use base44.functions.invoke as per outline
      const { data: response } = await base44.functions.invoke('geminiValuation', payload);
      console.log('4. Antwort von geminiValuation (Follow-up) erhalten.');
      
      if (!response || Object.keys(response).length === 0 || !response.estimatedValue || !response.description) {
        console.error("5. Leere oder unvollständige Follow-up-Antwort von Gemini erhalten:", response);
        throw new Error("Es gab ein Problem bei der Verfeinerung der Bewertung. Bitte versuchen Sie es erneut oder wenden Sie sich an den Support.");
      }

      console.log("5. Backend hat Follow-up-Bewertung geliefert und aktualisiert.");
      setResult(response);
      setPendingValuation(null);

      // Backend hat bereits den Zähler inkrementiert, lade User neu
      await loadUser(); // Corrected: Load user data to refresh counts

      console.log('✅ --- Prozess zur Präzisierung erfolgreich abgeschlossen ---');

    } catch (err) {
      console.error("5. Fehler bei der Follow-up-Bewertung im Frontend:", err);
      
      if (err.response && err.response.data) {
        const errorData = err.response.data;
        setError(errorData.error || "Die erweiterte Bewertung ist fehlgeschlagen.");
      } else {
        setError("Die erweiterte Bewertung ist fehlgeschlagen. Bitte versuchen Sie es später erneut.");
      }
      console.log('❌ --- Prozess zur Präzisierung mit Fehler beendet ---');
      setShowAdditionalDetailsModal(true);
    } finally {
      setShowAnalysisModal(false);
      setSubmittingAdditionalPhotos(false);
    }
  };

  const getSafeParsedObject = (data, fallback = {}) => {
    if (typeof data === 'object' && data !== null) {
      return data;
    }
    if (typeof data === 'string') {
      try {
        const parsed = JSON.parse(data);
        return typeof parsed === 'object' && parsed !== null ? parsed : fallback;
      } catch (e) {
        return fallback;
      }
    }
    return fallback;
  };

  const getSafeParsedArray = (data) => {
    const obj = getSafeParsedObject(data, []);
    return Array.isArray(obj) ? obj : [];
  };

  if (loading) {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-700 rounded w-1/3"></div>
          <div className="h-64 bg-slate-800 rounded-xl"></div>
        </div>
      </div>
    );
  }

  if (result) {
    const displayedOriginalInfo = getSafeParsedObject(result.originalInfo);
    const displayedAlternativeIdentifications = getSafeParsedArray(result.alternativeIdentifications);
    const displayedDesignerCandidates = getSafeParsedArray(result.designerCandidates);

    const displayedManufacturer = result.manufacturer || result.likelyManufacturer || result.manufacturerReasoning || 'Nicht identifiziert';
    const displayedDesigner = result.primaryDesigner || result.likelyDesigner || (displayedDesignerCandidates.length > 0 ? displayedDesignerCandidates[0].designer : 'Nicht identifiziert');

    return (
      <>
        <ImageModal src={magnifiedImage} onClose={() => setMagnifiedImage(null)} />
        <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
          <div className="flex items-center gap-4 mb-6">
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                setResult(null);
                setPhotos([]);
                setFormData({ woodType: "", age: "", origin: "", condition: 3 });
                setError(null);
              }}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-slate-50">Bewertungsergebnis</h1>
              <p className="text-slate-400">Ihre professionelle Wertschätzung</p>
            </div>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {displayedDesignerCandidates.length > 0 && (
            <Card className="bg-slate-900 border-slate-800 shadow-lg">
              <CardHeader className="border-b border-slate-800">
                <CardTitle className="text-lg font-bold text-slate-100">Identifizierte Designer-Kandidaten</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {displayedDesignerCandidates.slice(0, 3).map((candidate, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border ${
                        index === 0 ? 'bg-teal-900/20 border-teal-700' :
                        index === 1 ? 'bg-cyan-900/20 border-cyan-700' :
                        'bg-slate-800/50 border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {index === 0 && <Crown className="w-5 h-5 text-teal-400" />}
                          <h3 className="font-semibold text-slate-100">{candidate.designer}</h3>
                        </div>
                        <Badge className={`${
                          candidate.confidence >= 70 ? 'bg-teal-900 text-teal-200 border-teal-700' :
                          candidate.confidence >= 40 ? 'bg-yellow-900 text-yellow-200 border-yellow-700' :
                          'bg-slate-800 text-slate-300 border-slate-700'
                        }`}>
                          {candidate.confidence}% sicher
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-400 mb-2">{candidate.reasoning}</p>
                      {candidate.specificFeatures && (
                        <p className="text-xs text-slate-500">
                          <strong>Merkmale:</strong> {candidate.specificFeatures}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {result.isNotFurniture && (
            <Alert variant="destructive" className="mb-6 bg-red-900/20 border-red-700 text-red-200">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Hinweis:</strong> Unser System hat erkannt, dass es sich bei Ihrem Artikel möglicherweise nicht um ein Möbelstück handelt. Die Bewertung ist daher möglicherweise ungenau.
              </AlertDescription>
            </Alert>
          )}

          {displayedAlternativeIdentifications.length > 0 && (
            <div className="mb-6 p-4 bg-slate-900/20 border border-slate-700 rounded-lg">
              <h3 className="font-semibold text-slate-100 mb-2">Mögliche alternative Identifikationen:</h3>
              <ul className="list-disc list-inside text-sm text-slate-300 space-y-2">
                {displayedAlternativeIdentifications.map((item, index) => (
                  <li key={index}>
                    <span className="font-medium">{item.style}</span> ({item.confidence}% sicher)
                    <p className="pl-5 text-slate-400 text-xs">{item.reasoning}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-teal-800 shadow-xl">
            <CardContent className="p-8">
              <div className="flex flex-col lg:flex-row items-start justify-between mb-6 gap-6">
                <div className="flex-1">
                  <div className="mb-4">
                    <h3 className="text-lg font-semibold text-slate-100 mb-2">Angebotspreis (Marktpreis)</h3>
                    <div className="flex items-center gap-2 mb-2">
                      <Euro className="w-8 h-8 text-teal-400" />
                      <span className="text-3xl font-bold text-teal-400">
                        {result.estimatedValue?.toLocaleString('de-DE', { 
                          style: 'currency', 
                          currency: 'EUR', 
                          maximumFractionDigits: 0 
                        })}
                      </span>
                    </div>
                    <p className="text-teal-300 text-sm">
                      Durchschnittlicher Marktpreis
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-slate-100 mb-2">Realistischer Verkaufspreis</h3>
                    <div className="flex items-center gap-2 mb-2">
                      <Euro className="w-8 h-8 text-cyan-400" />
                      <span className="text-3xl font-bold text-cyan-400">
                        {result.realisticPrice?.toLocaleString('de-DE', { 
                          style: 'currency', 
                          currency: 'EUR', 
                          maximumFractionDigits: 0 
                        })}
                      </span>
                    </div>
                    <p className="text-cyan-300 text-sm">
                      Inkl. Zustand & Handelsspanne
                    </p>
                  </div>
                  
                  <p className="text-slate-400 mt-4">
                    Wertspanne: {result.valueRange}
                  </p>
                </div>
                
                <div className="flex flex-col gap-2 items-start lg:items-end">
                  <Badge className={`${
                    result.confidence === 'high' ? 'bg-teal-900 text-teal-200 border-teal-700' :
                    result.confidence === 'medium' ? 'bg-yellow-900 text-yellow-200 border-yellow-700' :
                    'bg-orange-900 text-orange-200 border-orange-700'
                  }`}>
                    {result.confidence === 'high' && '🎯 Hohe Sicherheit'}
                    {result.confidence === 'medium' && '⚡ Gute Schätzung'}
                    {result.confidence === 'low' && '📊 Grobe Schätzung'}
                  </Badge>
                  
                  {result.isReplica && (
                    <Badge className="bg-orange-900 text-orange-200 border-orange-700">
                      ⚠️ Möglicherweise Replika
                    </Badge>
                  )}
                </div>
              </div>

              {result.isReplica && displayedOriginalInfo && Object.keys(displayedOriginalInfo).length > 0 && (
                <div className="mb-6 p-4 bg-orange-900/20 border border-orange-700 rounded-lg">
                  <h3 className="font-semibold text-orange-200 mb-2">🔍 Replika-Analyse</h3>
                  <div className="space-y-2 text-sm">
                    {displayedOriginalInfo.estimatedOriginalValue && (
                      <p className="text-slate-300">
                        <strong>Original-Wert:</strong> {displayedOriginalInfo.estimatedOriginalValue.toLocaleString('de-DE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 })}
                      </p>
                    )}
                    {displayedOriginalInfo.recognitionFeatures && (
                      <p className="text-slate-300">
                        <strong>Original erkennen an:</strong> {displayedOriginalInfo.recognitionFeatures}
                      </p>
                    )}
                    {displayedOriginalInfo.replicaIndicators && (
                      <p className="text-slate-300">
                        <strong>Replika-Hinweise:</strong> {displayedOriginalInfo.replicaIndicators}
                      </p>
                    )}
                  </div>
                </div>
              )}

              <Separator className="my-6 bg-slate-700" />

              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-slate-100 mb-2">Beschreibung</h3>
                  <p className="text-slate-300">{result.description}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-100 mb-2">Stil</h3>
                  <p className="text-slate-300">{result.identifiedStyle}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-100 mb-2">Wahrscheinlicher Hersteller</h3>
                  <p className="text-slate-300">{displayedManufacturer}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-100 mb-2">Wahrscheinlicher Designer</h3>
                  <p className="text-slate-300">{displayedDesigner}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-100 mb-2">Bewertungsgrundlage</h3>
                  <div className="prose prose-sm prose-invert max-w-none">
                    <ReactMarkdown className="text-slate-300">
                      {cleanAiResponse(result.reasoning)}
                    </ReactMarkdown>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {(result.forgeryDetection || result.additionalInfo) && (
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader><CardTitle>Zusätzliche Analysen</CardTitle></CardHeader>
              <CardContent className="space-y-6">

                {result.forgeryDetection && (
                  <div>
                    <h3 className="font-semibold text-slate-100 mb-2">Fälschungserkennung</h3>
                    <p className="text-slate-300">{result.forgeryDetection}</p>
                  </div>
                )}

                {result.additionalInfo && (
                  <div>
                    <Separator className="bg-slate-700 my-4"/>
                    <h3 className="font-semibold text-slate-100 mb-2">Weitere Informationen zu diesem Möbeltyp</h3>
                    <p className="text-slate-300">{result.additionalInfo}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <Card className="bg-slate-900 border-slate-800">
            <CardHeader><CardTitle>Analysierte Fotos</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {photos.map((photo, index) => (
                  <div key={index} className="relative group space-y-2 cursor-pointer" onClick={() => setMagnifiedImage(photo.url)}>
                    <img 
                      src={photo.base64} 
                      alt={`Vorschau ${index}`} 
                      className={`w-full h-24 object-cover rounded-lg border ${
                          photo.error ? 'border-red-500' :
                          'border-slate-700'
                        }`} 
                    />
                    <button
                        onClick={() => removePhoto(index)}
                        className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    {photo.uploading && (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-lg">
                        <Loader2 className="w-6 h-6 animate-spin text-white" />
                      </div>
                    )}
                    {photo.error && !photo.uploading && (
                      <div className="absolute inset-0 bg-red-900/50 flex items-center justify-center rounded-lg" title={photo.error}>
                        <AlertTriangleIcon className="w-6 h-6 text-red-300" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="flex flex-col md:flex-row gap-4">
            <Button onClick={() => navigate(createPageUrl("Dashboard"))} className="flex-1 bg-cyan-600 hover:bg-cyan-700">Zum Dashboard</Button>
            <Button onClick={() => navigate(createPageUrl("Historie"))} variant="outline" className="flex-1">Alle Bewertungen anzeigen</Button>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <ImageModal src={magnifiedImage} onClose={() => setMagnifiedImage(null)} />
      <AnalysisProgressModal 
        isOpen={showAnalysisModal} 
        subscriptionType={user?.subscriptionType || 'free'}
        firstPhotoUrl={photos.length > 0 ? photos[0].url : null}
        photoCount={photos.length}
        hasPro={user?.subscriptionType === 'pro'}
      />
      
      <AdditionalDetailsModal
        isOpen={showAdditionalDetailsModal}
        onClose={() => {
          setShowAdditionalDetailsModal(false);
          if (pendingValuation) {
            setResult(pendingValuation);
            setPendingValuation(null);
            // Removed client-side user data update.
            // If the user closes the modal without submitting additional photos,
            // the valuation is considered "used" and should have been counted by the backend
            // when the initial `geminiValuation` call returned `needsMoreInfo`.
            // The `loadUser` call occurs after a successful *follow-up* valuation in `handleAdditionalPhotos`.
            // No action needed here for counter.
          }
        }}
        onSubmitAdditionalPhotos={handleAdditionalPhotos}
        alternativeIdentifications={getSafeParsedArray(pendingValuation?.alternativeIdentifications)}
        specificDetailsNeeded={getSafeParsedArray(pendingValuation?.specificDetailsNeeded)}
        loading={submittingAdditionalPhotos}
      />
      
      <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Dashboard"))}><ArrowLeft className="w-4 h-4" /></Button>
          <div>
            <h1 className="text-2xl font-bold text-slate-50 brand-text">Neue Bewertung</h1>
            <p className="text-slate-400">Fotografieren Sie Ihr Möbelstück</p>
          </div>
        </div>

        {error && <Alert variant="destructive"><AlertTriangle className="h-4 w-4" /><AlertDescription>{error}</AlertDescription></Alert>}

        {!canUseService() && (
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Sie haben keine verfügbaren Bewertungen mehr.
              <Button variant="link" className="p-0 h-auto ml-1 text-cyan-400" onClick={() => navigate(createPageUrl("Abonnement"))}>Jetzt upgraden</Button>
            </AlertDescription>
          </Alert>
        )}

        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5" />
              Fotos aufnehmen oder hochladen
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 ${photos.length >= 3 ? 'border-slate-800 bg-slate-900/50 cursor-not-allowed' : 'border-slate-700 hover:border-cyan-600'}`}>
              <UploadCloud className="mx-auto h-12 w-12 text-slate-500" />
              <h3 className="mt-4 text-lg font-semibold text-slate-100">Fotos hochladen (max. 3)</h3>
              <p className="mt-1 text-sm text-slate-400">Mehrere Perspektiven verbessern die Analyse erheblich.</p>
              <input 
                type="file" 
                multiple 
                accept="image/jpeg, image/png"
                onChange={handlePhotoUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                id="multi-photo-upload"
                disabled={uploading || photos.length >= 3}
              />
            </div>
            
            {uploading && (
                <div className="flex items-center justify-center gap-2 text-slate-400">
                    <Loader2 className="w-4 h-4 animate-spin"/>
                    <span>Bilder werden verarbeitet...</span>
                </div>
            )}

            {photos.length > 0 && (
              <div>
                <Label className="font-semibold">Hochgeladene Fotos ({photos.length} / 3):</Label>
                <div className="mt-2 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
                  {photos.map((photo, index) => (
                    <div key={index} className="relative group">
                      <img 
                        src={photo.base64} 
                        alt={`Vorschau ${index}`} 
                        className={`w-full h-24 object-cover rounded-lg border ${
                          photo.error ? 'border-red-500' : 'border-slate-700'
                        }`} 
                      />
                      <button
                        onClick={() => removePhoto(index)}
                        className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-3 h-3" />
                      </button>
                      {photo.uploading && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-lg">
                          <Loader2 className="w-6 h-6 animate-spin text-white" />
                        </div>
                      )}
                      {photo.error && !photo.uploading && (
                        <div className="absolute inset-0 bg-red-900/50 flex items-center justify-center rounded-lg" title={photo.error}>
                          <AlertTriangleIcon className="w-6 h-6 text-red-300" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardHeader><CardTitle className="flex items-center gap-2"><Eye className="w-5 h-5" />Zusätzliche Informationen</CardTitle></CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2"><Label htmlFor="woodType">Material / Holzart</Label><Input id="woodType" placeholder="z.B. Eiche, Teak, Buche..." value={formData.woodType} onChange={(e) => setFormData(prev => ({ ...prev, woodType: e.target.value }))}/></div>
              <div className="space-y-2"><Label htmlFor="age">Geschätztes Alter</Label><Input id="age" placeholder="z.B. 1960er, ~50 Jahre, Antik..." value={formData.age} onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}/></div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="origin">Weitere Informationen zum Schätzchen</Label>
                <Input id="origin" placeholder="z.B. Erbstück von Großmutter, auf Flohmarkt gefunden..." value={formData.origin} onChange={(e) => setFormData(prev => ({ ...prev, origin: e.target.value }))}/>
                <p className="text-xs text-slate-500 mt-1 flex items-start gap-1">
                  <Shield className="w-3 h-3 mt-0.5 flex-shrink-0" />
                  Bitte geben Sie hier keine persönlichen Daten (Namen, Adressen o.ä.) ein.
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <Label>Zustand: {getConditionText(formData.condition)}</Label>
              <Slider value={[formData.condition]} onValueChange={(value) => setFormData(prev => ({ ...prev, condition: value[0] }))} max={5} min={1} step={1} className="w-full"/>
              <div className="flex justify-between text-xs text-slate-400"><span>Neuwertig</span><span>Sehr gut</span><span>Gut</span><span>Gebrauchsspuren</span><span>Grenzwertig</span></div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-slate-800 to-slate-900 border-cyan-800">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div><h3 className="font-semibold text-slate-100 mb-1 brand-text">Bereit für die Bewertung?</h3><p className="text-slate-400 text-sm">Unsere KI analysiert Ihre Fotos und erstellt eine professionelle Wertschätzung.</p></div>
              <Button size="lg" onClick={handleEvaluation} disabled={photos.length === 0 || !canUseService() || evaluating || uploading || photos.some(p => p.uploading)} className="bg-cyan-600 hover:bg-cyan-700 text-white px-8 flex items-center gap-2 min-w-[220px] justify-center">
                {evaluating ? (
                  <><Loader2 className="w-5 h-5 animate-spin" />Analysiere...</>
                ) : (<><Sparkles className="w-5 h-5" />Jetzt bewerten lassen</>)}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
