
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@16.12.0';

function getPlanFromPriceId(priceId) {
    const priceIdPro = Deno.env.get("STRIPE_PRICE_ID_PRO");
    if (priceId === priceIdPro) return 'pro';
    return 'free';
}

Deno.serve(async (req) => {
    console.log('\n' + '='.repeat(80));
    console.log('🔔 STRIPE WEBHOOK EVENT EMPFANGEN');
    console.log('='.repeat(80));
    
    try {
        const stripeSecretKey = Deno.env.get("STRIPE_SECRET_KEY");
        const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
        
        if (!stripeSecretKey || !webhookSecret) {
            console.error('❌ Stripe Konfiguration fehlt');
            return Response.json({ error: 'Stripe Konfiguration fehlt' }, { status: 500 });
        }

        const stripe = new Stripe(stripeSecretKey); // API-Version entfernt, verwendet nun Account-Standard
        const body = await req.text();
        const sig = req.headers.get('stripe-signature');

        let event;
        try {
            event = stripe.webhooks.constructEvent(body, sig, webhookSecret);
            console.log(`✅ Webhook signature verifiziert`);
            console.log(`   - Event Type: ${event.type}`);
            console.log(`   - Event ID: ${event.id}`);
        } catch (err) {
            console.error('❌ Webhook signature verification failed:', err.message);
            return Response.json({ error: 'Invalid signature' }, { status: 400 });
        }

        const base44 = createClientFromRequest(req);
        
        const eventObject = event.data.object; 
        let customerId;

        // Bestimme customerId basierend auf Event-Typ
        if (event.type.startsWith('customer.subscription.')) {
            customerId = eventObject.customer;
        } else if (event.type.startsWith('checkout.session.')) {
            customerId = eventObject.customer;
        } else {
            customerId = eventObject.customer;
        }
        
        if (!customerId) {
            console.error(`❌ Keine Customer ID im Stripe Event gefunden: ${event.type}`);
            return Response.json({ error: 'Customer ID not found in event' }, { status: 400 });
        }
        
        console.log(`   - Customer ID: ${customerId}`);

        // Finde User anhand der Stripe Customer ID
        console.log('🔍 Suche User in Datenbank...');
        const users = await base44.asServiceRole.entities.User.filter({ stripeCustomerId: customerId });
        if (!users || users.length === 0) {
            console.error(`❌ Kein Benutzer für Stripe Customer ID gefunden: ${customerId}`);
            return Response.json({ error: 'User not found' }, { status: 404 });
        }
        const user = users[0];
        console.log(`✅ User gefunden: ${user.email}`);

        switch (event.type) {
            case 'checkout.session.completed': {
                const session = eventObject;
                const metadata = session.metadata || {};
                const planType = metadata.planType;
                
                console.log(`📦 Checkout abgeschlossen für Plan: ${planType}`);

                // Wenn es ein Bewertungspaket ist
                if (planType === 'pack_5') {
                    const currentTotal = user.totalValuationsUsed || 0;
                    const newTotal = Math.max(0, currentTotal - 5);
                    
                    await base44.asServiceRole.entities.User.update(user.id, {
                        totalValuationsUsed: newTotal
                    });
                    
                    console.log(`✅ 5 Bewertungen hinzugefügt für ${user.email}`);
                    console.log(`   - Vorher: ${currentTotal} genutzt`);
                    console.log(`   - Nachher: ${newTotal} genutzt`);
                    console.log(`   - Verfügbar: ${7 - newTotal} von 7`);
                    
                } else if (planType === 'pack_20') {
                    const currentTotal = user.totalValuationsUsed || 0;
                    const newTotal = Math.max(0, currentTotal - 20);
                    
                    await base44.asServiceRole.entities.User.update(user.id, {
                        totalValuationsUsed: newTotal
                    });
                    
                    console.log(`✅ 20 Bewertungen hinzugefügt für ${user.email}`);
                    console.log(`   - Vorher: ${currentTotal} genutzt`);
                    console.log(`   - Nachher: ${newTotal} genutzt`);
                    console.log(`   - Verfügbar: ${7 - newTotal} von 7`);
                }
                break;
            }

            case 'customer.subscription.created':
            case 'customer.subscription.updated': {
                const subscription = eventObject;
                
                if (!subscription.items || subscription.items.data.length === 0) {
                    console.error('❌ Subscription has no items:', subscription);
                    return Response.json({ error: 'Subscription has no items' }, { status: 400 });
                }
                
                const planType = getPlanFromPriceId(subscription.items.data[0].price.id);
                const endDate = new Date(subscription.current_period_end * 1000).toISOString().split('T')[0];

                await base44.asServiceRole.entities.User.update(user.id, {
                    subscriptionType: planType,
                    subscriptionEndDate: endDate
                });
                
                console.log(`✅ Abo für ${user.email} auf ${planType} bis ${endDate} aktualisiert`);
                break;
            }

            case 'customer.subscription.deleted': {
                await base44.asServiceRole.entities.User.update(user.id, {
                    subscriptionType: 'free',
                    subscriptionEndDate: null
                });
                
                console.log(`✅ Abo für ${user.email} gekündigt und auf 'free' zurückgesetzt`);
                break;
            }

            default:
                console.log(`ℹ️ Unbehandeltes Stripe Event: ${event.type}`);
        }

        console.log('='.repeat(80));
        console.log('✅ WEBHOOK ERFOLGREICH VERARBEITET');
        console.log('='.repeat(80) + '\n');
        
        return Response.json({ received: true });

    } catch (error) {
        console.error('❌ WEBHOOK ERROR:');
        console.error('   - Name:', error.name);
        console.error('   - Message:', error.message);
        console.error('   - Stack:', error.stack);
        
        console.log('='.repeat(80));
        console.log('❌ WEBHOOK FEHLER');
        console.log('='.repeat(80) + '\n');
        
        return Response.json({ error: error.message }, { status: 500 });
    }
});
