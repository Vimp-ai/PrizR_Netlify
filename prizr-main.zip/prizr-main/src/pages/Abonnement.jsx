
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Crown, 
  Check, 
  Star,
  ArrowLeft,
  Gem,
  X,
  ArrowRight,
  History,
  TrendingUp,
  Zap,
  ShoppingCart,
  AlertTriangle
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import CancellationModal from "@/components/CancellationModal";

export default function Abonnement() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [totalValuations, setTotalValuations] = useState(0);
  const [stats, setStats] = useState({ total: 0, thisMonth: 0 });
  const [cancelling, setCancelling] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Implementierung der Zähler-Logik, die nur auf Backend-Daten basiert.
      // Die Zähler werden direkt aus dem `currentUser`-Objekt bezogen,
      // anstatt alle Bewertungen clientseitig zu filtern.
      const currentMonth = new Date().toISOString().slice(0, 7); // Format "YYYY-MM"

      const totalValuationsFromUser = currentUser.totalValuationsUsed || 0;
      setTotalValuations(totalValuationsFromUser);

      const thisMonthValuationsFromUser = (currentUser.lastValuationMonth === currentMonth)
        ? (currentUser.monthlyValuationsUsed || 0)
        : 0;
      
      setStats({
        total: totalValuationsFromUser,
        thisMonth: thisMonthValuationsFromUser
      });

    } catch (error) {
      console.error("Fehler beim Laden der Daten:", error);
      setError("Daten konnten nicht geladen werden. Bitte versuchen Sie es später erneut.");
    }
    setLoading(false);
  };

  const handleCancelSubscription = async () => {
    setCancelling(true);
    setError(null);
    
    try {
      const { data } = await base44.functions.invoke('createStripePortalSession');
      
      if (data.portalUrl) {
        window.location.href = data.portalUrl;
      } else {
        throw new Error("Keine Portal-URL erhalten.");
      }
    } catch (error) {
      console.error("Fehler beim Kündigen:", error);
      
      let errorMessage = "Die Kündigung konnte nicht durchgeführt werden.";
      
      if (error.response?.data?.details) {
        errorMessage = error.response.data.details;
      } else if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      setError(errorMessage);
    } finally {
      setCancelling(false);
      setShowCancelModal(false);
    }
  };

  const plans = [
    {
      id: 'free',
      name: 'Prizr Free',
      price: 0,
      period: 'Kostenlos',
      icon: <Gem className="w-6 h-6" />,
      color: 'bg-slate-800 border-slate-700',
      headerColor: 'bg-slate-700',
      features: [
        { text: '3 kostenlose Bewertungen', included: true },
        { text: 'KI-gestützte Analyse', included: true },
        { text: 'Designer-Identifikation', included: true },
        { text: 'Marktwert-Schätzung', included: true },
        { text: 'Historie-Funktion', included: true }
      ],
      limitations: 'Gesamt 3 freie Bewertungen'
    },
    {
      id: 'pro',
      name: 'Prizr Pro',
      price: 4.99,
      period: '/ Monat',
      icon: <Crown className="w-6 h-6" />,
      color: 'bg-gradient-to-br from-cyan-600 to-teal-600 border-cyan-500',
      headerColor: 'bg-gradient-to-r from-cyan-500 to-teal-500',
      popular: true,
      features: [
        { text: '30 Bewertungen pro Monat', included: true },
        { text: 'KI-gestützte Analyse', included: true },
        { text: 'Designer-Identifikation', included: true },
        { text: 'Marktwert-Schätzung', included: true },
        { text: 'Historie-Funktion', included: true },
        { text: 'Prioritäts-Support', included: true }
      ],
      limitations: 'Monatlich kündbar'
    },
    {
      id: 'enterprise',
      name: 'Prizr Enterprise',
      price: null,
      period: 'Kontakt',
      icon: <Star className="w-6 h-6" />,
      color: 'bg-slate-900 border-slate-700',
      headerColor: 'bg-slate-800',
      features: [
        { text: 'Unbegrenzte Bewertungen', included: true },
        { text: 'Prioritäts-Support', included: true },
        { text: 'Team-Accounts', included: true },
        { text: 'SLA & Datenschutz auf Anfrage', included: true }
      ],
      limitations: 'Bitte kontaktieren Sie uns für ein Angebot'
    }
  ];

  const valuationPacks = [
    { count: 5, price: 1.99, popular: false },
    { count: 20, price: 3.99, popular: true }
  ];

  if (loading) {
    return (
      <div className="p-8 max-w-6xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-700 rounded w-1/3"></div>
          <div className="grid md:grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <div key={i} className="h-96 bg-slate-800 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const currentPlan = user?.subscriptionType || 'free';

  return (
    <>
      <CancellationModal
        isOpen={showCancelModal}
        onClose={() => setShowCancelModal(false)}
        onConfirm={handleCancelSubscription}
        loading={cancelling}
        subscriptionEndDate={user?.subscriptionEndDate}
      />

      <div className="p-4 md:p-8 max-w-6xl mx-auto space-y-6">
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-slate-50">Wählen Sie Ihren Plan</h1>
            <p className="text-slate-400">Finden Sie das perfekte Abonnement für Ihre Bedürfnisse</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="bg-slate-900 border-slate-800 shadow-lg hover:shadow-cyan-500/10 hover:border-cyan-800 transition-all duration-300">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-slate-400">Bewertungen gesamt</CardTitle>
                <History className="w-5 h-5 text-cyan-500" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-50">{totalValuations}</div>
              <p className="text-sm text-slate-400 mt-1">
                {stats.thisMonth} diesen Monat
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-900 border-slate-800 shadow-lg hover:shadow-cyan-500/10 hover:border-cyan-800 transition-all duration-300">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-slate-400">Status</CardTitle>
                <TrendingUp className="w-5 h-5 text-cyan-500" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold text-slate-50">
                {(() => {
                  const type = user?.subscriptionType || 'free';
                  if (type === 'enterprise') return 'Enterprise Aktiv';
                  if (type === 'pro') {
                    const current = new Date().toISOString().slice(0, 7);
                    const used = user.lastValuationMonth === current ? (user.monthlyValuationsUsed || 0) : 0;
                    return `Pro Aktiv (${used}/30)`;
                  }
                  const freeUsed = user?.totalValuationsUsed || 0;
                  return freeUsed < 3 ? `Free Aktiv (${freeUsed}/3)` : 'Limit erreicht';
                })()}
              </div>
              <p className="text-sm text-slate-400 mt-1">
                {(() => {
                  const type = user?.subscriptionType || 'free';
                  if (type === 'enterprise') return 'Unbegrenzte Bewertungen';
                  if (type === 'pro') {
                    const current = new Date().toISOString().slice(0, 7);
                    const used = user.lastValuationMonth === current ? (user.monthlyValuationsUsed || 0) : 0;
                    return `Noch ${30 - used} Bewertungen diesen Monat`;
                  }
                  const freeUsed = user?.totalValuationsUsed || 0;
                  return freeUsed < 3 ? `Noch ${3 - freeUsed} freie Bewertungen` : 'Jetzt upgraden';
                })()}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Current Status */}
        {user && (
          <Alert className="bg-slate-800/50 border-slate-700">
            <Gem className="h-4 w-4 text-cyan-400" />
            <AlertDescription className="text-slate-300 flex items-center justify-between flex-wrap gap-4">
              <div>
                <strong>Aktueller Plan:</strong> {plans.find(p => p.id === currentPlan)?.name} 
                {user.subscriptionEndDate && currentPlan !== 'free' && (
                  <span className="ml-2">
                    (Läuft bis: {format(new Date(user.subscriptionEndDate), 'dd.MM.yyyy')})
                  </span>
                )}
              </div>
              {currentPlan !== 'free' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowCancelModal(true)}
                  className="text-red-400 border-red-400 hover:bg-red-900/20"
                >
                  Abo kündigen
                </Button>
              )}
            </AlertDescription>
          </Alert>
        )}

        {/* Pricing Plans */}
        <div className="grid lg:grid-cols-3 gap-8 items-stretch">
          {plans.map((plan) => (
            <Card key={plan.id} className={`${plan.color} text-white relative overflow-hidden shadow-xl flex flex-col`}>
              {plan.popular && (
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-yellow-400 text-yellow-900 font-bold">
                    <Star className="w-3 h-3 mr-1" />
                    Beliebt
                  </Badge>
                </div>
              )}
              
              <CardHeader className={`${plan.headerColor} pb-8 ${plan.popular ? 'pt-12' : 'pt-6'}`}>
                <div className="text-center">
                  <div className="flex justify-center mb-3">
                    {plan.icon}
                  </div>
                  <CardTitle className="text-2xl font-bold mb-2">{plan.name}</CardTitle>
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-4xl font-bold">
                      {plan.price === 0
                        ? 'Kostenlos'
                        : plan.price === null
                        ? plan.period
                        : `${plan.price.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}€`}
                    </span>
                    {plan.price > 0 && (
                      <span className="text-white/80">{plan.period}</span>
                    )}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="p-6 space-y-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-3">
                        {feature.included ? (
                          <Check className="w-5 h-5 text-green-400 flex-shrink-0" />
                        ) : (
                          <X className="w-5 h-5 text-red-400 flex-shrink-0" />
                        )}
                        <span className={feature.included ? 'text-white' : 'text-white/60'}>
                          {feature.text}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 mt-4 border-t border-white/20">
                    <p className="text-sm text-white/80 italic">
                      {plan.limitations}
                    </p>
                  </div>
                </div>

                <div className="pt-4">
                  {currentPlan === plan.id ? (
                    <Badge className="w-full justify-center py-2 bg-white/20 text-white border-white/30">
                      Aktueller Plan
                    </Badge>
                  ) : plan.id === 'free' ? (
                    <Badge className="w-full justify-center py-2 bg-white/20 text-white border-white/30">
                      Kostenloser Plan
                    </Badge>
                  ) : plan.id === 'pro' ? (
                    <Button 
                      size="lg" 
                      className="w-full bg-white text-slate-900 hover:bg-slate-200 font-semibold"
                      onClick={() => navigate(createPageUrl(`Bezahlung?plan=pro`))}
                    >
                      Plan wählen
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : (
                    <Button 
                      size="lg" 
                      variant="outline"
                      className="w-full"
                      onClick={() => window.open('mailto:info@prizr.app?subject=Enterprise%20Anfrage', '_blank')}
                    >
                      Kontakt aufnehmen
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bewertungspakete */}
        <div className="mt-12">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-slate-50 mb-2">Einzelne Bewertungen kaufen</h2>
            <p className="text-slate-400">Perfekt für gelegentliche Nutzung - kein Abonnement erforderlich</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
            {valuationPacks.map((pack) => (
              <Card key={pack.count} className={`bg-slate-900 border-slate-800 relative overflow-hidden shadow-lg hover:shadow-cyan-500/10 hover:border-cyan-700 transition-all duration-300 ${pack.popular ? 'ring-2 ring-cyan-500/50' : ''}`}>
                {pack.popular && (
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-cyan-600 text-white font-bold text-xs">
                      Beliebt
                    </Badge>
                  </div>
                )}
                
                <CardContent className="p-6 text-center">
                  <div className="mb-4">
                    <div className="text-5xl font-bold text-cyan-400 mb-1">{pack.count}</div>
                    <div className="text-sm text-slate-400">Bewertungen</div>
                  </div>

                  <div className="mb-6">
                    <div className="text-3xl font-bold text-slate-50">
                      {pack.price.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}€
                    </div>
                    <div className="text-xs text-slate-500 mt-1">
                      {(pack.price / pack.count).toFixed(2)}€ pro Bewertung
                    </div>
                  </div>

                  <Button 
                    size="lg" 
                    className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-semibold"
                    onClick={() => navigate(createPageUrl(`Bezahlung?plan=pack_${pack.count}`))}
                  >
                    Jetzt kaufen
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>

                  <div className="pt-3 text-xs text-slate-500 text-center">
                    Einmalzahlung • Kein Abo • Unbegrenzt gültig
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
