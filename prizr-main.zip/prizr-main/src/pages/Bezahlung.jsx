import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  CreditCard, 
  ArrowLeft,
  Shield,
  Loader2
} from "lucide-react";
import { createPageUrl } from "@/utils";

const plansDetails = {
  pro: {
    name: "Prizr Pro",
    price: "4,99€",
    period: "Monat",
    type: "subscription"
  },
  pack_5: {
    name: "5 Bewertungen",
    price: "1,99€",
    period: "Einmalig",
    type: "one_time"
  },
  pack_20: {
    name: "20 Bewertungen",
    price: "3,99€",
    period: "Einmalig",
    type: "one_time"
  }
};

export default function Bezahlung() {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [planType, setPlanType] = useState(null);
  const [planDetails, setPlanDetails] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const plan = searchParams.get('plan');
    if (plan && plansDetails[plan]) {
      setPlanType(plan);
      setPlanDetails(plansDetails[plan]);
    } else {
      navigate(createPageUrl("Abonnement"));
    }

    base44.auth.me().then(setUser).catch(() => setError("Bitte melden Sie sich an, um fortzufahren."));
  }, [location, navigate]);

  const handlePayment = async (provider) => {
    if (!user) {
      setError('Bitte melden Sie sich an.');
      return;
    }
    setProcessing(true);
    setError(null);
    
    try {
      let response;
      if (provider === 'stripe') {
        response = await base44.functions.invoke('stripeCheckout', { planType });
      } else if (provider === 'paypal') {
        response = await base44.functions.invoke('paypalCheckout', { planType });
      }

      if (response.data?.checkoutUrl) {
        window.location.href = response.data.checkoutUrl;
      } else {
        throw new Error('Keine Checkout-URL erhalten');
      }
    } catch (err) {
      console.error('Payment Error:', err);
      setError('Fehler bei der Zahlungsabwicklung. Bitte versuchen Sie es später erneut.');
      setProcessing(false);
    }
  };

  if (!planDetails) {
    return (
      <div className="p-8 max-w-md mx-auto text-center">
        <Loader2 className="w-8 h-8 animate-spin mx-auto" />
        <p className="mt-4">Lade Plan-Informationen...</p>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 max-w-md mx-auto space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Abonnement"))}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Zahlung abschließen</h1>
          <p className="text-slate-400">Sicher und schnell zu Ihrem neuen Plan.</p>
        </div>
      </div>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>Ihre Auswahl</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center bg-slate-800 p-4 rounded-lg">
            <div>
              <h3 className="font-bold text-lg text-slate-100">{planDetails.name}</h3>
              <p className="text-slate-400">
                {planDetails.type === 'subscription' ? 'Monatliches Abonnement' : 'Einmalkauf'}
              </p>
            </div>
            <div className="text-right">
              <p className="font-bold text-xl text-cyan-400">{planDetails.price}</p>
              <p className="text-sm text-slate-500">{planDetails.period}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {error && <p className="text-red-400 text-sm text-center">{error}</p>}

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>Zahlungsmethode wählen</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button 
            size="lg" 
            className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold flex items-center justify-center gap-2"
            onClick={() => handlePayment('stripe')}
            disabled={processing}
          >
            {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CreditCard className="w-5 h-5" />}
            Mit Stripe bezahlen
          </Button>
          
          <div className="flex items-center justify-center gap-2 pt-4 text-sm text-slate-500">
            <Shield className="w-4 h-4" />
            <span>Sichere Zahlung über Stripe</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}