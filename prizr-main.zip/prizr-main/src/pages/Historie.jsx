
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/entities/User";
import { Valuation } from "@/entities/Valuation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import ImageModal from "@/components/ImageModal";
import ValuationDetailModal from "@/components/ValuationDetailModal";
import {
  History,
  Search,
  Euro,
  Calendar,
  Eye,
  ArrowLeft,
  ImageIcon,
  Archive,
  Trash2,
} from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

// Robuste Hilfsfunktion zum Parsen der Foto-URLs
const getPhotoArray = (photoUrlsField) => {
  if (!photoUrlsField) return [];
  if (Array.isArray(photoUrlsField)) return photoUrlsField; // Schon ein Array
  if (typeof photoUrlsField === 'string') {
    try {
      const parsed = JSON.parse(photoUrlsField);
      if (Array.isArray(parsed)) return parsed; // JSON-String eines Arrays
    } catch (e) {
      // Kein valides JSON, vielleicht eine einzelne URL?
      if (photoUrlsField.startsWith('http')) {
        return [photoUrlsField]; // Als Array mit einem Element behandeln
      }
    }
  }
  return []; // Fallback
};

export default function Historie() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [valuations, setValuations] = useState([]);
  const [filteredValuations, setFilteredValuations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [confidenceFilter, setConfidenceFilter] = useState("all");
  const [magnifiedImage, setMagnifiedImage] = useState(null);
  const [selectedValuation, setSelectedValuation] = useState(null);

  const loadData = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      const userValuations = await Valuation.filter({ created_by: currentUser.email }, '-created_date');
      setValuations(userValuations);
    } catch (error) {
      console.error("Fehler beim Laden der Daten:", error);
    }
    setLoading(false);
  }, []);

  const filterAndSortValuations = useCallback(() => {
    let filtered = [...valuations];

    // Search filter
    if (searchTerm) {
      // Updated search criteria based on new placeholder
      filtered = filtered.filter(val =>
        (val.identifiedStyle && val.identifiedStyle.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (val.woodType && val.woodType.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (val.origin && val.origin.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Confidence filter
    if (confidenceFilter !== "all") {
      filtered = filtered.filter(val => val.confidence === confidenceFilter);
    }

    // Sort
    switch (sortBy) {
      case "newest":
        filtered.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        break;
      case "oldest":
        filtered.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        break;
      case "value_high":
        filtered.sort((a, b) => (b.estimatedValue || 0) - (a.estimatedValue || 0));
        break;
      case "value_low":
        filtered.sort((a, b) => (a.estimatedValue || 0) - (b.estimatedValue || 0));
        break;
      default:
        break;
    }

    setFilteredValuations(filtered);
  }, [valuations, searchTerm, sortBy, confidenceFilter]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    filterAndSortValuations();
  }, [filterAndSortValuations]);

  const handleDelete = async (valuationId) => {
    if (window.confirm("Sind Sie sicher, dass Sie diese Bewertung endgültig löschen möchten?")) {
      try {
        // NEU: Rufe die neue Löschfunktion auf
        const { deleteValuationRecursive } = await import("@/functions/deleteValuationRecursive");
        await deleteValuationRecursive({ valuationId });
        
        setValuations(vals => vals.filter(v => v.id !== valuationId));
        // If the deleted item was currently selected, deselect it
        if (selectedValuation && selectedValuation.id === valuationId) {
          setSelectedValuation(null);
        }
      } catch (error) {
        console.error("Fehler beim Löschen der Bewertung:", error);
        alert("Die Bewertung konnte nicht gelöscht werden.");
      }
    }
  };

  const getConfidenceBadge = (confidence) => {
    switch (confidence) {
      case 'high':
        return <Badge className="bg-teal-900 text-teal-200 border-teal-700">🎯 Hohe Sicherheit</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-900 text-yellow-200 border-yellow-700">⚡ Gute Schätzung</Badge>;
      case 'low':
        return <Badge className="bg-orange-900 text-orange-200 border-orange-700">📊 Grobe Schätzung</Badge>;
      default:
        return null;
    }
  };

  const getConditionText = (condition) => {
    const conditions = {
      1: "Neuwertig",
      2: "Sehr gut",
      3: "Gut",
      4: "Gebrauchsspuren",
      5: "Grenzwertig nutzbar"
    };
    return conditions[condition] || "Unbekannt";
  };

  // Kurze Überschrift erstellen
  const getShortTitle = (valuation) => {
    if (valuation.identifiedStyle) {
      return valuation.identifiedStyle;
    }
    if (valuation.description) {
      // Nur die ersten 3-4 Wörter oder bis zu 30 Zeichen
      const words = valuation.description.split(' ').slice(0, 3).join(' ');
      return words.length > 30 ? words.substring(0, 30) + '...' : words;
    }
    return 'Möbelstück';
  };

  if (loading) {
    return (
      <div className="p-8 max-w-6xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-700 rounded w-1/3"></div>
          <div className="grid gap-6">
            {[1,2,3].map(i => (
              <div key={i} className="h-32 bg-slate-800 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <ImageModal src={magnifiedImage} onClose={() => setMagnifiedImage(null)} />
      <ValuationDetailModal
        valuation={selectedValuation}
        onClose={() => setSelectedValuation(null)}
        onImageClick={setMagnifiedImage}
      />

      <div className="p-4 md:p-8 max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate(createPageUrl("Dashboard"))}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-slate-50 flex items-center gap-2">
                <History className="w-6 h-6" />
                Bewertungshistorie
              </h1>
              <p className="text-slate-400">
                {filteredValuations.length} von {valuations.length} Bewertungen
              </p>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 items-end">
              <div className="flex-1 space-y-2 lg:col-span-1">
                <Label className="text-sm font-medium text-slate-300">Suche</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <Input
                    placeholder="Suche nach Stil, Material..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium text-slate-300">Sortierung</Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Neueste zuerst</SelectItem>
                    <SelectItem value="oldest">Älteste zuerst</SelectItem>
                    <SelectItem value="value_high">Wert hoch → niedrig</SelectItem>
                    <SelectItem value="value_low">Wert niedrig → hoch</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium text-slate-300">Sicherheit</Label>
                <Select value={confidenceFilter} onValueChange={setConfidenceFilter}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle</SelectItem>
                    <SelectItem value="high">Hoch</SelectItem>
                    <SelectItem value="medium">Mittel</SelectItem>
                    <SelectItem value="low">Niedrig</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Valuations List */}
        <div className="space-y-4">
          {filteredValuations.length === 0 ? (
            <Card className="bg-slate-900 border-slate-800">
              <CardContent className="p-12 text-center">
                <Archive className="w-16 h-16 text-slate-700 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-100 mb-2">
                  {valuations.length === 0 ? "Noch keine Bewertungen" : "Keine Ergebnisse gefunden"}
                </h3>
                <p className="text-slate-400 mb-6">
                  {valuations.length === 0
                    ? "Starten Sie Ihre erste Möbelbewertung!"
                    : "Versuchen Sie andere Suchbegriffe oder Filter."
                  }
                </p>
                {valuations.length === 0 && (
                  <Button onClick={() => navigate(createPageUrl("Bewertung"))} className="bg-cyan-600 hover:bg-cyan-700">
                    Erste Bewertung starten
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            filteredValuations.map((valuation) => {
              const photoUrls = getPhotoArray(valuation.photoUrls);
              const firstPhoto = photoUrls[0];

              return (
                <Card
                  key={valuation.id}
                  className="bg-slate-900 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50 transition-all duration-200 cursor-pointer relative"
                  onClick={() => setSelectedValuation(valuation)}
                >
                  <CardContent className="p-4 md:p-6">
                    <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
                      {/* Photo Preview */}
                      <div
                        className="w-full sm:w-24 md:w-32 h-32 sm:h-auto rounded-lg overflow-hidden bg-slate-800 flex-shrink-0"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (firstPhoto) setMagnifiedImage(firstPhoto);
                        }}
                      >
                        {firstPhoto ? (
                          <img
                            src={firstPhoto}
                            alt="Möbelstück"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <ImageIcon className="w-8 h-8 text-slate-700" />
                          </div>
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0 space-y-2">
                       <div className="flex justify-between items-start gap-4">
                         <div className="flex-1 min-w-0">
                          <h3 className="text-md md:text-lg font-semibold text-slate-100 truncate">
                            {getShortTitle(valuation)}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-slate-400 mt-1">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {format(new Date(valuation.created_date), 'dd.MM.yyyy')}
                            </span>
                            {getConfidenceBadge(valuation.confidence)}
                           </div>
                         </div>
                         <div className="text-right flex-shrink-0">
                            <div className="text-lg md:text-xl font-bold text-teal-400">
                                {valuation.estimatedValue?.toLocaleString('de-DE', {
                                  style: 'currency',
                                  currency: 'EUR',
                                  maximumFractionDigits: 0
                                }) || 'N/A'}
                              </div>
                              {valuation.valueRange && (
                                <div className="text-xs text-slate-500">
                                  {valuation.valueRange}
                                </div>
                              )}
                         </div>
                       </div>
                       
                        {valuation.reasoning && (
                          <p className="text-sm text-slate-400 clamp-2 leading-relaxed">
                            {valuation.reasoning}
                          </p>
                        )}
                    </div>
                     <Button
                        variant="destructive"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(valuation.id);
                        }}
                        className="absolute top-2 right-2 sm:static bg-red-900/50 hover:bg-red-900/80 text-red-300 border border-red-800 w-8 h-8 flex-shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                  </div>
                </CardContent>
              </Card>
              )
            })
          )}
        </div>
      </div>
    </>
  );
}
