import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { jsPDF } from 'npm:jspdf@2.5.1';
import 'npm:jspdf-autotable@3.8.2';

// Verbesserte Hilfsfunktion für UTF-8 Text ohne Ersetzungen
const addText = (doc, text, x, y, options = {}) => {
    if (!text) return;
    
    // Keine Zeichenersetzung mehr - jsPDF unterstützt UTF-8 nativ
    const cleanText = text;
    
    if (options.maxWidth) {
        const lines = doc.splitTextToSize(cleanText, options.maxWidth);
        doc.text(lines, x, y);
        return lines.length * (options.lineHeight || 5);
    } else {
        doc.text(cleanText, x, y);
        return options.lineHeight || 5;
    }
};

// Verbesserte Hilfsfunktion zum Laden und Hinzufügen von Bildern
const addImageFromUrl = async (doc, imageUrl, x, y, width, height) => {
    try {
        if (!imageUrl) {
            console.log('Keine Bild-URL bereitgestellt');
            return false;
        }
        
        console.log('Versuche Bild zu laden von:', imageUrl);
        
        const response = await fetch(imageUrl);
        if (!response.ok) {
            console.error('Fehler beim Laden des Bildes:', response.status, response.statusText);
            return false;
        }
        
        const arrayBuffer = await response.arrayBuffer();
        if (arrayBuffer.byteLength === 0) {
            console.error('Leere Bild-Datei empfangen');
            return false;
        }
        
        const uint8Array = new Uint8Array(arrayBuffer);
        
        // Bestimme Bildformat basierend auf URL oder Dateiinhalt
        let format = 'JPEG'; // Standard
        if (imageUrl.toLowerCase().includes('.png')) {
            format = 'PNG';
        }
        
        // Konvertiere zu Base64
        let binary = '';
        for (let i = 0; i < uint8Array.length; i++) {
            binary += String.fromCharCode(uint8Array[i]);
        }
        const base64 = btoa(binary);
        
        // Füge das Bild zur PDF hinzu
        doc.addImage(`data:image/${format.toLowerCase()};base64,${base64}`, format, x, y, width, height);
        console.log('Bild erfolgreich zur PDF hinzugefügt');
        return true;
        
    } catch (error) {
        console.error('Fehler beim Hinzufügen des Bildes zur PDF:', error);
        return false;
    }
};

// Robuste Hilfsfunktion zum Parsen der Foto-URLs
const getPhotoArray = (photoUrlsField) => {
  if (!photoUrlsField) return [];
  if (Array.isArray(photoUrlsField)) return photoUrlsField;
  if (typeof photoUrlsField === 'string') {
    try {
      const parsed = JSON.parse(photoUrlsField);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) {
      if (photoUrlsField.startsWith('http')) {
        return [photoUrlsField];
      }
    }
  }
  return [];
};

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }
        
        const { valuationId } = await req.json();

        if (!valuationId) {
            return Response.json({ error: 'Valuation ID is required in payload' }, { status: 400 });
        }

        const valuation = await base44.entities.Valuation.get(valuationId);

        if (!valuation || valuation.created_by !== user.email) {
             return Response.json({ error: 'Valuation not found or access denied' }, { status: 404 });
        }

        const doc = new jsPDF();
        
        // UTF-8 Support aktivieren
        doc.setFont('helvetica', 'normal');

        // Header-Bereich mit verbessertem Logo
        const headerHeight = 35;
        doc.setFillColor(15, 23, 42); // Slate-900 Farbe
        doc.rect(0, 0, 210, headerHeight, 'F');
        
        // Prizr-Logo - verbesserter Ansatz
        doc.setFillColor(20, 184, 166); // Teal-500 Farbe wie auf der Website
        doc.circle(20, 18, 10, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(16);
        doc.setFont('helvetica', 'bold');
        addText(doc, 'P', 16, 22);
        
        // Titel rechts vom Logo
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(20);
        doc.setFont('helvetica', 'bold');
        addText(doc, 'Prizr Bewertungsbericht', 40, 22);
        
        // Reset auf schwarzen Text
        doc.setTextColor(0, 0, 0);
        
        // Hauptinhalt startet nach dem Header
        let y = headerHeight + 15;
        
        // Titel und Datum der Bewertung
        doc.setFontSize(16);
        doc.setFont('helvetica', 'bold');
        const title = valuation.identifiedStyle || 'Möbelstück';
        addText(doc, title, 14, y);
        
        y += 10;
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        const createdDate = new Date(valuation.created_date).toLocaleDateString('de-DE');
        addText(doc, `Bewertung vom: ${createdDate}`, 14, y);
        
        y += 20;

        // Bewertungsinformationen in einer strukturierten Box
        doc.setFillColor(248, 250, 252); // Light gray background
        doc.rect(14, y, 182, 45, 'F');
        doc.setDrawColor(226, 232, 240);
        doc.rect(14, y, 182, 45);
        
        y += 10;
        
        // Hauptwert prominent anzeigen
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        addText(doc, 'Geschätzter Wert:', 18, y);
        doc.setFontSize(18);
        doc.setTextColor(20, 184, 166); // Teal color
        const valueText = valuation.estimatedValue 
            ? `${valuation.estimatedValue.toLocaleString('de-DE')} €`
            : 'N/A';
        addText(doc, valueText, 70, y);
        
        y += 12;
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        addText(doc, `Wertspanne: ${valuation.valueRange || 'N/A'}`, 18, y);
        
        y += 8;
        addText(doc, `Zustand: ${valuation.condition || 'N/A'} / 5`, 18, y);
        
        y += 8;
        addText(doc, `Sicherheit: ${valuation.confidence || 'N/A'}`, 18, y);
        
        y += 20;
        
        // Vollständige Beschreibung
        if (valuation.description) {
            doc.setFontSize(12);
            doc.setFont('helvetica', 'bold');
            addText(doc, 'Beschreibung:', 14, y);
            y += 8;
            
            doc.setFontSize(10);
            doc.setFont('helvetica', 'normal');
            const descriptionHeight = addText(doc, valuation.description, 14, y, { maxWidth: 180, lineHeight: 6 });
            y += descriptionHeight + 10;
        }
        
        // Stil und Designer
        if (valuation.identifiedStyle) {
            doc.setFont('helvetica', 'bold');
            addText(doc, 'Stil:', 14, y);
            y += 6;
            doc.setFont('helvetica', 'normal');
            addText(doc, valuation.identifiedStyle, 14, y, { maxWidth: 180 });
            y += 12;
        }
        
        if (valuation.likelyManufacturer) {
            doc.setFont('helvetica', 'bold');
            addText(doc, 'Wahrscheinlicher Hersteller:', 14, y);
            y += 6;
            doc.setFont('helvetica', 'normal');
            addText(doc, valuation.likelyManufacturer, 14, y, { maxWidth: 180 });
            y += 12;
        }
        
        if (valuation.likelyDesigner) {
            doc.setFont('helvetica', 'bold');
            addText(doc, 'Wahrscheinlicher Designer:', 14, y);
            y += 6;
            doc.setFont('helvetica', 'normal');
            addText(doc, valuation.likelyDesigner, 14, y, { maxWidth: 180 });
            y += 12;
        }
        
        // Bewertungsgrundlage
        if (valuation.reasoning) {
            doc.setFont('helvetica', 'bold');
            addText(doc, 'Bewertungsgrundlage:', 14, y);
            y += 8;
            
            doc.setFont('helvetica', 'normal');
            const reasoningHeight = addText(doc, valuation.reasoning, 14, y, { maxWidth: 180, lineHeight: 6 });
            y += reasoningHeight + 15;
        }
        
        // Neue Seite für Bilder wenn nötig
        if (y > 240) {
            doc.addPage();
            y = 20;
        }
        
        // Alle hochgeladenen Bilder einbinden
        const photoUrls = getPhotoArray(valuation.photoUrls);
        if (photoUrls.length > 0) {
            doc.setFont('helvetica', 'bold');
            addText(doc, 'Analysierte Fotos:', 14, y);
            y += 10;
            
            const imageWidth = 40;
            const imageHeight = 30;
            const imagesPerRow = 4;
            let imageCount = 0;
            
            for (const photoUrl of photoUrls) {
                const row = Math.floor(imageCount / imagesPerRow);
                const col = imageCount % imagesPerRow;
                const imageX = 14 + (col * (imageWidth + 5));
                const imageY = y + (row * (imageHeight + 5));
                
                // Neue Seite wenn nötig
                if (imageY + imageHeight > 280) {
                    doc.addPage();
                    y = 20;
                    // Recalculate positions
                    const newRow = Math.floor(imageCount / imagesPerRow) - Math.floor(photoUrls.indexOf(photoUrl) / imagesPerRow);
                    const newImageY = y + (newRow * (imageHeight + 5));
                    await addImageFromUrl(doc, photoUrl, imageX, newImageY, imageWidth, imageHeight);
                } else {
                    await addImageFromUrl(doc, photoUrl, imageX, imageY, imageWidth, imageHeight);
                }
                
                imageCount++;
            }
            
            // Adjust y position after images
            const totalRows = Math.ceil(photoUrls.length / imagesPerRow);
            y += totalRows * (imageHeight + 5) + 10;
        }
        
        // Footer - neue Seite wenn nötig
        if (y > 260) {
            doc.addPage();
            y = 250;
        } else {
            y = Math.max(y, 275);
        }
        
        doc.setFontSize(8);
        doc.setTextColor(100, 100, 100);
        addText(doc, `Erstellt mit Prizr • ${new Date().toLocaleDateString('de-DE')} • prizr.base44.app`, 14, y);
        
        const pdfBytes = doc.output('arraybuffer');

        // Verbesserter Dateiname
        const cleanTitle = (valuation.identifiedStyle || 'Moebel')
            .replace(/[^a-zA-Z0-9äöüÄÖÜß\s-]/g, '')
            .replace(/\s+/g, '-')
            .substring(0, 30)
            .replace(/-$/, '');
        
        const dateFormatted = new Date(valuation.created_date).toLocaleDateString('de-DE').replace(/\./g, '-');
        const filename = `Prizr-Bewertung-${cleanTitle}-${dateFormatted}.pdf`;

        return new Response(pdfBytes, {
            status: 200,
            headers: {
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="${filename}"`
            }
        });

    } catch (error) {
        console.error('PDF Export Error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});