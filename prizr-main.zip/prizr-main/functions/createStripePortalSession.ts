
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@16.12.0';

Deno.serve(async (req) => {
    console.log('\n' + '='.repeat(80));
    console.log('🔄 STRIPE PORTAL SESSION REQUEST GESTARTET');
    console.log('='.repeat(80));
    
    try {
        const base44 = createClientFromRequest(req);
        
        console.log('1️⃣ Authentifiziere User...');
        const user = await base44.auth.me();

        if (!user) {
            console.error('❌ Unauthorized: Kein User gefunden');
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        console.log(`✅ User authentifiziert:`);
        console.log(`   - Email: ${user.email}`);
        console.log(`   - ID: ${user.id}`);
        console.log(`   - Subscription Type: ${user.subscriptionType || 'free'}`);
        console.log(`   - Stripe Customer ID: ${user.stripeCustomerId || 'NICHT VORHANDEN'}`);
        console.log(`   - Subscription End Date: ${user.subscriptionEndDate || 'NICHT VORHANDEN'}`);

        // Prüfe Subscription Type
        if (!user.subscriptionType || user.subscriptionType === 'free') {
            console.error('❌ User hat keinen bezahlten Plan');
            return Response.json({ 
                error: 'Portal nur für bezahlte Abonnements verfügbar',
                details: 'Sie haben aktuell kein aktives bezahltes Abonnement.'
            }, { status: 403 });
        }

        console.log('2️⃣ Prüfe Stripe-Konfiguration...');
        const stripeSecretKey = Deno.env.get("STRIPE_SECRET_KEY");
        
        if (!stripeSecretKey) {
            console.error('❌ STRIPE_SECRET_KEY nicht konfiguriert');
            return Response.json({ 
                error: 'Stripe nicht konfiguriert',
                details: 'Die Stripe-Integration ist nicht vollständig eingerichtet.'
            }, { status: 500 });
        }
        
        console.log('✅ Stripe Secret Key gefunden');

        const stripe = new Stripe(stripeSecretKey);

        // WICHTIG: Prüfe, ob User über Stripe oder PayPal bezahlt hat
        console.log('3️⃣ Prüfe Zahlungsmethode...');
        
        if (!user.stripeCustomerId) {
            console.warn('⚠️ Keine Stripe Customer ID vorhanden');
            console.log('💡 Versuche, neuen Stripe Customer zu erstellen...');
            
            try {
                const newCustomer = await stripe.customers.create({
                    email: user.email,
                    name: user.full_name || user.email,
                    metadata: { 
                        userId: user.id,
                        createdBy: 'portal_session_fallback'
                    }
                });
                
                console.log(`✅ Neuer Stripe Customer erstellt: ${newCustomer.id}`);
                
                // Speichere Customer ID in Datenbank
                await base44.asServiceRole.entities.User.update(user.id, { 
                    stripeCustomerId: newCustomer.id 
                });
                
                console.log('✅ Customer ID in Datenbank gespeichert');
                user.stripeCustomerId = newCustomer.id;
                
            } catch (createError) {
                console.error('❌ Fehler beim Erstellen des Stripe Customers:', createError);
                
                // Wenn es ein PayPal-User ist, gebe spezifische Nachricht
                return Response.json({ 
                    error: 'Kündigung nicht möglich',
                    details: 'Ihr Abonnement wurde möglicherweise über PayPal abgeschlossen. Bitte kündigen Sie über Ihr PayPal-Konto oder kontaktieren Sie uns unter info@prizr.app'
                }, { status: 400 });
            }
        }

        const customerId = user.stripeCustomerId;
        console.log(`4️⃣ Verwende Stripe Customer ID: ${customerId}`);
        
        // Verifiziere Customer
        console.log('5️⃣ Verifiziere Stripe Customer...');
        try {
            const customer = await stripe.customers.retrieve(customerId);
            
            if (customer.deleted) {
                console.error('❌ Stripe Customer wurde gelöscht');
                return Response.json({ 
                    error: 'Stripe-Konto nicht verfügbar',
                    details: 'Ihr Stripe-Konto wurde gelöscht. Bitte kontaktieren Sie den Support unter info@prizr.app'
                }, { status: 400 });
            }
            
            console.log(`✅ Customer verifiziert:`);
            console.log(`   - Email: ${customer.email}`);
            console.log(`   - Created: ${new Date(customer.created * 1000).toISOString()}`);
            
        } catch (retrieveError) {
            console.error('❌ Fehler beim Abrufen des Stripe Customers:', retrieveError);
            console.error('   - Type:', retrieveError.type);
            console.error('   - Code:', retrieveError.code);
            console.error('   - Message:', retrieveError.message);
            
            return Response.json({ 
                error: 'Stripe-Konto nicht gefunden',
                details: `Ihr Stripe-Konto konnte nicht gefunden werden (${retrieveError.message}). Bitte kontaktieren Sie den Support.`
            }, { status: 400 });
        }

        // Erstelle Return URL
        console.log('6️⃣ Erstelle Return URL...');
        
        const origin = req.headers.get('origin');
        const referer = req.headers.get('referer');
        
        console.log(`   - Origin Header: ${origin || 'NICHT VORHANDEN'}`);
        console.log(`   - Referer Header: ${referer || 'NICHT VORHANDEN'}`);
        
        let returnUrl;
        
        if (origin) {
            try {
                const urlObj = new URL(origin);
                returnUrl = `${urlObj.origin}/Profil`;
            } catch (e) {
                console.warn('⚠️ Origin parsing fehlgeschlagen:', e.message);
                returnUrl = 'https://prizr.app/Profil';
            }
        } else if (referer) {
            try {
                const urlObj = new URL(referer);
                returnUrl = `${urlObj.origin}/Profil`;
            } catch (e) {
                console.warn('⚠️ Referer parsing fehlgeschlagen:', e.message);
                returnUrl = 'https://prizr.app/Profil';
            }
        } else {
            console.warn('⚠️ Kein Origin/Referer gefunden, verwende Fallback');
            returnUrl = 'https://prizr.app/Profil';
        }
        
        console.log(`✅ Return URL: ${returnUrl}`);

        // Erstelle Portal Session
        console.log('7️⃣ Erstelle Stripe Portal Session...');
        
        try {
            const portalSession = await stripe.billingPortal.sessions.create({
                customer: customerId,
                return_url: returnUrl,
            });

            console.log(`✅ Portal Session erstellt:`);
            console.log(`   - Session ID: ${portalSession.id}`);
            console.log(`   - Portal URL: ${portalSession.url}`);
            console.log(`   - Return URL: ${portalSession.return_url}`);
            
            console.log('='.repeat(80));
            console.log('✅ ERFOLG: Portal Session bereit');
            console.log('='.repeat(80) + '\n');

            return Response.json({ 
                success: true,
                portalUrl: portalSession.url 
            });
            
        } catch (portalError) {
            console.error('❌ Fehler beim Erstellen der Portal Session:');
            console.error('   - Type:', portalError.type);
            console.error('   - Code:', portalError.code);
            console.error('   - Message:', portalError.message);
            console.error('   - Param:', portalError.param);
            
            if (portalError.raw) {
                console.error('   - Raw:', JSON.stringify(portalError.raw, null, 2));
            }
            
            // Spezifische Fehlerbehandlung
            if (portalError.code === 'resource_missing') {
                return Response.json({ 
                    error: 'Stripe-Konto nicht gefunden',
                    details: 'Ihr Stripe-Konto existiert nicht mehr. Bitte kontaktieren Sie den Support.'
                }, { status: 400 });
            }
            
            if (portalError.code === 'url_invalid') {
                return Response.json({ 
                    error: 'Ungültige URL-Konfiguration',
                    details: 'Die Weiterleitung konnte nicht konfiguriert werden. Bitte versuchen Sie es erneut.'
                }, { status: 400 });
            }
            
            return Response.json({ 
                error: 'Fehler beim Öffnen des Kundenportals',
                details: `Stripe-Fehler: ${portalError.message}`
            }, { status: 500 });
        }

    } catch (error) {
        console.error('❌ UNERWARTETER FEHLER:');
        console.error('   - Name:', error.name);
        console.error('   - Message:', error.message);
        console.error('   - Stack:', error.stack);
        
        console.log('='.repeat(80));
        console.log('❌ FEHLER: Portal Session fehlgeschlagen');
        console.log('='.repeat(80) + '\n');
        
        return Response.json({ 
            error: 'Ein unerwarteter Fehler ist aufgetreten',
            details: error.message
        }, { status: 500 });
    }
});
