import Dashboard from './pages/Dashboard';
import Bewertung from './pages/Bewertung';
import Historie from './pages/Historie';
import Abonnement from './pages/Abonnement';
import Admin from './pages/Admin';
import Profil from './pages/Profil';
import Bezahlung from './pages/Bezahlung';
import Impressum from './pages/Impressum';
import Datenschutz from './pages/Datenschutz';
import ComingSoon from './pages/ComingSoon';
import Zustimmungen from './pages/Zustimmungen';
import AGB from './pages/AGB';
import Layout from './Layout.jsx';


export const PAGES = {
    "Dashboard": Dashboard,
    "Bewertung": Bewertung,
    "Historie": Historie,
    "Abonnement": Abonnement,
    "Admin": Admin,
    "Profil": Profil,
    "Bezahlung": Bezahlung,
    "Impressum": Impressum,
    "Datenschutz": Datenschutz,
    "ComingSoon": ComingSoon,
    "Zustimmungen": Zustimmungen,
    "AGB": AGB,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: Layout,
};