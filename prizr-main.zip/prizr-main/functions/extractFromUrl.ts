import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Nicht autorisiert' }, { status: 401 });
    }

    const { url } = await req.json();
    
    if (!url || !url.startsWith('http')) {
      return Response.json({ error: 'Ungültige URL' }, { status: 400 });
    }

    console.log("🔗 URL-Extraktion:", url);

    // Lade HTML-Inhalt
    const pageResponse = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
      signal: AbortSignal.timeout(10000)
    });

    if (!pageResponse.ok) {
      throw new Error(`HTTP ${pageResponse.status}`);
    }

    const html = await pageResponse.text();
    const truncatedHtml = html.slice(0, 30000);

    // Extrahiere Bilder
    const imageRegex = /<img[^>]+src=["']([^"']+)["']/gi;
    const imageUrls = [...truncatedHtml.matchAll(imageRegex)]
      .map(m => m[1])
      .filter(u => u.startsWith('http') && !u.includes('logo') && !u.includes('icon'))
      .slice(0, 3);

    console.log(`🖼️ ${imageUrls.length} Bilder gefunden`);

    // Nutze Gemini über InvokeLLM Integration
    const analysisResult = await base44.integrations.Core.InvokeLLM({
      prompt: `Analysiere diesen HTML-Ausschnitt eines Möbelangebots und extrahiere:
1. Material/Holzart
2. Geschätztes Alter/Epoche
3. Herkunft/Hersteller
4. Zustand (1-5, wobei 1=neuwertig, 5=stark gebraucht)
5. Kurze Beschreibung

HTML:
${truncatedHtml}

Antworte NUR mit JSON:`,
      response_json_schema: {
        type: "object",
        properties: {
          woodType: { type: "string" },
          age: { type: "string" },
          origin: { type: "string" },
          condition: { type: "number" },
          description: { type: "string" }
        }
      }
    });

    const result = {
      ...analysisResult,
      imageUrls,
      sourceUrl: url
    };

    console.log("✅ Extraktion erfolgreich");
    return Response.json(result);

  } catch (error) {
    console.error("❌ Fehler:", error.message);
    return Response.json({
      error: 'Extraktion fehlgeschlagen',
      details: error.message
    }, { status: 500 });
  }
});