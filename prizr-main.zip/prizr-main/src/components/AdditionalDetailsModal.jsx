
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { X, Camera, FileImage, Loader2, AlertCircle, CheckCircle } from 'lucide-react';

const AdditionalDetailsModal = ({ 
  isOpen, 
  onClose, 
  onSubmitAdditionalPhotos,
  alternativeIdentifications = [],
  specificDetailsNeeded = [],
  loading = false 
}) => {
  const [additionalPhotos, setAdditionalPhotos] = useState([]);
  const [uploading, setUploading] = useState({});

  if (!isOpen) return null;

  const handlePhotoUpload = async (index, file) => {
    if (!file) return;
    
    setUploading(prev => ({ ...prev, [index]: true }));
    
    try {
      // Convert to base64 for preview
      const reader = new FileReader();
      reader.onload = (e) => {
        const newPhotos = [...additionalPhotos];
        newPhotos[index] = {
          file: file, // KORREKTUR: Speichere das originale File-Objekt
          base64: e.target.result, // Base64 nur für Preview
          uploaded: true
        };
        setAdditionalPhotos(newPhotos);
        setUploading(prev => ({ ...prev, [index]: false }));
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Fehler beim Upload:', error);
      setUploading(prev => ({ ...prev, [index]: false }));
    }
  };

  const handleSubmit = () => {
    const validPhotos = additionalPhotos.filter(photo => photo && photo.file);
    if (validPhotos.length === 0) {
      alert('Bitte laden Sie mindestens ein zusätzliches Foto hoch.');
      return;
    }
    // KORREKTUR: Übergebe nur die File-Objekte, nicht die kompletten Photo-Objekte
    onSubmitAdditionalPhotos(validPhotos.map(photo => photo.file));
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col">
        <div className="flex-shrink-0 bg-slate-900 border-b border-slate-800 p-6 flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold text-slate-50 flex items-center gap-2">
              <AlertCircle className="w-6 h-6 text-yellow-500" />
              Präzisere Bewertung möglich
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Die KI hat mehrere mögliche Identifikationen gefunden. Zusätzliche Details helfen bei der finalen Bestimmung.
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Alternative Identifikationen */}
          {alternativeIdentifications.length > 0 && (
            <div>
              <h3 className="font-semibold text-slate-100 mb-3">Mögliche Identifikationen:</h3>
              <div className="space-y-2">
                {alternativeIdentifications.map((alt, index) => (
                  <div key={index} className="flex items-center justify-between bg-slate-800 p-3 rounded-lg">
                    <div>
                      <span className="font-medium text-slate-100">{alt.style}</span>
                      <p className="text-xs text-slate-400">{alt.reasoning}</p>
                    </div>
                    <Badge variant="outline" className="ml-2">
                      {alt.confidence}% sicher
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          <Separator className="bg-slate-700" />

          {/* Benötigte Details */}
          <div>
            <h3 className="font-semibold text-slate-100 mb-3">
              Zusätzliche Fotos für präzise Identifikation:
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              {specificDetailsNeeded.map((detail, index) => {
                const photo = additionalPhotos[index];
                const isUploading = uploading[index];
                
                return (
                  <Card key={index} className="bg-slate-800 border-slate-700">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-semibold text-slate-100 text-sm">{detail.detail}</h4>
                          <p className="text-xs text-slate-400">{detail.reason}</p>
                        </div>
                        
                        {photo ? (
                          <div className="space-y-2">
                            <img 
                              src={photo.base64} 
                              alt={detail.detail}
                              className="w-full h-24 object-cover rounded border border-slate-600"
                            />
                            <div className="flex items-center gap-2 text-xs text-teal-400">
                              <CheckCircle className="w-3 h-3" />
                              Foto hochgeladen
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <div className="flex gap-2">
                              <input 
                                type="file" 
                                accept="image/jpeg, image/png" 
                                capture="environment"
                                onChange={(e) => handlePhotoUpload(index, e.target.files[0])}
                                className="hidden" 
                                id={`additional-capture-${index}`}
                                disabled={isUploading}
                              />
                              <input 
                                type="file" 
                                accept="image/jpeg, image/png"
                                onChange={(e) => handlePhotoUpload(index, e.target.files[0])}
                                className="hidden" 
                                id={`additional-upload-${index}`}
                                disabled={isUploading}
                              />
                              
                              <Button 
                                variant="outline" 
                                size="sm" 
                                disabled={isUploading}
                                asChild
                              >
                                <label htmlFor={`additional-capture-${index}`} className="cursor-pointer flex items-center gap-1">
                                  {isUploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Camera className="w-3 h-3" />}
                                  Foto
                                </label>
                              </Button>
                              
                              <Button 
                                variant="outline" 
                                size="sm" 
                                disabled={isUploading}
                                asChild
                              >
                                <label htmlFor={`additional-upload-${index}`} className="cursor-pointer flex items-center gap-1">
                                  {isUploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <FileImage className="w-3 h-3" />}
                                  Datei
                                </label>
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex-shrink-0 bg-slate-900 border-t border-slate-800 p-4 flex justify-between">
          <Button variant="outline" onClick={onClose}>
            Aktuelle Bewertung beibehalten
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={loading || additionalPhotos.filter(p => p?.file).length === 0}
            className="bg-cyan-600 hover:bg-cyan-700"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analysiere...
              </>
            ) : (
              'Bewertung präzisieren'
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AdditionalDetailsModal;
