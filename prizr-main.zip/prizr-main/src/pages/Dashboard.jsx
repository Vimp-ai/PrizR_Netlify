import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Camera,
  ArrowRight,
  Sparkles,
  LogIn,
} from "lucide-react";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const authenticated = await base44.auth.isAuthenticated();
      setIsAuthenticated(authenticated);
      
      if (authenticated) {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      }
    } catch (error) {
      console.error("Fehler beim Laden der Benutzerdaten:", error);
      setIsAuthenticated(false);
    }
    setLoading(false);
  };

  const canUseService = () => {
    if (!user) return false;
    const type = user.subscriptionType || 'free';
    
    if (type === 'enterprise') {
      if (user.customMonthlyLimit !== null && user.customMonthlyLimit !== undefined) {
        const currentMonth = new Date().toISOString().slice(0, 7);
        const used = user.lastValuationMonth === currentMonth ? (user.monthlyValuationsUsed || 0) : 0;
        return used < user.customMonthlyLimit;
      }
      return true;
    }
    
    if (type === 'pro') {
      const currentMonth = new Date().toISOString().slice(0, 7);
      const used = user.lastValuationMonth === currentMonth ? (user.monthlyValuationsUsed || 0) : 0;
      return used < 30;
    }
    return (user.totalValuationsUsed || 0) < 3;
  };

  const handleStartEvaluation = () => {
    if (!isAuthenticated) {
      // Nicht eingeloggt: Zur Registrierung/Login weiterleiten
      base44.auth.redirectToLogin(createPageUrl("Bewertung"));
    } else if (!canUseService()) {
      // Eingeloggt aber Limit erreicht: Zu Abonnement
      window.location.href = createPageUrl("Abonnement");
    } else {
      // Alles ok: Zur Bewertung
      window.location.href = createPageUrl("Bewertung");
    }
  };

  if (loading) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-700 rounded w-1/3"></div>
          <div className="h-96 bg-slate-800 rounded-xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-8">
      <div className="relative w-full max-w-[450px] space-y-6">
        {/* Glow-Effekt */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            filter: "blur(80px)",
            background:
              "radial-gradient(closest-side, rgba(34,211,238,0.5), rgba(14,165,233,0.3) 40%, transparent 70%)",
            transform: "scale(1.5)"
          }}
        />

        {/* Hauptkreis */}
        <Card className="relative aspect-square w-full rounded-full bg-gradient-to-br from-cyan-900 to-teal-900 border-2 border-cyan-700/30 shadow-2xl overflow-visible">
          <CardContent className="h-full flex flex-col items-center justify-center p-8 sm:p-12 text-center">
            <div className="mb-6 w-full flex flex-col items-center">
              <div className="w-20 h-20 sm:w-24 sm:h-24 bg-cyan-800/30 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Camera className="w-10 h-10 sm:w-12 sm:h-12 text-cyan-300" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-50 brand-text mb-3">
                Neue Bewertung
              </h2>
              <p className="text-slate-300 text-sm leading-relaxed px-4 max-w-[280px]">
                Fotografieren Sie Ihr Möbelstück und erhalten Sie eine professionelle KI-Bewertung
              </p>
            </div>

            <div className="w-full px-8">
              <Button 
                size="lg" 
                onClick={handleStartEvaluation}
                className="w-full bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-700 hover:to-teal-700 text-white font-bold px-6 py-5 text-base rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 flex items-center justify-center gap-2 group"
              >
                {!isAuthenticated ? (
                  <>
                    <LogIn className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300 flex-shrink-0" />
                    <span>Jetzt registrieren</span>
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300 flex-shrink-0" />
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300 flex-shrink-0" />
                    <span>Jetzt bewerten</span>
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300 flex-shrink-0" />
                  </>
                )}
              </Button>
            </div>

            {isAuthenticated && !canUseService() && (
              <div className="mt-4 text-orange-400 text-sm px-4">
                Limit erreicht. <Link to={createPageUrl("Abonnement")} className="underline font-semibold">Jetzt upgraden</Link>
              </div>
            )}
            
            {!isAuthenticated && (
              <div className="mt-4 text-cyan-300 text-xs px-4">
                Erstellen Sie ein kostenloses Konto und starten Sie Ihre erste Bewertung
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}