import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        console.log('\n' + '='.repeat(80));
        console.log('🔍 DEBUG AGENT PARAMETERS');
        console.log('='.repeat(80));
        
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        
        console.log('\n📧 User Info:');
        console.log(`   Email: ${user?.email}`);
        console.log(`   ID: ${user?.id}`);
        console.log(`   Subscription: ${user?.subscriptionType || 'free'}`);
        
        const payload = await req.json();
        
        console.log('\n📦 Empfangene Payload:');
        console.log(JSON.stringify(payload, null, 2));
        
        console.log('\n🖼️ Bild-Analyse:');
        if (payload.allBase64Images) {
            console.log(`   allBase64Images: Array mit ${payload.allBase64Images.length} Einträgen`);
            payload.allBase64Images.forEach((img, i) => {
                if (typeof img === 'string') {
                    const isDataUrl = img.startsWith('data:');
                    const isHttpUrl = img.startsWith('http');
                    console.log(`   [${i}] Typ: ${isDataUrl ? 'Base64 Data URL' : isHttpUrl ? 'HTTP URL' : 'Unbekannt'}, Länge: ${img.length}`);
                } else {
                    console.log(`   [${i}] Kein String! Typ: ${typeof img}`);
                }
            });
        } else {
            console.log('   allBase64Images: NICHT VORHANDEN');
        }
        
        if (payload.allPhotoUrls) {
            console.log(`   allPhotoUrls: Array mit ${payload.allPhotoUrls.length} Einträgen`);
            payload.allPhotoUrls.forEach((url, i) => {
                console.log(`   [${i}] ${url.substring(0, 100)}...`);
            });
        } else {
            console.log('   allPhotoUrls: NICHT VORHANDEN');
        }
        
        console.log('\n📋 Form Data:');
        console.log(JSON.stringify(payload.formData, null, 2));
        
        console.log('\n⚙️ Weitere Parameter:');
        console.log(`   subscriptionType: ${payload.subscriptionType}`);
        console.log(`   userLanguage: ${payload.userLanguage}`);
        console.log(`   isFollowUp: ${payload.isFollowUp}`);
        
        console.log('\n' + '='.repeat(80));
        console.log('✅ DEBUG ABGESCHLOSSEN');
        console.log('='.repeat(80) + '\n');
        
        return Response.json({
            success: true,
            message: "Debug erfolgreich - Parameter wurden geloggt",
            summary: {
                user: user?.email,
                hasBase64Images: !!payload.allBase64Images,
                base64ImagesCount: payload.allBase64Images?.length || 0,
                hasPhotoUrls: !!payload.allPhotoUrls,
                photoUrlsCount: payload.allPhotoUrls?.length || 0,
                formData: payload.formData,
                subscriptionType: payload.subscriptionType,
                userLanguage: payload.userLanguage
            }
        });
        
    } catch (error) {
        console.error('\n❌ DEBUG FEHLER:', error.message);
        console.error('Stack:', error.stack);
        
        return Response.json({
            success: false,
            error: error.message,
            stack: error.stack
        }, { status: 500 });
    }
});