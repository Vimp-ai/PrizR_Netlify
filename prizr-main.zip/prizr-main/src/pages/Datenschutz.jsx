import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Datenschutz() {
  const navigate = useNavigate();

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button 
          variant="outline" 
          size="icon"
          onClick={() => navigate(createPageUrl("Dashboard"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-slate-50">Datenschutzerklärung</h1>
          <p className="text-slate-400">Informationen zur Datenverarbeitung</p>
        </div>
      </div>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>Datenschutz</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 text-slate-300">
          <div>
            <h3 className="font-semibold text-slate-100 mb-2 text-lg">1. Datenschutz auf einen Blick</h3>
            <h4 className="font-semibold text-slate-200 mb-2">Allgemeine Hinweise</h4>
            <p className="text-sm">
              Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie diese Website besuchen. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2 text-lg">2. Verantwortliche Stelle</h3>
            <p className="text-sm">
              Die verantwortliche Stelle für die Datenverarbeitung auf dieser Website ist:<br /><br />
              [HIER IHRE KONTAKTDATEN AUS DEM IMPRESSUM EINTRAGEN]
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2 text-lg">3. Datenerfassung auf dieser Website</h3>
            <h4 className="font-semibold text-slate-200 mb-2">Welche Daten werden erfasst?</h4>
            <p className="text-sm mb-3">
              Wir erfassen folgende Daten:
            </p>
            <ul className="list-disc list-inside text-sm space-y-1 ml-4">
              <li>Registrierungsdaten (E-Mail-Adresse, Name)</li>
              <li>Hochgeladene Bilder für die Möbelbewertung</li>
              <li>Bewertungsergebnisse und Historie</li>
              <li>Zahlungsinformationen (über PayPal/Stripe)</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2 text-lg">4. KI-Verarbeitung</h3>
            <p className="text-sm">
              Ihre hochgeladenen Bilder werden zur Analyse an Google Gemini AI übermittelt. Die Verarbeitung erfolgt ausschließlich zum Zweck der Möbelbewertung. Die Bilder werden nicht für andere Zwecke verwendet oder an Dritte weitergegeben.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2 text-lg">5. Ihre Rechte</h3>
            <p className="text-sm mb-3">
              Sie haben jederzeit das Recht:
            </p>
            <ul className="list-disc list-inside text-sm space-y-1 ml-4">
              <li>Auskunft über Ihre gespeicherten Daten zu erhalten</li>
              <li>Berichtigung unrichtiger Daten zu verlangen</li>
              <li>Löschung Ihrer Daten zu fordern</li>
              <li>Einschränkung der Verarbeitung zu verlangen</li>
              <li>Der Datenverarbeitung zu widersprechen</li>
              <li>Datenübertragbarkeit zu verlangen</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2 text-lg">6. Zahlungsdienstleister</h3>
            <p className="text-sm">
              Wir nutzen externe Zahlungsdienstleister (PayPal, Stripe), über deren Plattformen die Zahlungen abgewickelt werden. Es gelten die Datenschutzbestimmungen der jeweiligen Anbieter.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-100 mb-2 text-lg">7. Kontakt</h3>
            <p className="text-sm">
              Bei Fragen zum Datenschutz kontaktieren Sie uns unter:<br />
              [IHRE DATENSCHUTZ-E-MAIL]
            </p>
          </div>

          <div className="text-xs text-slate-500 pt-4 border-t border-slate-700">
            <p>Stand: {new Date().toLocaleDateString('de-DE')}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}