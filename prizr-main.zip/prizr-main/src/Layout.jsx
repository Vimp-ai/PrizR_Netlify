
import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { History, Home, Gem, User, Shield, FileText, LogOut } from "lucide-react";
import { base44 } from "@/api/base44Client";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger
} from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: Home
  },
  {
    title: "Historie",
    url: createPageUrl("Historie"),
    icon: History
  },
  {
    title: "Abonnement",
    url: createPageUrl("Abonnement"),
    icon: Gem
  },
  {
    title: "Profil",
    url: createPageUrl("Profil"),
    icon: User
  }
];

// Öffentlich zugängliche Seiten (ohne Login)
const publicPages = ['Impressum', 'Datenschutz', 'ComingSoon', 'Dashboard', 'Zustimmungen'];

// WARTUNGSMODUS: Nur diese Seiten sind erreichbar
const maintenanceModePages = ['ComingSoon', 'Admin'];

// Zentrales Logo (wird überall verwendet)
const PRIZR_LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68cd430ed0ac70a8dad89157/2ec71407a_Priz_Freigestellt.png";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [user, setUser] = useState(null);
  const [isMaintenanceMode] = useState(false); // WARTUNGSMODUS AN/AUS (auf false für Produktion)

  useEffect(() => {
    checkAuth();
  }, [currentPageName]);

  const checkAuth = async () => {
    try {
      const authenticated = await base44.auth.isAuthenticated();
      setIsAuthenticated(authenticated);
      
      if (authenticated) {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        // WARTUNGSMODUS-LOGIK
        if (isMaintenanceMode) {
          console.log('🔒 Wartungsmodus aktiv');
          console.log('👤 User:', currentUser.email, 'Role:', currentUser.role);
          console.log('📄 Aktuelle Seite:', currentPageName);
          
          // WICHTIG: Admins haben vollen Zugriff auf ALLE Seiten
          if (currentUser.role === 'admin') {
            console.log('✅ Admin erkannt - voller Zugriff gewährt');
            return; // Keine Weiterleitung, Admin darf überall hin
          }
          
          // Normale User: Nur Coming Soon erlaubt
          if (currentPageName !== 'ComingSoon') {
            console.log('🚫 Normaler User im Wartungsmodus - Weiterleitung zu Coming Soon');
            navigate(createPageUrl("ComingSoon"));
            return;
          }
        }
        
        // NEU: Prüfe ob User Zustimmungen gegeben hat (außer auf Zustimmungen-Seite selbst)
        if (!currentUser.hasAcceptedTerms && currentPageName !== 'Zustimmungen' && !publicPages.includes(currentPageName)) {
          console.log('⚠️ User hat noch nicht zugestimmt - Weiterleitung zu Zustimmungen');
          navigate(createPageUrl("Zustimmungen"));
          return;
        }
        
      } else {
        // Nicht eingeloggt
        if (isMaintenanceMode) {
          // Im Wartungsmodus: nur Coming Soon erlaubt
          if (currentPageName !== 'ComingSoon') {
            console.log('🔒 Wartungsmodus: Nicht authentifiziert - Weiterleitung zu Coming Soon');
            navigate(createPageUrl("ComingSoon"));
            return;
          }
        } else {
          // Normalbetrieb: Öffentliche Seiten erlauben
          if (!publicPages.includes(currentPageName)) {
            console.log('🔒 Nicht authentifiziert - Weiterleitung zum Login');
            base44.auth.redirectToLogin(window.location.pathname);
            return;
          }
        }
      }
    } catch (error) {
      console.error('Auth Check Error:', error);
      // Bei Fehler: Im Wartungsmodus zu Coming Soon, sonst zu Login
      if (isMaintenanceMode) {
        navigate(createPageUrl("ComingSoon"));
        return;
      } else if (!publicPages.includes(currentPageName)) {
        base44.auth.redirectToLogin(window.location.pathname);
        return;
      }
      setIsAuthenticated(false);
    }
  };

  const handleLogout = async () => {
    try {
      await base44.auth.logout();
    } catch (error) {
      console.error('Logout Error:', error);
      window.location.reload();
    }
  };

  // Zeige öffentliche Seiten immer an (auch im Wartungsmodus)
  if (publicPages.includes(currentPageName) && !isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-50">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Libre+Caslon+Display:wght@400;700&display=swap');

          :root {
            --background: 224 71% 4%;
            --foreground: 210 40% 98%;
            --card: 224 71% 6%;
            --card-foreground: 210 40% 98%;
            --popover: 224 71% 4%;
            --popover-foreground: 210 40% 98%;
            --primary: 210 40% 98%;
            --primary-foreground: 222.2 47.4% 11.2%;
            --secondary: 217.2 32.6% 17.5%;
            --secondary-foreground: 210 40% 98%;
            --muted: 217.2 32.6% 17.5%;
            --muted-foreground: 215 20.2% 65.1%;
            --accent: 217.2 32.6% 17.5%;
            --accent-foreground: 210 40% 98%;
            --destructive: 0 62.8% 30.6%;
            --destructive-foreground: 210 40% 98%;
            --border: 217.2 32.6% 17.5%;
            --input: 217.2 32.6% 17.5%;
            --ring: 216 91% 68%;
            --font-family-heading: 'Libre Caslon Display', serif;
          }

          h1, h2, h3, h4, h5, h6 {
            font-family: 'Libre Caslon Display', serif;
          }

          .brand-text {
            font-family: 'Libre Caslon Display', serif;
          }
        `}</style>
        
        <header className="bg-slate-900 border-b border-slate-800 px-6 py-4">
          <div className="flex items-center justify-between max-w-7xl mx-auto">
            <Link to={createPageUrl("Dashboard")} className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden shadow-lg bg-transparent">
                <img 
                  src={PRIZR_LOGO_URL}
                  alt="Prizr Logo" 
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-xl font-bold brand-text">Prizr</span>
            </Link>
            
            <div className="flex items-center gap-4">
              <Link to={createPageUrl("Impressum")} className="text-slate-400 hover:text-slate-200 text-sm">
                Impressum
              </Link>
              <Link to={createPageUrl("Datenschutz")} className="text-slate-400 hover:text-slate-200 text-sm">
                Datenschutz
              </Link>
            </div>
          </div>
        </header>
        
        {children}
      </div>
    );
  }

  // Warte auf Auth-Check für geschützte Seiten
  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-cyan-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-400">Authentifizierung wird geprüft...</p>
        </div>
      </div>
    );
  }

  // Wenn nicht authentifiziert, wird bereits redirected in checkAuth
  if (!isAuthenticated) {
    return null;
  }

  return (
    <SidebarProvider defaultOpen={false}>
      <div className="min-h-screen flex w-full bg-background text-slate-50">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Libre+Caslon+Display:wght@400;700&display=swap');

          :root {
            --background: 224 71% 4%;
            --foreground: 210 40% 98%;
            --card: 224 71% 6%;
            --card-foreground: 210 40% 98%;
            --popover: 224 71% 4%;
            --popover-foreground: 210 40% 98%;
            --primary: 210 40% 98%;
            --primary-foreground: 222.2 47.4% 11.2%;
            --secondary: 217.2 32.6% 17.5%;
            --secondary-foreground: 210 40% 98%;
            --muted: 217.2 32.6% 17.5%;
            --muted-foreground: 215 20.2% 65.1%;
            --accent: 217.2 32.6% 17.5%;
            --accent-foreground: 210 40% 98%;
            --destructive: 0 62.8% 30.6%;
            --destructive-foreground: 210 40% 98%;
            --border: 217.2 32.6% 17.5%;
            --input: 217.2 32.6% 17.5%;
            --ring: 216 91% 68%;
            --font-family-heading: 'Libre Caslon Display', serif;
          }

          h1, h2, h3, h4, h5, h6 {
            font-family: 'Libre Caslon Display', serif;
          }

          .brand-text {
            font-family: 'Libre Caslon Display', serif;
          }
        `}</style>
        
        <Sidebar className="border-r border-slate-800 bg-slate-900 shadow-lg">
          <SidebarHeader className="bg-card p-6 flex flex-col gap-2 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl overflow-hidden shadow-lg flex-shrink-0 bg-transparent">
                <img 
                  src={PRIZR_LOGO_URL}
                  alt="Prizr Logo" 
                  className="w-full h-full object-cover"
                  style={{ objectPosition: 'center' }}
                />
              </div>
              <div>
                <h2 className="font-bold text-slate-100 text-xl brand-text">Prizr</h2>
                <p className="text-xs text-slate-400">Professionelle Möbelbewertung</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="bg-card p-4 flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-2 py-3">
                Navigation
              </SidebarGroupLabel>
              <SidebarMenu>
                {navigationItems.map((item) =>
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      className={`hover:bg-cyan-900/20 hover:text-cyan-400 transition-colors duration-200 rounded-xl mb-2 ${
                        location.pathname === item.url ? 'bg-cyan-900/30 text-cyan-400 font-medium' : 'text-slate-300'
                      }`}
                    >
                      <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                        <item.icon className="w-5 h-5" />
                        <span className="font-medium">{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )}
              </SidebarMenu>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="bg-card p-4 flex flex-col gap-2 border-t border-slate-800">
            <Link to={createPageUrl("Profil")} className="flex items-center gap-3 hover:bg-slate-800 p-2 rounded-lg transition-colors">
              <div className="w-9 h-9 bg-slate-700 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-slate-300" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-slate-100 text-sm truncate">{user?.full_name || 'Benutzer'}</p>
                <p className="text-xs text-slate-400 truncate">{user?.email}</p>
              </div>
            </Link>
            
            <Separator className="bg-slate-800 my-2" />
            
            <div className="space-y-1">
              <Link 
                to={createPageUrl("Impressum")} 
                className="flex items-center gap-3 px-2 py-2 hover:bg-slate-800 rounded-lg transition-colors text-xs text-slate-400 hover:text-slate-200"
              >
                <FileText className="w-4 h-4" />
                <span>Impressum</span>
              </Link>
              <Link 
                to={createPageUrl("Datenschutz")} 
                className="flex items-center gap-3 px-2 py-2 hover:bg-slate-800 rounded-lg transition-colors text-xs text-slate-400 hover:text-slate-200"
              >
                <Shield className="w-4 h-4" />
                <span>Datenschutz</span>
              </Link>
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-2 py-2 hover:bg-slate-800 rounded-lg transition-colors text-xs text-red-400 hover:text-red-300"
              >
                <LogOut className="w-4 h-4" />
                <span>Abmelden</span>
              </button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col overflow-hidden">
          <header className="bg-slate-900 border-b border-slate-800 px-6 py-4 shadow-sm">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-slate-800 p-2 rounded-xl transition-colors duration-200 text-slate-50" />
              <h1 className="text-xl font-bold text-slate-100 brand-text">Prizr</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
