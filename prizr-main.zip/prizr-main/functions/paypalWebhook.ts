import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

function getPlanTypeFromPaypalId(planId) {
    const proPlanId = Deno.env.get("PAYPAL_PRO_PLAN_ID");
    if (planId === proPlanId) return 'pro';
    return 'free';
}

Deno.serve(async (req) => {
    try {
        const paypalClientId = Deno.env.get("PAYPAL_CLIENT_ID");
        const paypalClientSecret = Deno.env.get("PAYPAL_CLIENT_SECRET");
        const paypalWebhookId = Deno.env.get("PAYPAL_WEBHOOK_ID");
        const paypalSandbox = Deno.env.get("PAYPAL_SANDBOX") === "true";

        if (!paypalClientId || !paypalClientSecret || !paypalWebhookId) {
            return Response.json({ error: 'PayPal Konfiguration fehlt' }, { status: 500 });
        }

        const baseUrl = paypalSandbox ? 
            "https://api-m.sandbox.paypal.com" : 
            "https://api-m.paypal.com";

        const body = await req.text();
        const headers = req.headers;

        // PayPal Access Token abrufen für Webhook-Verification
        const tokenResponse = await fetch(`${baseUrl}/v1/oauth2/token`, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Accept-Language': 'en_US',
                'Authorization': `Basic ${btoa(`${paypalClientId}:${paypalClientSecret}`)}`
            },
            body: 'grant_type=client_credentials'
        });

        const tokenData = await tokenResponse.json();
        const accessToken = tokenData.access_token;

        // Webhook Signature verifizieren
        const verificationResponse = await fetch(`${baseUrl}/v1/notifications/verify-webhook-signature`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`
            },
            body: JSON.stringify({
                auth_algo: headers.get('PAYPAL-AUTH-ALGO'),
                cert_url: headers.get('PAYPAL-CERT-URL'),
                transmission_id: headers.get('PAYPAL-TRANSMISSION-ID'),
                transmission_sig: headers.get('PAYPAL-TRANSMISSION-SIG'),
                transmission_time: headers.get('PAYPAL-TRANSMISSION-TIME'),
                webhook_id: paypalWebhookId,
                webhook_event: JSON.parse(body)
            })
        });

        const verificationResult = await verificationResponse.json();
        if (verificationResult.verification_status !== 'SUCCESS') {
            console.error('PayPal Webhook verification failed:', verificationResult);
            return Response.json({ error: 'Invalid webhook signature' }, { status: 400 });
        }

        const event = JSON.parse(body);
        const base44 = createClientFromRequest(req);

        console.log('PayPal Webhook Event:', event.event_type);

        switch (event.event_type) {
            case 'BILLING.SUBSCRIPTION.ACTIVATED': {
                const subscription = event.resource;
                const userId = subscription.custom_id;
                
                if (!userId) {
                    console.error('No user ID in PayPal subscription');
                    break;
                }

                const planType = getPlanTypeFromPaypalId(subscription.plan_id);

                const subscriptionEndDate = new Date();
                subscriptionEndDate.setMonth(subscriptionEndDate.getMonth() + 1);

                await base44.asServiceRole.entities.User.update(userId, {
                    subscriptionType: planType,
                    subscriptionEndDate: subscriptionEndDate.toISOString().split('T')[0]
                });

                console.log(`PayPal subscription activated for user ${userId}, plan: ${planType}`);
                break;
            }

            case 'BILLING.SUBSCRIPTION.CANCELLED': {
                const subscription = event.resource;
                const userId = subscription.custom_id;
                
                if (userId) {
                    await base44.asServiceRole.entities.User.update(userId, {
                        subscriptionType: 'free',
                        subscriptionEndDate: null
                    });
                    console.log(`PayPal subscription cancelled for user ${userId}`);
                }
                break;
            }

            case 'BILLING.SUBSCRIPTION.SUSPENDED': {
                const subscription = event.resource;
                const userId = subscription.custom_id;
                
                if (userId) {
                    console.log(`PayPal subscription suspended for user ${userId}`);
                }
                break;
            }

            case 'PAYMENT.SALE.COMPLETED': {
                const sale = event.resource;
                console.log('PayPal payment completed:', sale.id);
                break;
            }

            default:
                console.log(`Unhandled PayPal event type: ${event.event_type}`);
        }

        return Response.json({ received: true });

    } catch (error) {
        console.error('PayPal Webhook Error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});