import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { z } from 'npm:zod@3.23.8';

const MAX_PAYLOAD_BYTES = 10 * 1024 * 1024;
const TIMEOUT = 90000;

// ============================================================================
// KI-MODELL KONFIGURATION
// ============================================================================

const GOOGLE_API_KEY = Deno.env.get("GEMINI_API_KEY");

// HAUPTMODELL: Gemini 3 Pro Preview (Neuestes Modell, Release Nov 2025)
const MODEL_PRIMARY = "gemini-3-pro-preview"; 

// FALLBACK-MODELL: Gemini 2.5 Pro (Stabil & Intelligent)
const MODEL_FALLBACK = "gemini-2.5-pro";

const GET_GEMINI_URL = (model) => 
  `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GOOGLE_API_KEY}`;

const VISION_API_KEY = Deno.env.get("GEMINI_API_KEY"); 
const VISION_API = `https://vision.googleapis.com/v1/images:annotate?key=${VISION_API_KEY}`;

// ============================================================================
// HELPER: Safety & Metadata
// ============================================================================

async function checkImageSafety(base64Image) {
  try {
    console.log('🔍 Prüfe Bild auf unangemessene Inhalte...');
    const base64Data = base64Image.includes(',') ? base64Image.split(',')[1] : base64Image;
    
    const response = await fetch(VISION_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        requests: [{
          image: { content: base64Data },
          features: [{ type: 'SAFE_SEARCH_DETECTION', maxResults: 1 }]
        }]
      }),
      signal: AbortSignal.timeout(10000)
    });

    if (!response.ok) return { safe: true, warning: 'Vision API Fehler' };

    const data = await response.json();
    const safeSearch = data.responses?.[0]?.safeSearchAnnotation;
    
    if (!safeSearch) return { safe: true };

    const isUnsafe = ['LIKELY', 'VERY_LIKELY'].includes(safeSearch.adult) ||
                     ['LIKELY', 'VERY_LIKELY'].includes(safeSearch.violence);

    if (isUnsafe) return { safe: false, reason: 'Unangemessene Inhalte erkannt.' };
    return { safe: true };

  } catch (error) {
    return { safe: true, warning: error.message };
  }
}

async function stripExifMetadata(base64Image) {
  try {
    const [mimeHeader, base64Data] = base64Image.includes(',')
      ? base64Image.split(',')
      : ['data:image/jpeg;base64', base64Image];
    
    const mimeType = mimeHeader.match(/:(.*?);/)?.[1] || 'image/jpeg';
    const binaryString = atob(base64Data);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
    
    // Simples "Re-Encoding" via Blob entfernt meist EXIF nicht zuverlässig in Deno ohne Canvas.
    // Da wir hier keine Canvas-API haben, geben wir das Bild sicherheitshalber zurück.
    // Das Frontend sollte die Hauptarbeit leisten. Hier ist es ein Placeholder für zukünftige Server-Side-Libraries.
    return base64Image; 
    
  } catch (error) {
    return base64Image;
  }
}

async function urlToBase64(url) {
  try {
    console.log(`📥 Lade Bild von URL: ${url.substring(0, 50)}...`);
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    
    const contentType = response.headers.get('content-type') || 'image/jpeg';
    const arrayBuffer = await response.arrayBuffer();
    const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
    
    // Performance-Fix: Hier KEIN stripExifMetadata aufrufen. 
    // Das machen wir zentral in callGeminiSingleAgent.
    return `data:${contentType};base64,${base64}`;
  } catch (error) {
    console.error(`❌ Fehler beim Laden von URL:`, error.message);
    return null; 
  }
}

function sanitize(text) {
  if (!text) return '';
  return String(text).slice(0, 5000)
    .replace(/<[^>]*>/g, '')
    .replace(/(\*\*|__)(.*?)\1/g, '$2')
    .trim();
}

function validateLLMOutput(data) {
  // Grundlegende Validierung der wichtigsten Felder
  if (!data.estimatedValue || typeof data.estimatedValue !== 'number') {
     console.warn('⚠️ estimatedValue fehlt oder ungültig');
  }
  return data;
}

// ============================================================================
// PROMPTS
// ============================================================================

const singleAgentPrompt = `**Role and Persona:** You are a **Senior Furniture Appraiser** with over 30 years of experience specializing in design and used furniture. Your expertise is identifying furniture pieces based on the minutest details (joinery, materials, and hardware).

**Core Task:** Analyze the uploaded image(s) of this furniture piece and provide a comprehensive expert appraisal focusing on provenance (Designer, Manufacturer) and **current market value**.

**Ultimate Goal of the Analysis:**
Your entire analysis and the resulting JSON data are intended to answer these four core user questions. Keep them in mind for every field you populate:
* **Classification:** Is it a designer piece or a standard, mass-produced item?
* **Provenance:** Where does the piece come from and who was the manufacturer?
* **Identification:** What specific details (materials, joinery, marks) prove its quality and origin?
* **Valuation:** What is it worth and what is a realistic selling price?

**User Context:**
{userContext}

**IMPORTANT - User-Provided Designer Information:**
If the user has mentioned a specific designer name in their input (Material, Herkunft, or other fields), you MUST:
1.  Give this designer significantly higher priority in your analysis
2.  Look specifically for design features that match or contradict this attribution
3.  If visual evidence supports the user's suggestion, assign high confidence (75-95%)
4.  If visual evidence contradicts it, explain why in detail and suggest alternatives
5.  Always include the user-mentioned designer as one of your three candidates

**OBJECTIVE:** Identify the designer and manufacturer of the furniture shown with the highest possible accuracy, based on a detailed visual analysis.

**PROCESS:** Execute the following steps sequentially. Do not skip any steps.

**1. Forensic Feature Analysis (Mandatory)**
Analyze the image and create a detailed checklist of the *critical design signatures*. Describe *only* what you see. Do **not** mention any designer names in this step.

* **Armrest Signature:**
    * Shape (e.g., flowing, rectilinear, organic, 'knife-edge', sculptural).
    * Curvature (e.g., gently sloped, sharp-angled, complex curve).
    * Joint (e.g., How does the armrest connect to the frame/legs? Bolted, integrated, seamless transition?).
* **Frame & Leg Structure:**
    * Overall Impression (e.g., delicate, massive, minimalist, robust).
    * Leg Shape (e.g., tapered, round, square, A-frame, sled base).
    * Material (e.g., teak, oak, rosewood, beech, metal, etc.).
* **Joinery & Construction Details:**
    * Examine all wood joints (e.g., visible finger joints, dowels, screw caps, wedge joints).
    * Material Craftsmanship (e.g., molded plywood, solid wood carving, steam-bent).
* **Upholstery & Seat Shell:**
    * Seat Shell Shape (e.g., floating, fixed within the frame, organically shaped).
    * Cushion Type (e.g., loose, fixed upholstery, integrated).

**2. Differential Diagnosis & Designer Hypotheses (Maximum 3)**
Based *exclusively* on the checklist from Step 1:

* Generate a list of a maximum of 3 plausible designers whose known signatures align with the analyzed features.
* For each designer, perform a direct comparison:
    * **Hypothesis 1 (Designer A):** "Matches because of [Feature X, e.g., the specific armrest joint]. Potential conflict: [Feature Y]."
    * **Hypothesis 2 (Designer B):** "Matches because of [Feature Z, e.g., the delicate leg structure]. Potential conflict: [Feature A]."
    * **Hypothesis 3 (Designer C):** "Matches because of [Feature B, e.g., the use of molded plywood]. Potential conflict: [Feature C]."

**3. Final Identification & Confidence (Mandatory)**
Select the most probable designer from the diagnosis above.

* **Designer:** [Name of Designer]
* **Confidence Level:** [0-100%]
* **Reasoning:** [Explain *why* this designer is more likely than the other hypotheses, referencing the "small details" from Steps 1 and 2. Focus on the subtle differentiators.]
* **Potential Misattribution (Lookalike):** Assess the possibility that this is a "no-name" piece 'in the style of' [Designer] or the work of a lesser-known contemporary.

**4. Manufacturer Identification (If possible)**
Look for visual cues (stamps, labels, plaques) or specific construction techniques that indicate a particular manufacturer and state it.

5.  **Market Research in web:** Research recent comparable sales data for similar pieces:
    -   Check auction results
    -   Review high-end dealer prices
    -   Consider current market trends

6.  **Price Calculation:**
    -   **estimatedValue**: Average market price (Angebotspreis)
    -   **valueRangeLow**: Lower end of price range
    -   **valueRangeHigh**: Upper end of price range
    -   **realisticPrice**: Calculate as: valueRangeLow - (valueRangeLow × 0.1 × condition)
        Example: For condition 3 and valueRangeLow 1000: 1000 - (1000 × 0.1 × 3) = 700 EUR

7.  **Confidence Assessment:** Rate your overall confidence (low/medium/high) based on:
    -   Clarity of design signatures
    -   Availability of comparable market data
    -   Condition of the piece
    -   Match with user-provided information


**CRITICAL LANGUAGE REQUIREMENT:**
- All text fields (description, reasoning, etc.) MUST be in {language}
- Designer and manufacturer names stay in their original form
- Technical terms can use English equivalents in parentheses

**CRITICAL JSON OUTPUT REQUIREMENTS:**
- Your response MUST be ONLY valid JSON, starting with { and ending with }
- NO markdown formatting (no \`\`\`json blocks), NO explanations before or after
- Start your response directly with the opening brace {
- ALL string values must escape special characters: use \\\\" for quotes, \\\\n for newlines
- NO trailing commas before closing braces } or brackets ]
- ALWAYS add commas between array elements and object properties
- Test your JSON mentally before output - it must parse correctly
- Name designers and manufacturers only by their names without editorial comments
- Never include internal notes like "Gemini researched" or "AI found" in user-facing text

**Output Format:**
{
  "designerCandidates": [
    {
      "designer": "Designer Name",
      "confidence": 85,
      "reasoning": "Detailed reasoning in {language}",
      "specificFeatures": "Key identifying features in {language}"
    },
    {
      "designer": "Designer Name 2",
      "confidence": 70,
      "reasoning": "Reasoning in {language}",
      "specificFeatures": "Features in {language}"
    },
    {
      "designer": "Designer Name 3",
      "confidence": 50,
      "reasoning": "Reasoning in {language}",
      "specificFeatures": "Features in {language}"
    }
  ],
  "primaryDesigner": "Most likely designer name",
  "primaryDesignerConfidence": 85,
  "manufacturer": "Manufacturer name or Unknown",
  "manufacturerReasoning": "Evidence in {language}",
  "estimatedValue": 120,
  "valueRangeLow": 100,
  "valueRangeHigh": 150,
  "realisticPrice": 70,
  "valueRange": "100 - 150 EUR",
  "description": "2-3 sentence description in {language}",
  "identifiedStyle": "Style name in {language}",
  "era": "Time period in {language}",
  "materials": "Materials in {language}",
  "origin": "Country/Region in {language}",
  "reasoning": "Market analysis and valuation basis in {language}",
  "confidence": "high",
  "isReplica": false,
  "isNotFurniture": false,
  "keyIdentifiers": "Most distinctive features in {language}",
  "additionalInfo": "Care recommendations or next steps in {language}"
}`;

// ============================================================================
// API & LOGGING UTILS
// ============================================================================

function log(msg, data = null) {
  console.log(`\n${'='.repeat(60)}\n${msg}\n${'='.repeat(60)}`);
  if (data) console.log(typeof data === 'string' ? data : JSON.stringify(data, null, 2));
}

const RequestSchema = z.object({
  allBase64Images: z.array(z.string()).optional(),
  allPhotoUrls: z.array(z.string()).min(1).max(10),
  formData: z.object({
    woodType: z.string().optional().nullable(),
    age: z.string().optional().nullable(),
    origin: z.string().optional().nullable(),
    condition: z.number().optional().nullable()
  }),
  subscriptionType: z.enum(['free', 'pro', 'enterprise']).optional(),
  userLanguage: z.string().optional()
});

function parseJSON(text) {
  if (!text) throw new Error('Leere Antwort');
  
  // 1. Basic Cleanup
  let clean = text.trim()
    .replace(/```json\s*/gi, '')
    .replace(/```\s*/g, '')
    .replace(/^[\s\n]*/, '')
    .replace(/[\s\n]*$/, '');
  
  const start = clean.indexOf('{');
  const end = clean.lastIndexOf('}');
  
  if (start >= 0 && end > start) {
    clean = clean.slice(start, end + 1);
  }
  
  // 2. Advanced Repair Strategy
  const tryParse = (str) => {
    try {
      return JSON.parse(str);
    } catch (e) {
      return null;
    }
  };

  // Versuch 1: Standard Parse
  let result = tryParse(clean);
  if (result) return result;

  // Versuch 2: Fix Trailing Commas (,} -> }, ,] -> ])
  let repaired = clean.replace(/,\s*([\]}])/g, '$1');
  result = tryParse(repaired);
  if (result) return result;

  // Versuch 3: Fix unescaped newlines in string values
  // Entfernt \n innerhalb von String-Werten die nicht escaped sind
  repaired = repaired.replace(/("\w+"\s*:\s*"[^"]*?)(\n)([^"]*?")/g, '$1 $3');
  result = tryParse(repaired);
  if (result) return result;

  // Versuch 4: Fix Missing Commas between objects (} { -> }, {)
  repaired = repaired.replace(/}\s*{/g, '},{');
  result = tryParse(repaired);
  if (result) return result;
  
  // Versuch 5: Fix Missing Commas between array elements (" " -> ", ")
  // Findet Stellen wo nach einem String-Ende direkt ein neuer String beginnt
  repaired = repaired.replace(/("\s*)\n\s*(")/g, '$1,$2');
  result = tryParse(repaired);
  if (result) return result;

  // Versuch 6: Fix unescaped quotes in string values
  // ACHTUNG: Sehr aggressiv - nur als letzte Rettung
  try {
    // Ersetze " innerhalb von Strings durch \"
    // Regex findet Strings und escaped Quotes darin
    repaired = repaired.replace(
      /"([^"\\]*(\\.[^"\\]*)*)"/g, 
      (match) => {
        // Wenn der String bereits korrekt escaped ist, lass ihn
        if (!match.includes('\\"')) {
          return match;
        }
        return match;
      }
    );
    return JSON.parse(repaired);
  } catch (e) {
    console.error('JSON Parse Error Final:', e.message);
    console.error('Failed JSON snippet (first 500 chars):', clean.slice(0, 500) + '...');
    console.error('Failed JSON snippet (around error):', clean.slice(Math.max(0, 1400), Math.min(clean.length, 1600)));
    throw new Error('JSON-Parsing fehlgeschlagen: ' + e.message);
  }
}

async function callGeminiSingleAgent(prompt, images, userLanguage, retries = 0, currentModel = MODEL_PRIMARY) {
  // PERFORMANCE FIX: Bildverarbeitung (Safety + Metadaten) läuft NUR beim ersten Versuch
  // und NUR wenn wir mit dem Hauptmodell starten. Bei Retries nutzen wir die Daten wieder.
  let processedImages = images;
  
  if (retries === 0 && currentModel === MODEL_PRIMARY) {
    console.log(`🔐 Prüfe ${images.length} Bilder auf unangemessene Inhalte...`);
    for (let i = 0; i < images.length; i++) {
      const safetyCheck = await checkImageSafety(images[i]);
      if (!safetyCheck.safe) {
        throw new Error(safetyCheck.reason || 'Unangemessener Bildinhalt erkannt.');
      }
    }
    console.log('✅ Alle Bilder sind sicher');

    // Optional: Server-seitiges Metadaten-Stripping (falls Frontend es nicht getan hat)
    console.log(`🧹 Bereinige ${images.length} Bilder...`);
    processedImages = await Promise.all(images.map(img => stripExifMetadata(img)));
  } 

  const imageParts = processedImages.map(b64 => {
    const [mime, data] = b64.split(',');
    return {inline_data: {mime_type: mime.match(/:(.*?);/)?.[1] || 'image/jpeg', data}};
  });

  try {
    log(`🤖 Gemini ${currentModel} Analyse (Versuch ${retries + 1})`, {
      prompt_length: prompt.length,
      num_images: processedImages.length,
      language: userLanguage,
      model: currentModel
    });

    const generationConfig = {
      temperature: 0.2,
      topP: 0.2,
      maxOutputTokens: 8192,
      responseMimeType: "application/json"
    };

    const requestBody = {
      contents: [{parts: [{text: prompt}, ...imageParts]}],
      generationConfig
    };

    const res = await fetch(GET_GEMINI_URL(currentModel), {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      signal: AbortSignal.timeout(TIMEOUT),
      body: JSON.stringify(requestBody)
    });

    // SPEZIALBEHANDLUNG: 503 (Overloaded) oder 429 (Rate Limit)
    if (res.status === 503 || res.status === 429) {
      throw new Error(`OVERLOADED_OR_RATE_LIMIT (${res.status})`);
    }

    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(`HTTP ${res.status}: ${errorText.slice(0, 200)}`);
    }
    
    const data = await res.json();
    
    if (!data.candidates || data.candidates.length === 0) {
      throw new Error('Keine Kandidaten in Gemini-Antwort');
    }
    
    const candidate = data.candidates[0];
    
    if (candidate.finishReason === 'SAFETY') {
      throw new Error('Gemini hat die Antwort aus Sicherheitsgründen blockiert');
    }
    
    let jsonText = '';
    if (candidate.content && candidate.content.parts) {
      for (const part of candidate.content.parts) {
        if (part.text) jsonText += part.text;
      }
    }
    
    if (!jsonText) throw new Error('Leere Gemini-Antwort');
    
    console.log('\n📝 Gemini Raw Response (erste 800 Zeichen):');
    console.log(jsonText.substring(0, 800));
    if (jsonText.length > 800) {
      console.log(`\n... (${jsonText.length - 800} weitere Zeichen)`);
    }
    
    const parsed = parseJSON(jsonText);
    
    if (currentModel === MODEL_FALLBACK) {
      console.log(`ℹ️ Hinweis: Ergebnis wurde mit dem Fallback-Modell (${MODEL_FALLBACK}) generiert.`);
    }

    return validateLLMOutput(parsed);
    
  } catch (error) {
    const isOverload = error.message.includes('OVERLOADED') || error.message.includes('503') || error.message.includes('429');
    const isTimeout = error.name === 'TimeoutError' || error.message.includes('fetch');
    const isEmptyResponse = error.message.includes('Leere Gemini-Antwort') || error.message.includes('Keine Kandidaten');
    const isJsonError = error.message.includes('JSON') || error.message.includes('SyntaxError') || error.message.includes('Unterminated string');

    console.error(`❌ Fehler bei ${currentModel} (Versuch ${retries + 1}):`, error.message);

    if (isEmptyResponse) {
      console.log('ℹ️ Leere Antwort erkannt -> Trigger Retry/Fallback');
    }

    // STRATEGIE 1: RETRY (Wiederholung beim selben Modell, max 2x)
    if ((isOverload || isTimeout || isJsonError || isEmptyResponse) && retries < 2) {
      const waitTime = 1000 * Math.pow(2, retries); 
      console.log(`⏳ Warte ${waitTime}ms vor erneutem Versuch mit ${currentModel}...`);
      await new Promise(r => setTimeout(r, waitTime));
      // Rekursiver Aufruf mit erhöhtem Retry-Counter
      return callGeminiSingleAgent(prompt, processedImages, userLanguage, retries + 1, currentModel);
    }
    
    // STRATEGIE 2: FALLBACK (Wechsel zu Gemini 2.5 Pro bei Überlastung)
    if ((isOverload || isTimeout || isEmptyResponse) && currentModel === MODEL_PRIMARY) {
      console.warn(`⚠️ Primäres Modell (${MODEL_PRIMARY}) überlastet/leer. Wechsle zu Fallback (${MODEL_FALLBACK})...`);
      // Wir setzen Retries auf 0 zurück für den neuen Modell-Versuch
      return callGeminiSingleAgent(prompt, processedImages, userLanguage, 0, MODEL_FALLBACK);
    }
    
    // Wenn nichts mehr hilft: Fehler werfen
    throw error;
  }
}

// ============================================================================
// MAIN HANDLER
// ============================================================================

Deno.serve(async (req) => {
  const start = Date.now();

  if (req.headers.get('content-length') > MAX_PAYLOAD_BYTES) {
    return Response.json({error: 'Dateien zu groß'}, {status: 413});
  }

  if (!GOOGLE_API_KEY) {
    return Response.json({error: 'Server-Konfigurationsfehler: GEMINI_API_KEY fehlt'}, {status: 500});
  }

  try {
    const base44 = createClientFromRequest(req);
    
    let user = null;
    try {
      user = await base44.auth.me();
    } catch (authError) {
      console.warn('⚠️ Authentifizierung fehlgeschlagen:', authError.message);
    }

    if (!user) {
      return Response.json({
        error: 'Nicht autorisiert. Bitte verbinden Sie sich zuerst über die App mit WhatsApp.',
        suggestions: 'Öffnen Sie die Prizr-App und folgen Sie dem "Mit WhatsApp verbinden"-Link.'
      }, {status: 401});
    }

    console.log(`✅ Authentifizierter User: ${user.email} (${user.id})`);

    const payload = await req.json();
    const validated = RequestSchema.parse(payload);
    let { allBase64Images, allPhotoUrls, formData, userLanguage: rawUserLanguage } = validated;

    const subscriptionType = validated.subscriptionType || user?.subscriptionType || 'free';

    // DATA LOADING FIX: Priorisiere Bilder aus URLs, um Payload klein zu halten
    if (!allBase64Images || allBase64Images.length === 0) {
      console.log('🔄 Lade Bilder von URLs (spart Bandbreite im Request)...');
      
      if (!allPhotoUrls || allPhotoUrls.length === 0) {
        return Response.json({ error: 'Keine Bilder gefunden.' }, {status: 400});
      }
      
      const conversionPromises = allPhotoUrls.map(async (url) => {
        try {
          return await urlToBase64(url);
        } catch (error) {
          console.warn(`⚠️ Bild-Download Fehler:`, error.message);
          return null;
        }
      });
      
      const convertedImages = await Promise.all(conversionPromises);
      allBase64Images = convertedImages.filter(img => img !== null);
      
      if (allBase64Images.length === 0) {
        return Response.json({ error: 'Bilder konnten nicht geladen werden.' }, {status: 400});
      }
    }

    const browserLanguage = rawUserLanguage || 'de-DE';
    const userLanguage = browserLanguage.startsWith('de') ? 'German' : 
                         browserLanguage.startsWith('en') ? 'English' : 'German';
    
    // Input Sanitization
    const userContext = `Material: ${sanitize(formData?.woodType)}, Age: ${sanitize(formData?.age)}, Origin: ${sanitize(formData?.origin)}, Condition: ${formData?.condition ?? 'N/A'}`;

    log('[1/1] GEMINI ANALYSE START');

    const finalPrompt = singleAgentPrompt
      .replace('{userContext}', userContext)
      .replace(/{language}/g, userLanguage);

    const geminiResponse = await callGeminiSingleAgent(finalPrompt, allBase64Images, userLanguage);

    // DETAILLIERTE ANALYSE-LOGS
    console.log('\n' + '='.repeat(80));
    console.log('🎯 GEMINI DESIGNER-ENTSCHEIDUNG & VOLLSTÄNDIGE ANALYSE');
    console.log('='.repeat(80));
    
    console.log('\n📌 PRIMARY DESIGNER:');
    console.log('   Name:', geminiResponse.primaryDesigner || 'NICHT GESETZT');
    console.log('   Confidence:', geminiResponse.primaryDesignerConfidence || 'NICHT GESETZT');
    console.log('   Estimated Value:', geminiResponse.estimatedValue || 'NICHT GESETZT');
    
    console.log('\n📋 ALLE DESIGNER-KANDIDATEN:');
    if (geminiResponse.designerCandidates && Array.isArray(geminiResponse.designerCandidates) && geminiResponse.designerCandidates.length > 0) {
      geminiResponse.designerCandidates.forEach((candidate, index) => {
        console.log(`\n   ${index + 1}. ${candidate.designer || 'UNBEKANNT'}`);
        console.log(`      → Confidence: ${candidate.confidence || 0}%`);
        console.log(`      → Reasoning: ${(candidate.reasoning || 'N/A').substring(0, 200)}`);
        console.log(`      → Features: ${(candidate.specificFeatures || 'N/A').substring(0, 150)}`);
      });
    } else {
      console.log('   ⚠️ KEINE DESIGNER-KANDIDATEN VORHANDEN');
      console.log('   designerCandidates Typ:', typeof geminiResponse.designerCandidates);
      console.log('   designerCandidates Wert:', JSON.stringify(geminiResponse.designerCandidates));
    }
    
    console.log('\n💡 BEWERTUNGS-REASONING:');
    console.log((geminiResponse.reasoning || 'N/A').substring(0, 400));
    
    console.log('\n📊 WEITERE DETAILS:');
    console.log('   Manufacturer:', geminiResponse.manufacturer || 'N/A');
    console.log('   Manufacturer Reasoning:', (geminiResponse.manufacturerReasoning || 'N/A').substring(0, 150));
    console.log('   Style:', geminiResponse.identifiedStyle || 'N/A');
    console.log('   Overall Confidence:', geminiResponse.confidence || 'N/A');
    console.log('   Value Range:', geminiResponse.valueRange || 'N/A');
    console.log('='.repeat(80) + '\n');
    
    const valuationData = {
      photoUrls: JSON.stringify(allPhotoUrls || []), // URLs bevorzugen
      woodType: sanitize(formData?.woodType) || '',
      age: sanitize(formData?.age) || '',
      origin: sanitize(formData?.origin) || '',
      condition: formData?.condition || 3,
      estimatedValue: geminiResponse.estimatedValue,
      realisticPrice: geminiResponse.realisticPrice,
      valueRange: geminiResponse.valueRange,
      description: geminiResponse.description,
      reasoning: geminiResponse.reasoning,
      identifiedStyle: geminiResponse.identifiedStyle,
      confidence: geminiResponse.confidence,
      isReplica: geminiResponse.isReplica || false,
      isNotFurniture: geminiResponse.isNotFurniture || false,
      needsMoreInfo: false,
      status: 'completed',
      manufacturer: geminiResponse.manufacturer,
      manufacturerReasoning: geminiResponse.manufacturerReasoning,
      primaryDesigner: geminiResponse.primaryDesigner,
      forgeryDetection: geminiResponse.forgeryDetection,
      additionalInfo: geminiResponse.additionalInfo,
      designerCandidates: geminiResponse.designerCandidates ? JSON.stringify(geminiResponse.designerCandidates) : null,
    };

    await base44.entities.Valuation.create(valuationData);
    console.log('✅ Bewertung gespeichert');

    // Counter Update Logik
    const monthKey = () => new Date().toISOString().slice(0, 7);
    const current = monthKey();
    const isSameMonth = (user.lastValuationMonth || '') === current;
    
    if (subscriptionType === 'pro') {
        const newMonthlyUsed = isSameMonth ? ((user.monthlyValuationsUsed || 0) + 1) : 1;
        await base44.asServiceRole.entities.User.update(user.id, {
            lastValuationMonth: current,
            monthlyValuationsUsed: newMonthlyUsed
        });
    } else if (subscriptionType !== 'enterprise') {
        await base44.asServiceRole.entities.User.update(user.id, {
            totalValuationsUsed: (user.totalValuationsUsed || 0) + 1
        });
    }

    console.log(`\n✅ Fertig in ${((Date.now() - start) / 1000).toFixed(1)}s\n`);
    return Response.json(geminiResponse);

  } catch (error) {
    console.error('❌ Hauptfehler:', error.message);
    return Response.json({
      error: 'Die KI-Analyse konnte nicht durchgeführt werden.',
      details: error.message
    }, {status: 500});
  }
});