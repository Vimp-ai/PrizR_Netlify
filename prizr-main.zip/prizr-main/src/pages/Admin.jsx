
import React, { useState, useEffect } from "react";
import { User } from "@/entities/User";
import { Valuation } from "@/entities/Valuation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Shield,
  Users,
  Camera,
  Crown,
  Search,
  Calendar,
  Euro,
  CheckCircle,
  XCircle,
  Settings,
  Gem
} from "lucide-react";
import { format } from "date-fns";

export default function Admin() {
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [valuations, setValuations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);

      if (user.role !== 'admin') {
        setError("Sie haben keine Berechtigung für diese Seite.");
        setLoading(false);
        return;
      }

      const allUsers = await User.list();
      const allValuations = await Valuation.list('-created_date');
      
      setUsers(allUsers);
      setValuations(allValuations);
    } catch (error) {
      setError("Fehler beim Laden der Daten.");
    }
    setLoading(false);
  };

  const updateUserSubscription = async (userId, isSubscribed, subscriptionEndDate = null) => {
    try {
      const updateData = { isSubscribed };
      if (subscriptionEndDate) {
        updateData.subscriptionEndDate = subscriptionEndDate;
      }
      
      await User.update(userId, updateData);
      setSuccess(`Abonnement-Status für Benutzer erfolgreich ${isSubscribed ? 'aktiviert' : 'deaktiviert'}.`);
      loadData(); // Reload data
    } catch (error) {
      setError("Fehler beim Aktualisieren des Abonnement-Status.");
    }
  };

  const resetFreeValuations = async (userId) => {
    try {
      await User.update(userId, { freeValuationsUsed: 0 });
      setSuccess("Kostenlose Bewertungen für Benutzer zurückgesetzt.");
      loadData();
    } catch (error) {
      setError("Fehler beim Zurücksetzen der kostenlosen Bewertungen.");
    }
  };

  const filteredUsers = users.filter(user =>
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (user.full_name && user.full_name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const totalRevenue = users.filter(u => u.isSubscribed).length * 4.99;
  const totalValuations = valuations.length;

  if (loading) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-700 rounded w-1/3"></div>
          <div className="grid md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-24 bg-slate-800 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (currentUser?.role !== 'admin') {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <Alert variant="destructive">
          <Shield className="h-4 w-4" />
          <AlertDescription>
            Sie haben keine Berechtigung für diese Seite. Nur Administratoren können auf diesen Bereich zugreifen.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Shield className="w-8 h-8 text-cyan-500" />
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Admin Dashboard</h1>
          <p className="text-slate-400">Benutzer- und Abonnement-Verwaltung für Prizr</p>
        </div>
      </div>

      {/* Alerts */}
      {error && (
        <Alert variant="destructive" className="mb-4">
          <XCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
          <Button variant="outline" size="sm" className="mt-2" onClick={() => setError(null)}>
            Schließen
          </Button>
        </Alert>
      )}

      {success && (
        <Alert className="mb-4 border-teal-700 bg-teal-900/50 text-teal-200">
          <CheckCircle className="h-4 w-4 text-teal-400" />
          <AlertDescription>{success}</AlertDescription>
          <Button variant="outline" size="sm" className="mt-2" onClick={() => setSuccess(null)}>
            Schließen
          </Button>
        </Alert>
      )}

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Benutzer gesamt</p>
                <p className="text-2xl font-bold text-slate-50">{users.length}</p>
              </div>
              <Users className="w-8 h-8 text-cyan-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Premium Mitglieder</p>
                <p className="text-2xl font-bold text-slate-50">
                  {users.filter(u => u.isSubscribed).length}
                </p>
              </div>
              <Gem className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Bewertungen gesamt</p>
                <p className="text-2xl font-bold text-slate-50">{totalValuations}</p>
              </div>
              <Camera className="w-8 h-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Monatsumsatz</p>
                <p className="text-2xl font-bold text-slate-50">
                  {totalRevenue.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                </p>
              </div>
              <Euro className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* User Management */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Benutzerverwaltung
            </CardTitle>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <Input
                placeholder="Benutzer suchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64 pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-slate-800">
                  <TableHead>Benutzer</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Bewertungen</TableHead>
                  <TableHead>Registriert</TableHead>
                  <TableHead>Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => {
                  const userValuations = valuations.filter(v => v.created_by === user.email);
                  return (
                    <TableRow key={user.id} className="border-slate-800">
                      <TableCell>
                        <div>
                          <p className="font-medium text-slate-100">
                            {user.full_name || user.email}
                          </p>
                          <p className="text-sm text-slate-400">{user.email}</p>
                          {user.role === 'admin' && (
                            <Badge variant="secondary" className="text-xs mt-1">Admin</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {user.isSubscribed ? (
                            <Badge className="bg-yellow-900 text-yellow-200 border-yellow-700">
                              <Gem className="w-3 h-3 mr-1" />
                              Premium
                            </Badge>
                          ) : (
                            <Badge variant="outline">Kostenlos</Badge>
                          )}
                          <div className="text-xs text-slate-400">
                            Gratis genutzt: {user.freeValuationsUsed || 0}/1
                          </div>
                          {user.subscriptionEndDate && (
                            <div className="text-xs text-slate-400">
                              Bis: {format(new Date(user.subscriptionEndDate), 'dd.MM.yyyy')}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-center">
                          <p className="font-medium">{userValuations.length}</p>
                          <p className="text-xs text-slate-400">
                            Wert: {userValuations.reduce((sum, v) => sum + (v.estimatedValue || 0), 0).toLocaleString('de-DE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 })}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm text-slate-400">
                          {format(new Date(user.created_date), 'dd.MM.yyyy')}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-2">
                          {user.isSubscribed ? (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateUserSubscription(user.id, false)}
                              className="text-xs"
                            >
                              Premium deaktivieren
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              onClick={() => {
                                const endDate = new Date();
                                endDate.setMonth(endDate.getMonth() + 1);
                                updateUserSubscription(user.id, true, endDate.toISOString().split('T')[0]);
                              }}
                              className="bg-yellow-600 hover:bg-yellow-700 text-yellow-50 text-xs"
                            >
                              Premium aktivieren
                            </Button>
                          )}
                          
                          {(user.freeValuationsUsed || 0) > 0 && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => resetFreeValuations(user.id)}
                              className="text-xs"
                            >
                              Gratis zurücksetzen
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Recent Valuations */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>Letzte Bewertungen</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-slate-800">
                  <TableHead>Benutzer</TableHead>
                  <TableHead>Beschreibung</TableHead>
                  <TableHead>Wert</TableHead>
                  <TableHead>Datum</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {valuations.slice(0, 10).map((valuation) => (
                  <TableRow key={valuation.id} className="border-slate-800">
                    <TableCell>
                      <div className="text-sm text-slate-400">
                        {valuation.created_by}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium text-sm text-slate-100">
                          {valuation.description || valuation.identifiedStyle || 'Möbelstück'}
                        </p>
                        {valuation.identifiedStyle && (
                          <p className="text-xs text-slate-500">{valuation.identifiedStyle}</p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium text-teal-400">
                        {valuation.estimatedValue?.toLocaleString('de-DE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }) || 'N/A'}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-slate-400">
                        {format(new Date(valuation.created_date), 'dd.MM.yyyy HH:mm')}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
