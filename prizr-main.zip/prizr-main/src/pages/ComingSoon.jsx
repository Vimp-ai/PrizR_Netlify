
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Loader2, AlertTriangle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

// Zentrales Logo
const PRIZR_LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68cd430ed0ac70a8dad89157/2ec71407a_Priz_Freigestellt.png";

export default function ComingSoon() {
  const navigate = useNavigate();
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleAdminLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Prüfe ob User bereits eingeloggt ist
      const isAuth = await base44.auth.isAuthenticated();
      
      if (!isAuth) {
        // Wenn nicht eingeloggt, leite zum Google SSO Login weiter
        console.log('🔐 User nicht eingeloggt, leite zum Login weiter...');
        base44.auth.redirectToLogin(window.location.pathname);
        return;
      }

      // User ist eingeloggt, hole User-Daten
      const user = await base44.auth.me();
      console.log('👤 User eingeloggt:', user.email, 'Role:', user.role);
      
      // Prüfe ob die eingegebene E-Mail mit dem eingeloggten User übereinstimmt
      if (user.email.toLowerCase() !== email.toLowerCase()) {
        setError("Die eingegebene E-Mail-Adresse stimmt nicht mit Ihrem Login überein.");
        setLoading(false);
        return;
      }
      
      // Prüfe Admin-Rolle
      if (user.role !== 'admin') {
        setError("Sie haben keine Admin-Berechtigung.");
        setLoading(false);
        return;
      }

      // Prüfe Passwort (Admin-Passwort sollte als Environment Variable gesetzt sein)
      // Für Sicherheit: Rufe eine Backend-Funktion auf, die das Passwort prüft
      try {
        const { data } = await base44.functions.invoke('verifyAdminPassword', { 
          email: user.email,
          password: password 
        });
        
        if (!data.success) {
          setError("Falsches Passwort.");
          setLoading(false);
          return;
        }
      } catch (verifyError) {
        console.error('Passwort-Verifizierung fehlgeschlagen:', verifyError);
        setError("Passwort-Überprüfung fehlgeschlagen. Bitte versuchen Sie es erneut.");
        setLoading(false);
        return;
      }

      // Alles OK - leite zur Admin-Seite weiter
      console.log('✅ Admin-Login erfolgreich');
      navigate(createPageUrl("Admin"));
      
    } catch (err) {
      console.error("Login-Fehler:", err);
      setError("Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center relative overflow-hidden">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Libre+Caslon+Display:wght@400;700&display=swap');

        .brand-text {
          font-family: 'Libre Caslon Display', serif;
        }

        @keyframes float {
          0%, 100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-20px);
          }
        }

        .floating {
          animation: float 6s ease-in-out infinite;
        }

        @keyframes pulse-glow {
          0%, 100% {
            opacity: 0.5;
          }
          50% {
            opacity: 0.8;
          }
        }

        .pulse-glow {
          animation: pulse-glow 4s ease-in-out infinite;
        }
      `}</style>

      {/* Hintergrund-Effekte */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pulse-glow"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pulse-glow" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Hauptinhalt */}
      <div className="relative z-10 text-center px-6">
        <div className="floating mb-8">
          <div className="w-32 h-32 mx-auto mb-6 rounded-3xl overflow-hidden shadow-2xl bg-transparent">
            <img 
              src={PRIZR_LOGO_URL}
              alt="Prizr Logo" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <h1 className="text-6xl md:text-7xl font-bold text-slate-50 mb-4 brand-text">
          Prizr
        </h1>
        
        <p className="text-2xl md:text-3xl text-slate-300 mb-6">
          Professionelle Möbelbewertung
        </p>

        <div className="inline-block bg-gradient-to-r from-cyan-600 to-teal-600 text-white px-8 py-3 rounded-full text-lg font-semibold shadow-lg">
          Coming Soon
        </div>

        <p className="text-slate-400 mt-8 max-w-md mx-auto">
          Wir bereiten etwas Besonderes für Sie vor. Bald können Sie Ihre Möbel professionell bewerten lassen.
        </p>
      </div>

      {/* Admin-Login unten rechts */}
      <div className="absolute bottom-6 right-6">
        {!showAdminLogin ? (
          <button
            onClick={() => setShowAdminLogin(true)}
            className="text-slate-600 hover:text-slate-400 transition-colors text-xs"
          >
            <Shield className="w-4 h-4" />
          </button>
        ) : (
          <Card className="bg-slate-900/95 border-slate-800 backdrop-blur-sm shadow-2xl w-72">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm font-semibold text-slate-200">Admin Login</span>
                </div>
                <button
                  onClick={() => {
                    setShowAdminLogin(false);
                    setError(null);
                    setEmail("");
                    setPassword("");
                  }}
                  className="text-slate-500 hover:text-slate-300"
                >
                  ×
                </button>
              </div>

              <form onSubmit={handleAdminLogin} className="space-y-3">
                <Input
                  type="email"
                  placeholder="Admin E-Mail"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-slate-800 border-slate-700 text-slate-200"
                  required
                />

                <Input
                  type="password"
                  placeholder="Passwort"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-slate-800 border-slate-700 text-slate-200"
                  required
                />

                {error && (
                  <div className="flex items-center gap-2 text-red-400 text-xs">
                    <AlertTriangle className="w-3 h-3" />
                    <span>{error}</span>
                  </div>
                )}

                <Button
                  type="submit"
                  className="w-full bg-cyan-600 hover:bg-cyan-700"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Prüfe...
                    </>
                  ) : (
                    'Anmelden'
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
