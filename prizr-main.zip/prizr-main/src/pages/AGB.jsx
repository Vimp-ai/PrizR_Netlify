import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function AGB() {
  const navigate = useNavigate();

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button 
          variant="outline" 
          size="icon"
          onClick={() => navigate(createPageUrl("Dashboard"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-slate-50">Allgemeine Geschäftsbedingungen</h1>
          <p className="text-slate-400">AGB für die Nutzung von Prizr</p>
        </div>
      </div>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>1. Geltungsbereich</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-300">
          <p>
            Diese Allgemeinen Geschäftsbedingungen (AGB) gelten für die Nutzung der Prizr-Plattform zur KI-gestützten 
            Möbelbewertung. Mit der Registrierung akzeptieren Sie diese Bedingungen.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>2. Leistungen</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-300">
          <p>
            Prizr bietet eine KI-gestützte Bewertung von Möbelstücken anhand hochgeladener Fotos. 
            Die Bewertungen sind Schätzungen und stellen keine verbindlichen Wertgutachten dar.
          </p>
          <h4 className="font-semibold text-slate-200">2.1 Free-Version</h4>
          <p className="text-sm">
            Die kostenlose Version umfasst 3 Bewertungen. Danach ist ein Upgrade erforderlich.
          </p>
          <h4 className="font-semibold text-slate-200">2.2 Pro-Version</h4>
          <p className="text-sm">
            Die Pro-Version ermöglicht 30 Bewertungen pro Monat für 4,99€/Monat.
          </p>
          <h4 className="font-semibold text-slate-200">2.3 Bewertungspakete</h4>
          <p className="text-sm">
            Einzelne Bewertungspakete können ohne Abonnement erworben werden (5 oder 20 Bewertungen).
          </p>
        </CardContent>
      </Card>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>3. Haftungsausschluss</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-300">
          <p>
            Die von Prizr bereitgestellten Bewertungen basieren auf KI-Analysen und öffentlich verfügbaren Daten. 
            Wir übernehmen keine Gewähr für die Richtigkeit, Vollständigkeit oder Aktualität der Bewertungen.
          </p>
          <p>
            Prizr haftet nicht für finanzielle Entscheidungen, die auf Grundlage der Bewertungen getroffen werden.
            Für rechtsverbindliche Wertgutachten konsultieren Sie bitte einen zertifizierten Sachverständigen.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>4. Nutzungsrechte und Datenschutz</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-300">
          <p>
            Durch das Hochladen von Bildern gewähren Sie Prizr das Recht, diese zur Analyse und Bewertung zu verwenden.
            Die Bilder werden nicht an Dritte weitergegeben und ausschließlich für den angegebenen Zweck genutzt.
          </p>
          <p>
            Weitere Informationen finden Sie in unserer{" "}
            <a
              href={createPageUrl("Datenschutz")}
              className="text-cyan-400 hover:underline"
            >
              Datenschutzerklärung
            </a>
            .
          </p>
        </CardContent>
      </Card>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>5. Zahlungsbedingungen</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-300">
          <h4 className="font-semibold text-slate-200">5.1 Abonnements</h4>
          <p className="text-sm">
            Pro-Abonnements werden monatlich im Voraus berechnet und verlängern sich automatisch, 
            sofern nicht vor Ablauf gekündigt wird. Die Kündigung kann jederzeit über das Kundenkonto erfolgen.
          </p>
          <h4 className="font-semibold text-slate-200">5.2 Einmalkäufe</h4>
          <p className="text-sm">
            Bewertungspakete sind Einmalkäufe ohne Abonnement und zeitlich unbegrenzt gültig.
          </p>
          <h4 className="font-semibold text-slate-200">5.3 Rückerstattungen</h4>
          <p className="text-sm">
            Rückerstattungen für bereits genutzte Bewertungen sind ausgeschlossen. 
            Bei technischen Problemen kontaktieren Sie bitte unseren Support.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>6. Kündigung</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-300">
          <p>
            Sie können Ihr Abonnement jederzeit über Ihr Kundenkonto kündigen. 
            Die Kündigung wird zum Ende der aktuellen Abrechnungsperiode wirksam.
          </p>
          <p>
            Prizr behält sich das Recht vor, Konten bei Verstößen gegen diese AGB zu sperren oder zu löschen.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>7. Änderungen der AGB</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-300">
          <p>
            Prizr behält sich das Recht vor, diese AGB jederzeit zu ändern. 
            Änderungen werden Ihnen per E-Mail mitgeteilt und treten 14 Tage nach Bekanntgabe in Kraft.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle>8. Schlussbestimmungen</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-slate-300">
          <p>
            Es gilt das Recht der Bundesrepublik Deutschland. 
            Sollten einzelne Bestimmungen dieser AGB unwirksam sein, bleibt die Wirksamkeit der übrigen Bestimmungen unberührt.
          </p>
        </CardContent>
      </Card>

      <div className="text-xs text-slate-500 text-center pt-4">
        <p>Stand: {new Date().toLocaleDateString('de-DE')}</p>
        <p className="mt-2">
          Bei Fragen zu den AGB kontaktieren Sie uns unter: info@prizr.app
        </p>
      </div>
    </div>
  );
}